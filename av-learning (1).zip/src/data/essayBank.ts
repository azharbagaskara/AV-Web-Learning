import { EssayQuestion } from '../types';

export const ESSAY_BANK: EssayQuestion[] = [
  {
    id: 'essay-sd-mat-1',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'mudah',
    question: 'Jelaskan apa yang dimaksud dengan nilai tempat pada bilangan 4.825 dan sebutkan nilai tempat masing-masing angkanya!',
    referenceAnswer: 'Nilai tempat adalah nilai dari suatu angka berdasarkan letak atau posisinya dalam suatu bilangan. Pada bilangan 4.825:\n- Angka 4 menempati nilai tempat ribuan bernilai 4.000.\n- Angka 8 menempati nilai tempat ratusan bernilai 800.\n- Angka 2 menempati nilai tempat puluhan bernilai 20.\n- Angka 5 menempati nilai tempat satuan bernilai 5.',
    keywords: ['nilai tempat', 'posisi', 'ribuan', 'ratusan', 'puluhan', 'satuan', '4000', '800', '20', '5'],
    rubric: [
      { criteria: 'Menjelaskan definisi nilai tempat dengan benar', points: 30 },
      { criteria: 'Menyebutkan nilai tempat ribuan dan ratusan dengan tepat', points: 35 },
      { criteria: 'Menyebutkan nilai tempat puluhan dan satuan dengan tepat', points: 35 }
    ],
    explanation: 'Nilai tempat memudahkan kita membaca bilangan besar dan menghitung operasi penjumlahan atau pengurangan bersusun secara teratur.'
  },
  {
    id: 'essay-sd-ipas-1',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'sedang',
    question: 'Uraikan proses fotosintesis pada tumbuhan hijau! Sebutkan bahan-bahan yang dibutuhkan serta zat yang dihasilkan!',
    referenceAnswer: 'Fotosintesis adalah proses memasak makanan oleh tumbuhan berklorofil dengan bantuan sinar matahari. Bahan baku yang dibutuhkan adalah air (diserap akar dari tanah) dan karbon dioksida (diserap stomata daun dari udara). Dengan energi cahaya matahari yang ditangkap klorofil, tumbuhan menghasilkan glukosa (zat gula/makanan) dan melepaskan gas oksigen ke udara.',
    keywords: ['fotosintesis', 'klorofil', 'matahari', 'air', 'karbon dioksida', 'glukosa', 'oksigen', 'daun', 'stomata', 'akar'],
    rubric: [
      { criteria: 'Menjelaskan pengertian fotosintesis dan peran klorofil', points: 25 },
      { criteria: 'Menyebutkan bahan baku air dan karbon dioksida', points: 35 },
      { criteria: 'Menyebutkan hasil glukosa dan gas oksigen bagi kehidupan', points: 40 }
    ],
    explanation: 'Fotosintesis sangat krusial bagi kelangsungan hidup di bumi karena menyediakan oksigen dan menjadi dasar piramida rantai makanan.'
  },
  {
    id: 'essay-smp-mat-1',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sedang',
    question: 'Tuliskan bunyi Teorema Pythagoras beserta rumus umumnya! Berikan satu contoh perhitungan tripel pythagoras!',
    referenceAnswer: 'Teorema Pythagoras menyatakan: Pada segitiga siku-siku, kuadrat panjang sisi miring (hipotenusa) sama dengan jumlah kuadrat panjang kedua sisi penyikunya. Rumus: c² = a² + b².\nContoh: Jika sisi tegak a = 3 cm dan b = 4 cm, maka c = √(3² + 4²) = √(9 + 16) = √25 = 5 cm. Maka (3, 4, 5) adalah tripel pythagoras.',
    keywords: ['segitiga siku-siku', 'hipotenusa', 'sisi miring', 'kuadrat', 'c2', 'a2', 'b2', 'tripel', 'akar', '90'],
    rubric: [
      { criteria: 'Menyatakan bunyi definisi teorema dengan tepat', points: 30 },
      { criteria: 'Menuliskan rumus matematis c² = a² + b²', points: 30 },
      { criteria: 'Memberikan contoh perhitungan angka tripel dengan benar', points: 40 }
    ],
    explanation: 'Teorema Pythagoras hanya berlaku pada segitiga siku-siku dengan sudut 90 derajat.'
  },
  {
    id: 'essay-smp-ipa-1',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'sedang',
    question: 'Jelaskan perbedaan antara Hukum I Newton, Hukum II Newton, dan Hukum III Newton beserta satu contoh peristiwa dalam kehidupan sehari-hari!',
    referenceAnswer: '1. Hukum I Newton (Kelembaman/Inersia): Benda diam tetap diam atau bergerak lurus konstan jika ΣF = 0. Contoh: Penumpang mobil terdorong ke depan saat direm mendadak.\n2. Hukum II Newton: Percepatan sebanding dengan gaya dan berbanding terbalik dengan massa (F = m · a). Contoh: Mendorong troli kosong terasa lebih ringan dan cepat dibanding troli penuh belanjaan.\n3. Hukum III Newton (Aksi-Reaksi): Jika memberi gaya aksi, maka timbul gaya reaksi yang sama besar berlawanan arah (F_aksi = -F_reaksi). Contoh: Saat mendayung perahu ke belakang, perahu maju ke depan.',
    keywords: ['hukum 1', 'hukum 2', 'hukum 3', 'kelembaman', 'inersia', 'f = m a', 'aksi reaksi', 'berlawanan', 'percepatan', 'gaya'],
    rubric: [
      { criteria: 'Menjelaskan Hukum I Newton dan inersia', points: 30 },
      { criteria: 'Menjelaskan Hukum II Newton rumus F = m·a', points: 35 },
      { criteria: 'Menjelaskan Hukum III Newton gaya aksi reaksi', points: 35 }
    ],
    explanation: 'Ketiga hukum gerak Newton membentuk fondasi mekanika klasik dalam fisika.'
  },
  {
    id: 'essay-sma-mat-1',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sulit',
    question: 'Jelaskan bagaimana konsep turunan (diferensial) digunakan untuk menentukan nilai maksimum atau minimum (optimasi) dalam suatu masalah fungsi keuntungan!',
    referenceAnswer: 'Untuk mencari nilai optimum (maksimum atau minimum) dari suatu fungsi keuntungan L(x):\n1. Tentukan turunan pertama fungsi keuntungan, yaitu L\'(x).\n2. Cari titik stasioner dengan menetapkan syarat stasioner L\'(x) = 0, lalu selesaikan nilai x.\n3. Lakukan uji turunan kedua L\'\'(x): Jika L\'\'(x) < 0, maka nilai x menghasilkan nilai balik maksimum (keuntungan tertinggi). Jika L\'\'(x) > 0, menghasilkan nilai minimum.\n4. Masukkan nilai x optimal tersebut ke fungsi awal L(x) untuk memperoleh total keuntungan maksimum.',
    keywords: ['turunan', 'diferensial', 'stasioner', 'l\'(x) = 0', 'turunan kedua', 'maksimum', 'minimum', 'gradien', 'keuntungan', 'optimum'],
    rubric: [
      { criteria: 'Menyebutkan syarat stasioner turunan pertama f\'(x) = 0', points: 35 },
      { criteria: 'Menjelaskan uji turunan kedua untuk memastikan nilai maksimum', points: 35 },
      { criteria: 'Menghubungkan langkah perhitungan dengan hasil keuntungan optimal', points: 30 }
    ],
    explanation: 'Aplikasi kalkulus diferensial sangat luas pada bidang teknik, ekonomi, dan sains data.'
  }
];

export function getEssayForTopic(topicId: string): EssayQuestion {
  const matching = ESSAY_BANK.find(e => e.topicId === topicId);
  if (matching) return matching;

  // Fallback dynamic essay question
  return {
    id: `essay-dyn-${topicId}`,
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: topicId,
    difficulty: 'sedang',
    question: `Uraikan konsep pemahaman kamu mengenai topik "${topicId.replace(/-/g, ' ')}" secara lengkap, berikan contoh penerapan dan kesimpulannya!`,
    referenceAnswer: `Topik ini membahas prinsip penting dalam kurikulum. Konsep utamanya meliputi definisi dasar, aturan rumus/teori yang berlaku, serta penerapannya secara nyata dalam memecahkan masalah sehari-hari.`,
    keywords: ['konsep', 'prinsip', 'penerapan', 'contoh', 'langkah', 'manfaat', 'metode', 'analisis', 'kesimpulan'],
    rubric: [
      { criteria: 'Penjelasan konsep dan teori dasar', points: 40 },
      { criteria: 'Pemberian contoh kasus kontekstual', points: 35 },
      { criteria: 'Kerapian bahasa dan kesimpulan', points: 25 }
    ],
    explanation: 'Menulis essay melatih kemampuan analisis kritis, perumusan argumen runtut, dan penguasaan materi.'
  };
}

export function evaluateEssay(
  question: EssayQuestion,
  userAnswer: string
): {
  score: number;
  feedback: string;
  matchedKeywords: string[];
  pointsEarned: number;
} {
  const cleanAnswer = userAnswer.toLowerCase().trim();

  if (cleanAnswer.length < 15) {
    return {
      score: 20,
      feedback: 'Jawaban kamu terlalu singkat. Cobalah untuk menjelaskan konsep lebih lengkap dengan menyertakan contoh dan istilah terkait.',
      matchedKeywords: [],
      pointsEarned: 20
    };
  }

  // Keyword analysis
  const matchedKeywords = question.keywords.filter(kw => 
    cleanAnswer.includes(kw.toLowerCase())
  );

  const keywordRatio = question.keywords.length > 0
    ? matchedKeywords.length / question.keywords.length
    : 0.5;

  // Length score
  const lengthScore = Math.min(30, Math.floor(cleanAnswer.length / 8));

  // Keyword score (up to 55)
  const keywordScore = Math.min(55, Math.round(keywordRatio * 55) + 15);

  // Structure bonus
  const hasParagraphs = cleanAnswer.includes('\n') || cleanAnswer.length > 100;
  const structureBonus = hasParagraphs ? 15 : 10;

  const rawScore = Math.min(100, Math.max(30, lengthScore + keywordScore + structureBonus));
  const finalScore = Math.round(rawScore);

  let feedback = '';
  if (finalScore >= 85) {
    feedback = 'Luar biasa! Jawabanmu sangat terstruktur, memuat banyak istilah kunci yang relevan, dan penjelasan konsepnya sangat akurat.';
  } else if (finalScore >= 70) {
    feedback = 'Bagus sekali! Kamu sudah memahami inti materi dengan baik. Tambahkan sedikit detail contoh penerapan untuk hasil yang sempurna.';
  } else {
    feedback = 'Jawaban sudah cukup baik, namun masih perlu dilengkapi dengan penjelasan konsep dan kata kunci materi yang lebih mendalam.';
  }

  return {
    score: finalScore,
    feedback,
    matchedKeywords,
    pointsEarned: finalScore // XP equals score
  };
}
