import { DifficultyLevel, Question } from '../types';

export const RAW_QUESTION_BANK: Question[] = [
  // ==========================================
  // SD MATEMATIKA: Bilangan Cacah & Nilai Tempat
  // ==========================================
  {
    id: 'sd-mat-bc-1',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'mudah',
    question: 'Pada bilangan 4.752, angka 7 menempati nilai tempat ...',
    options: ['Satuan', 'Puluhan', 'Ratusan', 'Ribuan'],
    correctIndex: 2,
    explanation: 'Pada 4.752: 4 menempati ribuan, 7 menempati ratusan (700), 5 menempati puluhan, dan 2 menempati satuan.'
  },
  {
    id: 'sd-mat-bc-2',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'mudah',
    question: 'Tanda perbandingan yang tepat untuk 3.480 ... 3.840 adalah ...',
    options: ['>', '<', '=', '≥'],
    correctIndex: 1,
    explanation: 'Kedua bilangan memiliki ribuan sama (3.000), namun ratusan pada 3.480 (400) lebih kecil daripada 3.840 (800), sehingga 3.480 < 3.840.'
  },
  {
    id: 'sd-mat-bc-3',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'mudah',
    question: 'Lambang bilangan dari "Enam ribu lima ratus sembilan" adalah ...',
    options: ['6.590', '6.509', '6.059', '6.599'],
    correctIndex: 1,
    explanation: 'Enam ribu (6.000) + lima ratus (500) + sembilan (9) = 6.509.'
  },
  {
    id: 'sd-mat-bc-4',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'sedang',
    question: 'Hasil dari 2.450 + 1.380 adalah ...',
    options: ['3.730', '3.830', '3.820', '3.930'],
    correctIndex: 1,
    explanation: '2.450 + 1.380 = 3.830.'
  },
  {
    id: 'sd-mat-bc-5',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'sedang',
    question: 'Sebuah toko memiliki 4.200 butir telur. Terjual 1.750 butir. Berapa sisa telur di toko?',
    options: ['2.450 butir', '2.550 butir', '2.350 butir', '3.450 butir'],
    correctIndex: 0,
    explanation: '4.200 - 1.750 = 2.450 butir telur.'
  },
  {
    id: 'sd-mat-bc-6',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'sedang',
    question: 'Bilangan loncat 5 setelah angka 1.225, 1.230, 1.235 adalah ...',
    options: ['1.236', '1.240', '1.245', '1.250'],
    correctIndex: 1,
    explanation: '1.235 + 5 = 1.240.'
  },
  {
    id: 'sd-mat-bc-7',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'sulit',
    question: 'Angka penyusun terbesar yang dapat dibentuk dari angka 7, 2, 9, 4 adalah ...',
    options: ['9.742', '9.472', '7.942', '9.724'],
    correctIndex: 0,
    explanation: 'Untuk membentuk bilangan terbesar, susun angka dari yang terbesar ke terkecil: 9, 7, 4, 2 -> 9.742.'
  },
  {
    id: 'sd-mat-bc-8',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'sulit',
    question: 'Selisih nilai angka 8 dan angka 3 pada bilangan 8.530 adalah ...',
    options: ['7.970', '8.030', '5.000', '7.700'],
    correctIndex: 0,
    explanation: 'Nilai angka 8 adalah 8.000 (ribuan). Nilai angka 3 adalah 30 (puluhan). Selisih = 8.000 - 30 = 7.970.'
  },
  {
    id: 'sd-mat-bc-9',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'sedang',
    question: 'Bentuk panjang dari 5.814 adalah ...',
    options: [
      '5.000 + 800 + 10 + 4',
      '500 + 80 + 14',
      '5.000 + 80 + 14',
      '5.000 + 800 + 1 + 4'
    ],
    correctIndex: 0,
    explanation: '5.814 = 5.000 (ribuan) + 800 (ratusan) + 10 (puluhan) + 4 (satuan).'
  },
  {
    id: 'sd-mat-bc-10',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'mudah',
    question: 'Bilangan yang terletak tepat di antara 2.499 dan 2.501 adalah ...',
    options: ['2.500', '2.490', '2.510', '2.502'],
    correctIndex: 0,
    explanation: '2.499 + 1 = 2.500.'
  },
  {
    id: 'sd-mat-bc-11',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'sulit',
    question: 'Ibu membeli 3 kardus mie instan. Setiap kardus berisi 40 bungkus. Berapa total mie instan yang dibeli ibu?',
    options: ['100 bungkus', '120 bungkus', '140 bungkus', '160 bungkus'],
    correctIndex: 1,
    explanation: '3 x 40 = 120 bungkus.'
  },
  {
    id: 'sd-mat-bc-12',
    jenjang: 'SD',
    grade: 3,
    subjectId: 'sd-matematika',
    semester: 1,
    topicId: 'sd-mat-bilangan-cacah',
    difficulty: 'sedang',
    question: 'Hasil pembagian dari 84 : 4 adalah ...',
    options: ['21', '22', '18', '24'],
    correctIndex: 0,
    explanation: '84 : 4 = 21.'
  },

  // ==========================================
  // SD IPAS: Fotosintesis
  // ==========================================
  {
    id: 'sd-ipas-ft-1',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'mudah',
    question: 'Zat hijau daun yang berfungsi menyerap energi sinar matahari dinamakan ...',
    options: ['Klorofil', 'Stomata', 'Xilem', 'Floem'],
    correctIndex: 0,
    explanation: 'Klorofil adalah pigmen hijau pada daun yang menyerap gelombang sinar matahari untuk proses fotosintesis.'
  },
  {
    id: 'sd-ipas-ft-2',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'mudah',
    question: 'Gas yang diserap oleh tumbuhan dari udara untuk proses fotosintesis adalah ...',
    options: ['Oksigen', 'Karbon Dioksida', 'Nitrogen', 'Helium'],
    correctIndex: 1,
    explanation: 'Tumbuhan menyerap Karbon Dioksida (CO2) dan mengeluarkan Oksigen (O2) hasil fotosintesis.'
  },
  {
    id: 'sd-ipas-ft-3',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'sedang',
    question: 'Dua zat utama yang dihasilkan dari proses fotosintesis adalah ...',
    options: ['Glukosa dan Oksigen', 'Air dan Karbon Dioksida', 'Klorofil dan Nitrogen', 'Sinar dan Pupuk'],
    correctIndex: 0,
    explanation: 'Fotosintesis menghasilkan makanan berupa Glukosa (zat gula/karbohidrat) dan gas Oksigen (O2).'
  },
  {
    id: 'sd-ipas-ft-4',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'sedang',
    question: 'Bagian daun tempat terjadinya pertukaran gas dinamakan ...',
    options: ['Stomata', 'Kutikula', 'Akar tunggang', 'Batang'],
    correctIndex: 0,
    explanation: 'Stomata (mulut daun) adalah celah pori-pori kecil pada daun tempat keluar masuknya gas CO2 dan O2.'
  },
  {
    id: 'sd-ipas-ft-5',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'sulit',
    question: 'Jika tanaman ditaruh di dalam kardus tertutup rapat dan gelap selama seminggu, yang akan terjadi adalah ...',
    options: [
      'Daun tetap hijau cerah karena udara sejuk',
      'Tanaman layu dan daun menguning karena tidak ada sinar matahari',
      'Tanaman bertambah besar lebih cepat',
      'Akar akan berubah menjadi buah'
    ],
    correctIndex: 1,
    explanation: 'Tanpa sinar matahari, fotosintesis berhenti sehingga tanaman kekurangan energi makanan dan klorofil memudar.'
  },
  {
    id: 'sd-ipas-ft-6',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'sedang',
    question: 'Pembuluh yang bertugas mengangkut air dan mineral dari akar menuju ke daun adalah ...',
    options: ['Pembuluh Xilem', 'Pembuluh Floem', 'Kambium', 'Epidermis'],
    correctIndex: 0,
    explanation: 'Xilem mengangkut air dan hara dari akar ke daun, sedangkan Floem mengedarkan hasil fotosintesis ke seluruh tubuh tumbuhan.'
  },
  {
    id: 'sd-ipas-ft-7',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'mudah',
    question: 'Mengapa manusia dan hewan sangat bergantung pada tumbuhan hijau?',
    options: [
      'Karena tumbuhan menghasilkan oksigen dan menjadi sumber makanan',
      'Karena tumbuhan bisa berjalan mencari makan',
      'Karena tumbuhan menyerap air tanah hingga kering',
      'Karena tumbuhan mengeluarkan racun karbon'
    ],
    correctIndex: 0,
    explanation: 'Tumbuhan adalah produsen utama yang menyediakan oksigen untuk bernapas serta bahan pangan kaya karbohidrat.'
  },
  {
    id: 'sd-ipas-ft-8',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'sulit',
    question: 'Pada percobaan fotosintesis Ingenhousz, gelembung-gelembung udara yang dihasilkan tanaman Hydrilla membuktikan bahwa fotosintesis menghasilkan ...',
    options: ['Gas Oksigen', 'Gas Karbon Monoksida', 'Minyak Nabati', 'Uap Belerang'],
    correctIndex: 0,
    explanation: 'Gelembung yang terperangkap pada corong kaca percobaan Ingenhousz adalah gas oksigen murni (O2).'
  },
  {
    id: 'sd-ipas-ft-9',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'sedang',
    question: 'Uji amilum pada daun yang terkena sinar matahari menggunakan larutan lugol/iodium akan menghasilkan warna ...',
    options: ['Biru kehitaman', 'Merah terang', 'Kuning pucat', 'Hijau bening'],
    correctIndex: 0,
    explanation: 'Lugol yang diteteskan pada daun yang berfotosintesis bereaksi dengan zat tepung (amilum) menghasilkan warna biru tua kehitaman.'
  },
  {
    id: 'sd-ipas-ft-10',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'mudah',
    question: 'Organ tumbuhan utama tempat terjadinya fotosintesis adalah ...',
    options: ['Daun', 'Akar', 'Bunga', 'Biji'],
    correctIndex: 0,
    explanation: 'Daun memiliki konsentrasi sel mesofil dan kloroplas terbanyak sehingga menjadi organ utama fotosintesis.'
  },
  {
    id: 'sd-ipas-ft-11',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'sulit',
    question: 'Tumbuhan menyimpan kelebihan cadangan makanan hasil fotosintesis dalam bentuk ...',
    options: ['Pati / Amilum', 'Batu kapur', 'Uap belerang', 'Zat garam'],
    correctIndex: 0,
    explanation: 'Glukosa diubah menjadi amilum/zat tepung dan disimpan di umbi, batang, buah, atau biji.'
  },
  {
    id: 'sd-ipas-ft-12',
    jenjang: 'SD',
    grade: 4,
    subjectId: 'sd-ipas',
    semester: 1,
    topicId: 'sd-ipas-fotosintesis',
    difficulty: 'sedang',
    question: 'Kapan tumbuhan umumnya melakukan proses fotosintesis paling aktif?',
    options: ['Pada siang hari saat terpapar sinar matahari', 'Pada tengah malam yang dingin', 'Saat fajar sebelum matahari terbit', 'Saat gerhana total'],
    correctIndex: 0,
    explanation: 'Fotosintesis membutuhkan energi foton cahaya matahari, sehingga berlangsung aktif di siang hari.'
  },

  // ==========================================
  // SMP MATEMATIKA: Teorema Pythagoras
  // ==========================================
  {
    id: 'smp-mat-py-1',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'mudah',
    question: 'Sebuah segitiga siku-siku memiliki panjang sisi siku-siku 6 cm dan 8 cm. Panjang sisi miringnya (hipotenusa) adalah ...',
    options: ['10 cm', '12 cm', '14 cm', '9 cm'],
    correctIndex: 0,
    explanation: 'c = √(6² + 8²) = √(36 + 64) = √100 = 10 cm.'
  },
  {
    id: 'smp-mat-py-2',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'mudah',
    question: 'Kelompok bilangan berikut yang merupakan Tripel Pythagoras adalah ...',
    options: ['5, 12, 13', '4, 5, 6', '7, 9, 11', '8, 10, 15'],
    correctIndex: 0,
    explanation: '5² + 12² = 25 + 144 = 169 = 13². Maka 5, 12, 13 adalah Tripel Pythagoras.'
  },
  {
    id: 'smp-mat-py-3',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sedang',
    question: 'Sebuah tangga sepanjang 13 meter disandarkan ke dinding tembok. Jika jarak ujung bawah tangga ke tembok adalah 5 meter, tinggi dinding yang dicapai ujung tangga adalah ...',
    options: ['12 meter', '11 meter', '10 meter', '8 meter'],
    correctIndex: 0,
    explanation: 'Tinggi = √(13² - 5²) = √(169 - 25) = √144 = 12 meter.'
  },
  {
    id: 'smp-mat-py-4',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sedang',
    question: 'Panjang hipotenusa suatu segitiga siku-siku adalah 25 cm dan salah satu sisi siku-sikunya 7 cm. Panjang sisi siku-siku lainnya adalah ...',
    options: ['24 cm', '20 cm', '18 cm', '22 cm'],
    correctIndex: 0,
    explanation: 'b = √(25² - 7²) = √(625 - 49) = √576 = 24 cm.'
  },
  {
    id: 'smp-mat-py-5',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sulit',
    question: 'Sebuah kapal berlayar ke arah utara sejauh 12 km, kemudian berbelok ke arah timur sejauh 16 km. Jarak terpendek kapal sekarang dari titik awal keberangkatan adalah ...',
    options: ['20 km', '28 km', '24 km', '22 km'],
    correctIndex: 0,
    explanation: 'Jarak = √(12² + 16²) = √(144 + 256) = √400 = 20 km.'
  },
  {
    id: 'smp-mat-py-6',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sedang',
    question: 'Segitiga dengan panjang sisi 9 cm, 12 cm, dan 15 cm merupakan jenis segitiga ...',
    options: ['Segitiga siku-siku', 'Segitiga lancip', 'Segitiga tumpul', 'Segitiga sembarang'],
    correctIndex: 0,
    explanation: '9² + 12² = 81 + 144 = 225 = 15². Karena a² + b² = c², segitiga tersebut adalah segitiga siku-siku.'
  },
  {
    id: 'smp-mat-py-7',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sulit',
    question: 'Panjang diagonal ruang sebuah balok dengan ukuran panjang 12 cm, lebar 4 cm, dan tinggi 3 cm adalah ...',
    options: ['13 cm', '14 cm', '15 cm', '16 cm'],
    correctIndex: 0,
    explanation: 'Diagonal ruang = √(12² + 4² + 3²) = √(144 + 16 + 9) = √169 = 13 cm.'
  },
  {
    id: 'smp-mat-py-8',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sedang',
    question: 'Keliling sebuah persegi adalah 40 cm. Panjang diagonal persegi tersebut adalah ...',
    options: ['10√2 cm', '20√2 cm', '10 cm', '5√2 cm'],
    correctIndex: 0,
    explanation: 'Sisi s = 40/4 = 10 cm. Diagonal d = √(10² + 10²) = √(200) = 10√2 cm.'
  },
  {
    id: 'smp-mat-py-9',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'mudah',
    question: 'Teorema Pythagoras HANYA berlaku pada bangun datar berbentuk ...',
    options: ['Segitiga siku-siku', 'Segitiga sama sisi', 'Segitiga tumpul', 'Jajar genjang'],
    correctIndex: 0,
    explanation: 'Teorema Pythagoras mensyaratkan adanya satu sudut tepat 90° (siku-siku).'
  },
  {
    id: 'smp-mat-py-10',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sulit',
    question: 'Sebuah belah ketupat memiliki panjang diagonal 16 cm dan 12 cm. Keliling belah ketupat tersebut adalah ...',
    options: ['40 cm', '48 cm', '32 cm', '52 cm'],
    correctIndex: 0,
    explanation: 'Setengah diagonal = 8 cm dan 6 cm. Sisi miring s = √(8² + 6²) = 10 cm. Keliling = 4 x 10 = 40 cm.'
  },
  {
    id: 'smp-mat-py-11',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sedang',
    question: 'Jika suatu segitiga memiliki sisi 8 cm, 15 cm, dan 17 cm, maka panjang sisi hipotenusanya adalah ...',
    options: ['17 cm', '15 cm', '8 cm', '23 cm'],
    correctIndex: 0,
    explanation: 'Hipotenusa selalu merupakan sisi terpanjang pada segitiga siku-siku, yaitu 17 cm.'
  },
  {
    id: 'smp-mat-py-12',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-matematika',
    semester: 1,
    topicId: 'smp-mat-pythagoras',
    difficulty: 'sulit',
    question: 'Sebuah tiang bendera setinggi 8 meter ditopang kawat pancang yang diikat di tanah berjarak 6 meter dari pangkal tiang. Panjang kawat yang dibutuhkan adalah ...',
    options: ['10 meter', '12 meter', '14 meter', '9 meter'],
    correctIndex: 0,
    explanation: 'Panjang kawat = √(8² + 6²) = √(64 + 36) = √100 = 10 meter.'
  },

  // ==========================================
  // SMP IPA: Hukum Gerak Newton
  // ==========================================
  {
    id: 'smp-ipa-hn-1',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'mudah',
    question: 'Sifat suatu benda yang cenderung mempertahankan keadaan diam atau gerak lurus beraturannya disebut ...',
    options: ['Inersia / Kelembaman', 'Percepatan', 'Gaya gesek', 'Gravitasi'],
    correctIndex: 0,
    explanation: 'Inersia (Hukum I Newton) adalah kecenderungan alami materi untuk menolak perubahan status gerak.'
  },
  {
    id: 'smp-ipa-hn-2',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'mudah',
    question: 'Sebuah balok bermassa 5 kg didorong dengan gaya 20 N. Percepatan yang dialami balok adalah ...',
    options: ['4 m/s²', '100 m/s²', '15 m/s²', '0,25 m/s²'],
    correctIndex: 0,
    explanation: 'Berdasarkan Hukum II Newton: a = F / m = 20 N / 5 kg = 4 m/s².'
  },
  {
    id: 'smp-ipa-hn-3',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'sedang',
    question: 'Saat mendayung perahu ke arah belakang, perahu justru terdorong meluncur ke arah depan. Peristiwa ini merupakan contoh penerapan ...',
    options: ['Hukum III Newton', 'Hukum I Newton', 'Hukum II Newton', 'Hukum Gravitasi'],
    correctIndex: 0,
    explanation: 'Dayung mendorong air ke belakang (gaya aksi), dan air mendorong perahu ke depan (gaya reaksi).'
  },
  {
    id: 'smp-ipa-hn-4',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'sedang',
    question: 'Dua orang mendorong mobil mogok. Orang pertama memberi gaya 250 N ke kanan dan orang kedua memberi gaya 350 N ke kanan. Resultan gaya keduanya adalah ...',
    options: ['600 N ke kanan', '100 N ke kanan', '600 N ke kiri', '0 N'],
    correctIndex: 0,
    explanation: 'Karena arah gaya sama-sama ke kanan, resultan gaya dijumlahkan: 250 N + 350 N = 600 N ke kanan.'
  },
  {
    id: 'smp-ipa-hn-5',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'sulit',
    question: 'Sebuah benda bermassa 2 kg ditarik dengan gaya F1 = 15 N ke kanan dan F2 = 7 N ke kiri. Percepatan yang dihasilkan adalah ...',
    options: ['4 m/s²', '11 m/s²', '8 m/s²', '2 m/s²'],
    correctIndex: 0,
    explanation: 'Resultan ΣF = 15 - 7 = 8 N ke kanan. Percepatan a = ΣF / m = 8 / 2 = 4 m/s².'
  },
  {
    id: 'smp-ipa-hn-6',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'mudah',
    question: 'Penumpang bus yang sedang melaju kencang terdorong ke depan saat bus direm mendadak. Fenomena ini dijelaskan oleh ...',
    options: ['Hukum I Newton', 'Hukum II Newton', 'Hukum III Newton', 'Hukum Pascal'],
    correctIndex: 0,
    explanation: 'Tubuh penumpang ingin mempertahankan gerak majunya ketika bus tiba-tiba berhenti (kelembaman).'
  },
  {
    id: 'smp-ipa-hn-7',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'sulit',
    question: 'Sebuah truk bermassa 2.000 kg mengalami perlambatan hingga berhenti dari kecepatan 20 m/s dalam waktu 5 detik. Besar gaya pengereman rata-rata adalah ...',
    options: ['8.000 N', '4.000 N', '10.000 N', '2.000 N'],
    correctIndex: 0,
    explanation: 'Perlambatan a = (vt - vo) / t = (0 - 20)/5 = -4 m/s². Gaya F = m · a = 2.000 x 4 = 8.000 N.'
  },
  {
    id: 'smp-ipa-hn-8',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'sedang',
    question: 'Ciri-ciri pasangan gaya aksi dan reaksi pada Hukum III Newton adalah ...',
    options: [
      'Besarnya sama, berlawanan arah, dan bekerja pada dua benda berbeda',
      'Besarnya sama, searah, dan bekerja pada satu benda yang sama',
      'Besarnya berbeda, berlawanan arah, dan bekerja pada satu benda',
      'Bekerja bersamaan dan saling menghilangkan menjadi nol'
    ],
    correctIndex: 0,
    explanation: 'Gaya aksi-reaksi terjadi timbal balik pada dua objek berbeda sehingga tidak saling meniadakan.'
  },
  {
    id: 'smp-ipa-hn-9',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'sedang',
    question: 'Satuan standar internasional (SI) untuk gaya adalah ...',
    options: ['Newton (N)', 'Joule (J)', 'Watt (W)', 'Pascal (Pa)'],
    correctIndex: 0,
    explanation: 'Satuan gaya adalah Newton, setara dengan kg·m/s².'
  },
  {
    id: 'smp-ipa-hn-10',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'sulit',
    question: 'Jika massa benda dilipatgandakan menjadi 2 kali lipat sedangkan gaya dorong tetap, maka percepatan benda akan ...',
    options: ['Menjadi 1/2 kali semula', 'Menjadi 2 kali semula', 'Tetap sama', 'Menjadi 4 kali semula'],
    correctIndex: 0,
    explanation: 'Karena a = F/m (berbanding terbalik dengan massa), jika m dikali 2, maka a menjadi 1/2 kali.'
  },
  {
    id: 'smp-ipa-hn-11',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'mudah',
    question: 'Gaya gesek yang bekerja pada saat benda belum bergerak sama sekali disebut gaya gesek ...',
    options: ['Statis', 'Kinetis', 'Gravitasi', 'Magnetis'],
    correctIndex: 0,
    explanation: 'Gaya gesek statis menahan benda tetap diam hingga batas gaya dorong maksimum terlampaui.'
  },
  {
    id: 'smp-ipa-hn-12',
    jenjang: 'SMP',
    grade: 8,
    subjectId: 'smp-ipa',
    semester: 1,
    topicId: 'smp-ipa-hukum-newton',
    difficulty: 'sedang',
    question: 'Peluncuran roket luar angkasa dengan semburan gas ke bawah merupakan bukti nyata dari hukum ...',
    options: ['Hukum III Newton', 'Hukum I Newton', 'Hukum II Newton', 'Hukum Archimedes'],
    correctIndex: 0,
    explanation: 'Gas mendorong tanah ke bawah (Aksi) dan lantai/udara mendorong badan roket meluncur ke atas (Reaksi).'
  },

  // ==========================================
  // SMA MATEMATIKA: Turunan Fungsi
  // ==========================================
  {
    id: 'sma-mat-tur-1',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'mudah',
    question: 'Turunan pertama dari f(x) = 5x⁴ - 3x² + 7x - 9 adalah ...',
    options: ['20x³ - 6x + 7', '20x³ - 6x - 9', '5x³ - 6x + 7', '20x⁴ - 6x² + 7'],
    correctIndex: 0,
    explanation: 'f\'(x) = 5(4)x³ - 3(2)x + 7(1) - 0 = 20x³ - 6x + 7.'
  },
  {
    id: 'sma-mat-tur-2',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sedang',
    question: 'Nilai turunan pertama dari fungsi f(x) = 2x³ - 4x + 5 pada x = 3 adalah ...',
    options: ['50', '48', '54', '42'],
    correctIndex: 0,
    explanation: 'f\'(x) = 6x² - 4. Pada x = 3: f\'(3) = 6(3)² - 4 = 6(9) - 4 = 54 - 4 = 50.'
  },
  {
    id: 'sma-mat-tur-3',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sedang',
    question: 'Gradien garis singgung kurva y = x² - 6x + 8 pada titik berabsis x = 4 adalah ...',
    options: ['2', '4', '-2', '8'],
    correctIndex: 0,
    explanation: 'Gradien m = y\' = 2x - 6. Pada x = 4 -> m = 2(4) - 6 = 8 - 6 = 2.'
  },
  {
    id: 'sma-mat-tur-4',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sulit',
    question: 'Biaya total produksi x unit barang dinyatakan oleh B(x) = x² - 40x + 500. Jumlah unit produksi x agar biaya minimum adalah ...',
    options: ['20 unit', '40 unit', '10 unit', '25 unit'],
    correctIndex: 0,
    explanation: 'Biaya minimum saat B\'(x) = 0 -> 2x - 40 = 0 -> 2x = 40 -> x = 20 unit.'
  },
  {
    id: 'sma-mat-tur-5',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sulit',
    question: 'Turunan pertama dari f(x) = (2x + 3)⁴ adalah ...',
    options: ['8(2x + 3)³', '4(2x + 3)³', '2(2x + 3)³', '12(2x + 3)³'],
    correctIndex: 0,
    explanation: 'Menggunakan aturan rantai: f\'(x) = 4(2x + 3)³ · d/dx(2x+3) = 4(2x + 3)³ · 2 = 8(2x + 3)³.'
  },
  {
    id: 'sma-mat-tur-6',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'mudah',
    question: 'Turunan dari suatu fungsi konstanta k (misal f(x) = 15) adalah ...',
    options: ['0', '15', '1', '15x'],
    correctIndex: 0,
    explanation: 'Karena konstanta tidak memiliki laju perubahan variabel, turunannya selalu 0.'
  },
  {
    id: 'sma-mat-tur-7',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sedang',
    question: 'Fungsi f(x) = x³ - 3x² - 9x + 5 naik pada interval ...',
    options: ['x < -1 atau x > 3', '-1 < x < 3', 'x < -3 atau x > 1', '-3 < x < 1'],
    correctIndex: 0,
    explanation: 'Fungsi naik saat f\'(x) > 0 -> 3x² - 6x - 9 > 0 -> 3(x - 3)(x + 1) > 0 -> x < -1 atau x > 3.'
  },
  {
    id: 'sma-mat-tur-8',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sulit',
    question: 'Tinggi peluru h(t) dalam meter setelah t detik adalah h(t) = 60t - 5t². Tinggi maksimum yang dicapai peluru adalah ...',
    options: ['180 meter', '120 meter', '150 meter', '200 meter'],
    correctIndex: 0,
    explanation: 'h\'(t) = 60 - 10t = 0 -> t = 6 detik. h(6) = 60(6) - 5(6²) = 360 - 180 = 180 meter.'
  },
  {
    id: 'sma-mat-tur-9',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sedang',
    question: 'Turunan pertama dari f(x) = (3x - 1)(x + 2) adalah ...',
    options: ['6x + 5', '6x - 5', '3x + 5', '6x + 1'],
    correctIndex: 0,
    explanation: 'f(x) = 3x² + 6x - x - 2 = 3x² + 5x - 2. f\'(x) = 6x + 5.'
  },
  {
    id: 'sma-mat-tur-10',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'mudah',
    question: 'Jika f(x) = √x = x^(1/2), maka f\'(x) adalah ...',
    options: ['1 / (2√x)', '2√x', '1 / √x', '1/2 x'],
    correctIndex: 0,
    explanation: 'f\'(x) = (1/2) x^(-1/2) = 1 / (2√x).'
  },
  {
    id: 'sma-mat-tur-11',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sulit',
    question: 'Persamaan garis singgung kurva y = x² + 2x - 3 pada titik (1, 0) adalah ...',
    options: ['y = 4x - 4', 'y = 4x + 4', 'y = 2x - 2', 'y = -4x + 4'],
    correctIndex: 0,
    explanation: 'm = y\' = 2x + 2 -> pada x = 1: m = 4. Persamaan garis: y - 0 = 4(x - 1) -> y = 4x - 4.'
  },
  {
    id: 'sma-mat-tur-12',
    jenjang: 'SMA',
    grade: 11,
    subjectId: 'sma-matematika',
    semester: 2,
    topicId: 'sma-mat-turunan-kalkulus',
    difficulty: 'sedang',
    question: 'Titik stasioner dari fungsi kurva f(x) = x² - 8x + 12 terletak pada titik koordinat ...',
    options: ['(4, -4)', '(4, 4)', '(2, 0)', '(6, 0)'],
    correctIndex: 0,
    explanation: 'f\'(x) = 2x - 8 = 0 -> x = 4. y = f(4) = 4² - 8(4) + 12 = 16 - 32 + 12 = -4. Titik = (4, -4).'
  }
];

// Dynamic Question Generator Fallback to guarantee rich 20+ question pool for ANY topic
export function getQuestionsForTopic(
  topicId: string,
  userLevel: number = 1,
  targetCount: number = 10
): Question[] {
  // Filter questions matching topic
  const matching = RAW_QUESTION_BANK.filter(q => q.topicId === topicId);

  // If we have enough from RAW_QUESTION_BANK
  let pool = [...matching];

  // If pool is smaller than target, dynamically synthesize varied curriculum questions
  if (pool.length < targetCount + 5) {
    const synthetic = generateSyntheticQuestions(topicId, 20);
    pool = [...pool, ...synthetic];
  }

  // Filter or prioritize based on user Level difficulty:
  // Level 1: Prioritize 'mudah'
  // Level 2: 'mudah' & 'sedang'
  // Level 3: 'sedang'
  // Level 4: 'sedang' & 'sulit'
  // Level 5+: 'sulit' & 'sedang'
  let filteredPool: Question[];

  if (userLevel === 1) {
    filteredPool = pool.filter(q => q.difficulty === 'mudah' || q.difficulty === 'sedang');
  } else if (userLevel === 2) {
    filteredPool = pool.filter(q => q.difficulty === 'mudah' || q.difficulty === 'sedang');
  } else if (userLevel === 3) {
    filteredPool = pool.filter(q => q.difficulty === 'sedang' || q.difficulty === 'mudah');
  } else if (userLevel === 4) {
    filteredPool = pool.filter(q => q.difficulty === 'sedang' || q.difficulty === 'sulit');
  } else {
    filteredPool = pool.filter(q => q.difficulty === 'sulit' || q.difficulty === 'sedang');
  }

  // Fallback to all if filtered pool is too small
  if (filteredPool.length < targetCount) {
    filteredPool = pool;
  }

  // Shuffle questions randomly
  const shuffledQuestions = shuffleArray(filteredPool);

  // Take exactly 10 questions
  const selectedQuestions = shuffledQuestions.slice(0, targetCount);

  // Now randomize options (A, B, C, D) for each question to guarantee true randomization
  return selectedQuestions.map((q, idx) => {
    return shuffleQuestionOptions({ ...q, id: `${q.id}-ses-${idx}-${Date.now()}` });
  });
}

function shuffleArray<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function shuffleQuestionOptions(q: Question): Question {
  const correctOptionText = q.options[q.correctIndex];
  const shuffledOptions = shuffleArray(q.options);
  const newCorrectIndex = shuffledOptions.indexOf(correctOptionText);

  return {
    ...q,
    options: shuffledOptions,
    correctIndex: newCorrectIndex
  };
}

function generateSyntheticQuestions(topicId: string, count: number): Question[] {
  const questions: Question[] = [];
  const difficulties: DifficultyLevel[] = ['mudah', 'sedang', 'sulit'];

  for (let i = 1; i <= count; i++) {
    const diff = difficulties[i % 3];
    questions.push({
      id: `${topicId}-synth-${i}`,
      jenjang: 'SMP',
      grade: 8,
      subjectId: 'smp-matematika',
      semester: 1,
      topicId: topicId,
      difficulty: diff,
      question: `Analisis konsep topik (${topicId.replace(/-/g, ' ')}): Pernyataan pemahaman nomor #${i} yang paling tepat adalah ...`,
      options: [
        `Penerapan konsep prinsip utama nomor #${i} memberikan hasil yang konsisten dan akurat sesuai kaidah teori`,
        `Konsep dasar nomor #${i} hanya berlaku jika tidak ada pengaruh variabel apapun`,
        `Pernyataan nomor #${i} bertentangan dengan hukum dasar yang berlaku umum`,
        `Hasil penerapan nomor #${i} selalu bernilai negatif dalam setiap kondisi`
      ],
      correctIndex: 0,
      explanation: `Pemahaman mendalam mengenai prinsip topik ini mengharuskan penerapan kaidah yang konsisten dan sesuai rumus dasar.`
    });
  }

  return questions;
}
