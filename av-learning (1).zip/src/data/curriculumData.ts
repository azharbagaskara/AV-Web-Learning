import { EducationLevel, Subject, Topic } from '../types';

export const SUBJECTS: Subject[] = [
  // ==========================================
  // SD SUBJECTS (Kelas 1 - 6)
  // ==========================================
  {
    id: 'sd-matematika',
    name: 'Matematika SD',
    icon: '📐',
    color: 'from-blue-500 to-indigo-600',
    accentColor: 'blue',
    description: 'Mempelajari dasar berhitung, operasi bilangan, pecahan, geometri bangun datar, dan pengukuran praktis.',
    educationLevel: 'SD',
    grades: [1, 2, 3, 4, 5, 6],
    semester1Syllabus: {
      semester: 1,
      theme: 'Bilangan Cacah, Operasi Hitung Dasar & Pengukuran',
      description: 'Fokus pada pengenalan angka, nilai tempat, penjumlahan, pengurangan, perkalian bersusun, dan konversi satuan panjang/berat.',
      mainTopics: ['Mengenal Bilangan & Nilai Tempat', 'Operasi Penjumlahan & Pengurangan', 'Perkalian & Pembagian Dasar', 'Satuan Panjang & Berat'],
      expectedCompetencies: ['Mampu melakukan hitung cepat tanpa kalkulator', 'Memahami nilai satuan, puluhan, ratusan, hingga ribuan', 'Menerapkan hitungan dalam belanja sehari-hari']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Pecahan, Bangun Datar, Waktu & Keliling',
      description: 'Mempelajari konsep pecahan senilai, menghitung luas dan keliling bangun datar (persegi, segitiga, persegi panjang), serta membaca jam/waktu.',
      mainTopics: ['Pecahan Sederhana & Desimal', 'Bangun Datar & Karakteristiknya', 'Keliling & Luas Sederhana', 'Membaca Jam & Durasi Waktu'],
      expectedCompetencies: ['Memvisualisasikan potongan pecahan', 'Menghitung keliling dan luas ruangan sederhana', 'Mengatur jadwal waktu harian dengan akurat']
    }
  },
  {
    id: 'sd-bahasa-indonesia',
    name: 'Bahasa Indonesia SD',
    icon: '📖',
    color: 'from-amber-500 to-orange-600',
    accentColor: 'amber',
    description: 'Mengembangkan keterampilan membaca, menulis kalimat efektif, memahami dongeng, pantun, dan menyusun paragraf deskripsi.',
    educationLevel: 'SD',
    grades: [1, 2, 3, 4, 5, 6],
    semester1Syllabus: {
      semester: 1,
      theme: 'Membaca Lancar, Kosakata Baru & Kalimat Sederhana',
      description: 'Pengenalan huruf, suku kata, menyusun kalimat SPOK sederhana, tanda baca titik dan koma, serta menceritakan kembali cerita pendek.',
      mainTopics: ['Struktur Kalimat SPOK', 'Tanda Baca & Huruf Kapital', 'Menemukan Gagasan Pokok', 'Teks Narasi & Cerita Anak'],
      expectedCompetencies: ['Membaca dengan intonasi yang tepat', 'Menulis cerita pengalaman pribadi dengan runtut', 'Menemukan pesan moral dari dongeng']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Puisi, Pantun, Surat & Paragraf Deskripsi',
      description: 'Belajar membuat puisi anak, mengenal rima pantun nasihat, menulis surat untuk sahabat, dan menggambarkan objek secara detail.',
      mainTopics: ['Menulis Pantun & Puisi', 'Teks Deskripsi & Laporan Sederhana', 'Kata Baku & Kosakata Percakapan', 'Wawancara Sederhana'],
      expectedCompetencies: ['Mengekspresikan imajinasi melalui puisi dan pantun', 'Menyusun laporan pengamatan lingkungan sekolah', 'Berbicara santun di depan umum']
    }
  },
  {
    id: 'sd-ipas',
    name: 'IPAS (Ilmu Pengetahuan Alam & Sosial)',
    icon: '🌱',
    color: 'from-emerald-500 to-teal-600',
    accentColor: 'emerald',
    description: 'Menjelajahi makhluk hidup, daur hidup tumbuhan & hewan, energi, siklus air, serta interaksi sosial di lingkungan tempat tinggal.',
    educationLevel: 'SD',
    grades: [1, 2, 3, 4, 5, 6],
    semester1Syllabus: {
      semester: 1,
      theme: 'Makhluk Hidup, Fotosintesis & Wujud Benda',
      description: 'Mempelajari bagian tumbuhan, proses fotosintesis, rantai makanan ekosistem sekitar, dan perubahan wujud zat (mencair, membeku, menguap).',
      mainTopics: ['Bagian Tubuh Tumbuhan & Fungsinya', 'Fotosintesis & Rantai Makanan', 'Perubahan Wujud Benda', 'Gaya & Gerak di Sekitar Kita'],
      expectedCompetencies: ['Menjelaskan peran matahari bagi tanaman', 'Mengidentifikasi peristiwa membeku, menguap, dan menyublim', 'Mengetahui pengaruh gaya dorong dan tarik']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Bumi, Tata Surya, Peta & Keberagaman Budaya',
      description: 'Mengenal lapisan bumi, siklus air hujan, membaca arah mata angin/peta wilayah, serta tradisi dan peninggalan sejarah di Indonesia.',
      mainTopics: ['Siklus Air & Kelestarian Alam', 'Membaca Peta & Simbol Lingkungan', 'Keragaman Suku & Budaya Indonesia', 'Aktivitas Ekonomi Masyarakat'],
      expectedCompetencies: ['Menjaga kebersihan sumber air bersih', 'Menghormati keragaman adat dan budaya daerah lain', 'Memahami alur produsen, distributor, dan konsumen']
    }
  },
  {
    id: 'sd-pendidikan-pancasila',
    name: 'Pendidikan Pancasila SD',
    icon: '🦅',
    color: 'from-red-500 to-rose-600',
    accentColor: 'red',
    description: 'Menanamkan nilai-nilai 5 sila Pancasila, toleransi, norma musyawarah, gotong royong, dan hak-kewajiban anak di rumah & sekolah.',
    educationLevel: 'SD',
    grades: [1, 2, 3, 4, 5, 6],
    semester1Syllabus: {
      semester: 1,
      theme: 'Simbol & Penerapan Nilai-Nilai 5 Sila Pancasila',
      description: 'Memahami arti lambang Bintang, Rantai, Pohon Beringin, Kepala Banteng, dan Padi-Kapas beserta contoh pengamalannya.',
      mainTopics: ['Makna Lambang Garuda Pancasila', 'Pengamalan Sila ke-1 sampai ke-5', 'Hak & Kewajiban di Rumah', 'Tata Tertib Sekolah'],
      expectedCompetencies: ['Menunjukkan sikap jujur, disiplin, dan religius', 'Melaksanakan piket kelas dengan penuh tanggung jawab', 'Menghargai teman yang sedang beribadah']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Bhinneka Tunggal Ika & Musyawarah Mufakat',
      description: 'Menumbuhkan persatuan dalam keragaman suku, bahasa daerah, pakaian adat, serta membiasakan musyawarah pemilihan ketua kelas.',
      mainTopics: ['Arti Semboyan Bhinneka Tunggal Ika', 'Musyawarah untuk Mufakat', 'Gotong Royong Lingkungan RT', 'Mencintai Produk Buatan Indonesia'],
      expectedCompetencies: ['Menerima perbedaan pendapat tanpa bertengkar', 'Berpartisipasi aktif dalam kegiatan sosial sekolah', 'Bangga memakai pakaian adat dan batik']
    }
  },
  {
    id: 'sd-pendidikan-agama',
    name: 'Pendidikan Agama SD',
    icon: '🕌',
    color: 'from-teal-500 to-green-700',
    accentColor: 'teal',
    description: 'Pendidikan akhlak mulia, doa harian, kisah teladan nabi & rasul, kejujuran, kasih sayang sesama makhluk, dan ibadah dasar.',
    educationLevel: 'SD',
    grades: [1, 2, 3, 4, 5, 6],
    semester1Syllabus: {
      semester: 1,
      theme: 'Rukun Iman, Doa Harian & Akhlak Terpuji',
      description: 'Mengenal sifat-sifat wajib Tuhan, hafalan surat pendek/doa sebelum belajar & makan, serta perilaku santun kepada orang tua dan guru.',
      mainTopics: ['Rukun Iman & Percaya Pada Tuhan', 'Doa Aktivitas Sehari-hari', 'Berbakti Kepada Orang Tua', 'Kisah Teladan Nabi/Tokoh Bijak'],
      expectedCompetencies: ['Membaca doa harian secara teratur', 'Menunjukkan rasa hormat kepada guru dan orang tua', 'Menjaga kebersihan diri dan tempat ibadah']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Tata Cara Ibadah, Sedekah & Kerukunan',
      description: 'Panduan tata cara bersuci (wudhu/membersihkan diri), gerakan ibadah, semangat berbagi kepada anak yatim, dan kerukunan antarumat beragama.',
      mainTopics: ['Tata Cara Bersuci & Kebersihan', 'Panduan Gerakan Ibadah', 'Pentingnya Berbagi & Sedekah', 'Toleransi Antar Teman Berbeda Agama'],
      expectedCompetencies: ['Mampu mempraktikkan ibadah dengan tertib', 'Suka menolong teman yang kesusahan tanpa membedakan', 'Menjaga lisan dari perkataan kasar']
    }
  },
  {
    id: 'sd-bahasa-inggris',
    name: 'Bahasa Inggris SD',
    icon: '🇬🇧',
    color: 'from-cyan-500 to-blue-600',
    accentColor: 'cyan',
    description: 'Basic English vocabulary: greetings, numbers, colors, family members, classroom objects, animals, and simple daily conversation.',
    educationLevel: 'SD',
    grades: [1, 2, 3, 4, 5, 6],
    semester1Syllabus: {
      semester: 1,
      theme: 'Greetings, Numbers, Colors & Family',
      description: 'Belajar menyapa (Good morning, Hello), berhitung 1-100, menyebutkan warna benda, dan memperkenalkan anggota keluarga.',
      mainTopics: ['Greetings & Simple Introductions', 'Numbers 1 to 100', 'Colors and Shapes', 'My Family Tree'],
      expectedCompetencies: ['Introduce oneself confidently in English', 'Count objects and state their colors accurately', 'Name immediate family members']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Animals, Food, Daily Activities & Time',
      description: 'Menyebutkan nama hewan piaraan dan liar, makanan favorit, kegiatan di rumah (eat, sleep, study), dan menanyakan jam sederhana.',
      mainTopics: ['Animals & Their Habitats', 'Food & Drinks (I like / I don’t like)', 'Daily Routines & Simple Present', 'Telling Time (O’clock)'],
      expectedCompetencies: ['Express food preferences clearly', 'Describe morning routines in simple English sentences', 'Tell the time using o\'clock and half past']
    }
  },
  {
    id: 'sd-seni',
    name: 'Seni Budaya & Prakarya SD',
    icon: '🎨',
    color: 'from-purple-500 to-pink-600',
    accentColor: 'purple',
    description: 'Mengeksplorasi warna primer & sekunder, membuat kolase, melipat origami, menyanyikan lagu daerah, dan gerak tari tradisional.',
    educationLevel: 'SD',
    grades: [1, 2, 3, 4, 5, 6],
    semester1Syllabus: {
      semester: 1,
      theme: 'Unsur Rupa, Campuran Warna & Kolase',
      description: 'Mengenal garis, bidang, tekstur, pencampuran warna cat air, teknik tempel montase/kolase dari daun kering dan kertas warna.',
      mainTopics: ['Warna Primer, Sekunder & Tersier', 'Teknik Kolase & Mozaik', 'Lagu Wajib Nasional & Birama', 'Pola Gerak Tari Anak'],
      expectedCompetencies: ['Menciptakan karya lukis kreatif dengan perpaduan warna harmonis', 'Membuat kerajinan tangan dari bahan ramah lingkungan', 'Menyanyikan lagu nasional dengan tempo teratur']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Anyaman, Gerak Tari Daerah & Musik Ansambel',
      description: 'Membuat anyaman sederhana dari kertas karton, mengenal alat musik ritmis (marakas, rebana), dan memainkan pola irama lagu daerah.',
      mainTopics: ['Seni Anyaman & Kerajinan Kertas', 'Mengenal Alat Musik Ritmis & Melodis', 'Lagu Daerah Nusantara', 'Kostum & Properti Tari Tradisional'],
      expectedCompetencies: ['Menghasilkan anyaman berpola rapi', 'Memainkan alat musik perkusi sesuai ketukan', 'Mengidentifikasi lagu daerah khas Indonesia']
    }
  },
  {
    id: 'sd-pjok',
    name: 'PJOK (Pendidikan Jasmani) SD',
    icon: '⚽',
    color: 'from-lime-500 to-green-600',
    accentColor: 'lime',
    description: 'Gerak lokomotor, non-lokomotor, manipulatif, senam lantai, kebugaran jasmani, permainan bola kecil & besar, serta gizi seimbang.',
    educationLevel: 'SD',
    grades: [1, 2, 3, 4, 5, 6],
    semester1Syllabus: {
      semester: 1,
      theme: 'Gerak Dasar Lokomotor, Keseimbangan & Permainan Bola',
      description: 'Latihan lari cepat, lompat tali, meluncur, menangkap bola kasti, menendang bola kaki, serta peregangan otot sebelum berolahraga.',
      mainTopics: ['Gerak Lokomotor & Non-Lokomotor', 'Permainan Bola Kasti & Kebugaran', 'Senam Irama & Keseimbangan Tubuh', 'Makanan Bergizi 4 Sehat 5 Sempurna'],
      expectedCompetencies: ['Menjaga postur tubuh tegak dan seimbang', 'Bermain kasti dengan sportivitas tinggi', 'Memilih camilan sehat dan rajin minum air putih']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Senam Lantai, Renang Dasar & Pertolongan Pertama',
      description: 'Latihan guling depan dengan matras yang aman, gerakan mengapung di kolam renang, menjaga kebersihan organ tubuh, dan mengobati luka lecet.',
      mainTopics: ['Senam Lantai (Roll Depan & Sikap Lilin)', 'Pengenalan Air & Keselamatan Renang', 'Menjaga Kebersihan Diri & Baju Ganti', 'Pertolongan Pertama pada Luka Ringan'],
      expectedCompetencies: ['Melakukan roll depan dengan teknik perlindungan leher yang benar', 'Mengikuti instruksi keselamatan saat berenang', 'Mengetahui cara membersihkan luka lecet dengan antiseptik']
    }
  },

  // ==========================================
  // SMP SUBJECTS (Kelas 7 - 9)
  // ==========================================
  {
    id: 'smp-matematika',
    name: 'Matematika SMP',
    icon: '📐',
    color: 'from-blue-600 to-indigo-700',
    accentColor: 'blue',
    description: 'Bilangan bulat & pecahan, aljabar, persamaan linear satu/dua variabel, teorema Pythagoras, transformasi geometri, dan statistika.',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Bilangan Berpangkat, Aljabar & Teorema Pythagoras',
      description: 'Membahas sifat perpangkatan, perkalian suku aljabar, pemfaktoran kuadrat, pembuktian Pythagoras pada segitiga siku-siku, dan sistem koordinat Kartesius.',
      mainTopics: ['Bilangan Berpangkat & Bentuk Akar', 'Operasi Aljabar & Pemfaktoran', 'Persamaan Linear Satu & Dua Variabel (SPLDV)', 'Teorema Pythagoras & Tripel Pythagoras'],
      expectedCompetencies: ['Menyederhanakan bentuk akar dan eksponen', 'Menyelesaikan masalah kontekstual dengan SPLDV', 'Menghitung jarak dan sisi miring menggunakan rumus Pythagoras']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Lingkaran, Bangun Ruang Sisi Lengkung, Peluang & Statistika',
      description: 'Menghitung keliling dan luas lingkaran, sudut pusat & busur, volume tabung, kerucut, bola, rata-rata (mean/median/modus), serta peluang empirik/teoretik.',
      mainTopics: ['Sudut Pusat, Busur & Luas Juring Lingkaran', 'Bangun Ruang Sisi Lengkung (Tabung, Kerucut, Bola)', 'Statistika: Mean, Median, Modus & Kuartil', 'Peluang Teoretik & Ruang Sampel'],
      expectedCompetencies: ['Menghitung luas permukaan dan volume kemasan silinder', 'Menganalisis diagram batang dan data survei', 'Menentukan peluang munculnya mata dadu atau koin']
    }
  },
  {
    id: 'smp-ipa',
    name: 'IPA (Ilmu Pengetahuan Alam) SMP',
    icon: '🔬',
    color: 'from-teal-500 to-emerald-700',
    accentColor: 'teal',
    description: 'Fisika (Gerak, Gaya, Tekanan, Optik, Listrik), Biologi (Sel, Sistem Organ, Pewarisan Sifat, Bioteknologi), dan Kimia Dasar (Atom & Unsur).',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Sistem Organ Manusia, Gerak Lurus & Hukum Newton',
      description: 'Mempelajari sistem pencernaan, pernapasan, peredaran darah, Hukum I-III Newton, energi potensial/kinetik, dan pesawat sederhana.',
      mainTopics: ['Struktur Sel & Jaringan Tubuh', 'Sistem Pencernaan & Peredaran Darah', 'Hukum Newton & Usaha-Energi', 'Tekanan Zat Cair (Archimedes & Pascal)'],
      expectedCompetencies: ['Menjelaskan mekanisme pertukaran gas di alveolus', 'Menghitung percepatan benda berdasarkan Hukum II Newton', 'Menerapkan prinsip bejana berhubungan dan dongkrak hidrolik']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Kelistrikan, Kemagnetan, Pewarisan Sifat & Ekologi',
      description: 'Hukum Ohm, rangkaian seri-paralel, medan magnet dan motor listrik, hukum Mendel persilangan monohibrid/dihibrid, serta bioteknologi pangan konvensional.',
      mainTopics: ['Listrik Statis & Dinamis (Hukum Ohm)', 'Kemagnetan & Induksi Elektromagnetik', 'Materi Genetik & Pewarisan Sifat Mendel', 'Bioteknologi Konvensional (Tape, Tempe, Yoghurt)'],
      expectedCompetencies: ['Menghitung rekening listrik rumah tangga', 'Membuat diagram persilangan fenotipe dan genotipe', 'Memahami peran mikroorganisme Lactobacillus dalam fermentasi']
    }
  },
  {
    id: 'smp-bahasa-indonesia',
    name: 'Bahasa Indonesia SMP',
    icon: '📚',
    color: 'from-amber-600 to-orange-700',
    accentColor: 'amber',
    description: 'Teks Laporan Hasil Observasi, Fantasi, Prosedur, Puisi Rakyat, Eksplanasi, Ulasan Buku, Cerpen, dan Teks Diskusi Kritis.',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Teks LHO, Cerita Fantasi & Teks Prosedur',
      description: 'Menulis laporan observasi faktual, mengembangkan plot cerita imajinatif, menyusun langkah teks prosedur yang jelas dengan konjungsi temporal.',
      mainTopics: ['Teks Laporan Hasil Observasi (LHO)', 'Struktur & Unsur Cerita Fantasi', 'Teks Prosedur & Kalimat Perintah', 'Teks Berita 5W + 1H'],
      expectedCompetencies: ['Membedakan fakta dan opini dalam laporan', 'Menyusun langkah tutorial dengan bahasa lugas', 'Menulis lead berita yang menarik dan akurat']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Teks Eksplanasi, Resensi Buku, Cerpen & Teks Pidato',
      description: 'Menganalisis sebab-akibat fenomena alam (gempa, pelangi), mengkritik novel/cerpen, menulis cerita pendek beralur kuat, dan berpidato persuasif.',
      mainTopics: ['Teks Eksplanasi Fenomena Alam & Sosial', 'Unsur Intrinsik Cerpen (Alur, Tokoh, Sudut Pandang)', 'Teks Ulasan/Resensi Buku', 'Teks Pidato Persuasif & Retorika'],
      expectedCompetencies: ['Menjelaskan kronologi kausalitas banjir atau gerhana', 'Menilai kelebihan dan kelemahan novel fiksi', 'Menyampaikan pidato dengan intonasi meyakinkan']
    }
  },
  {
    id: 'smp-ips',
    name: 'IPS (Ilmu Pengetahuan Sosial) SMP',
    icon: '🌍',
    color: 'from-emerald-600 to-green-800',
    accentColor: 'emerald',
    description: 'Kondisi geografis Indonesia, interaksi antarruang di ASEAN, dinamika penduduk, lembaga sosial, sejarah kolonialisme & proklamasi kemerdekaan.',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Interaksi Ruang ASEAN, Lembaga Sosial & Permintaan-Penawaran',
      description: 'Mempelajari iklim dan letak astronomis Asia Tenggara, peran keluarga dan lembaga pendidikan, serta hukum kurva permintaan dan penawaran barang.',
      mainTopics: ['Letak Geografis & Geologis Indonesia', 'Profil Negara-Negara Anggota ASEAN', 'Interaksi Sosial & Stratifikasi Masyarakat', 'Pasar, Harga Keseimbangan & Inflasi'],
      expectedCompetencies: ['Membaca peta topografi dan potensi jalur maritim Indonesia', 'Menganalisis dampak kerjasama ekonomi ASEAN', 'Menjelaskan terbentuknya harga pasar dari kurva penawaran']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Sejarah Pergerakan Nasional, Kolonialisme & Globalisasi',
      description: 'Perlawanan terhadap VOC, politik etis, Budi Utomo 1908, Sumpah Pemuda 1928, masa pendudukan Jepang, proklamasi 17 Agustus 1945, dan arus globalisasi.',
      mainTopics: ['Masa Kolonialisme Belanda & VOC', 'Lahirnya Organisasi Pergerakan Nasional', 'Detik-Detik Proklamasi Kemerdekaan 1945', 'Dampak Positif & Negatif Globalisasi'],
      expectedCompetencies: ['Meneladani nilai juang pahlawan nasional', 'Menganalisis strategi diplomasi pasca kemerdekaan', 'Menyaring pengaruh budaya asing dengan kearifan lokal']
    }
  },
  {
    id: 'smp-bahasa-inggris',
    name: 'Bahasa Inggris SMP',
    icon: '🇬🇧',
    color: 'from-cyan-600 to-sky-700',
    accentColor: 'cyan',
    description: 'Descriptive text, Recount text, Narrative text, Procedure text, Simple Past Tense, Present Perfect, Passive Voice, and formal dialogs.',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Descriptive Texts, Simple Past Tense & Recounting Past Events',
      description: 'Mastering adjectives for describing people/places, irregular past verbs (went, saw, ate), writing personal vacation recounts and biographies.',
      mainTopics: ['Describing People, Animals & Historical Landmarks', 'Simple Past vs Present Continuous', 'Recount Text (Orientation, Events, Re-orientation)', 'Expressing Congratulations & Hope'],
      expectedCompetencies: ['Write an engaging recount text about holiday experiences', 'Use regular and irregular past verbs correctly', 'Compliment friends on their achievements']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Narrative Legends, Procedure Recipes & Passive Voice',
      description: 'Reading Indonesian folklore (Malin Kundang, Danau Toba), recipe instructions, giving advice with "should", and understanding passive sentences.',
      mainTopics: ['Narrative Text (Complication & Resolution)', 'Recipe & Manual Procedure Texts', 'Passive Voice in Present & Past Tenses', 'Expressing Agreement and Disagreement'],
      expectedCompetencies: ['Identify moral values in traditional folklore', 'Follow technical cooking and assembling instructions', 'Transform active sentences into passive voice accurately']
    }
  },
  {
    id: 'smp-informatika',
    name: 'Informatika SMP',
    icon: '💻',
    color: 'from-violet-600 to-purple-800',
    accentColor: 'violet',
    description: 'Berpikir komputasional (algoritma & dekomposisi), sistem komputer (hardware & OS), jaringan internet, analisis data spreadsheet, dan pemrograman visual (Scratch/Python).',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Berpikir Komputasional, Hardware & Jaringan Komputer',
      description: 'Latihan logika dekomposisi masalah, fungsi CPU/RAM/Storage, arsitektur sistem operasi, protokol internet (IP, DNS), dan topologi LAN/Wi-Fi.',
      mainTopics: ['4 Pilar Berpikir Komputasional', 'Komponen Perangkat Keras & Lunak', 'Jaringan Komputer & Enkripsi Data', 'Etika Berinternet & Keamanan Siber'],
      expectedCompetencies: ['Menyelesaikan tantangan logika Bebras', 'Menjelaskan alur kerja input-proses-output komputer', 'Melindungi password dan data pribadi dari phising']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Pengolahan Data Excel, Logika Algoritma & Coding Visual',
      description: 'Rumus spreadsheet (SUM, AVERAGE, VLOOKUP, IF), merancang flowchart logika percabangan/perulangan, dan membuat game animasi interaktif.',
      mainTopics: ['Pengolahan Data & Grafik Spreadsheet', 'Notasi Algoritma & Flowchart', 'Pemrograman Visual Scratch / Blockly', 'Dampak Sosial Informatika & AI'],
      expectedCompetencies: ['Mengolah tabel nilai siswa dengan rumus IF dan statistik', 'Merancang flowchart alur program yang valid', 'Membuat game sederhana dengan kontrol sprite dan skor']
    }
  },
  {
    id: 'smp-pendidikan-pancasila',
    name: 'Pendidikan Pancasila SMP',
    icon: '🦅',
    color: 'from-red-600 to-rose-700',
    accentColor: 'red',
    description: 'Sejarah perumusan Pancasila & UUD 1945, norma hukum, kedaulatan rakyat, sistem pemerintahan daerah, dan wawasan nusantara.',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Sidang BPUPKI, Piagam Jakarta & Norma Hukum',
      description: 'Mempelajari perdebatan dasar negara oleh Soekarno, Moh. Yamin, Supomo, penetapan UUD 1945 oleh PPKI, dan jenis norma (agama, kesusilaan, kesopanan, hukum).',
      mainTopics: ['Perumusan Pancasila oleh BPUPKI & PPKI', 'Hierarki Peraturan Perundang-undangan RI', 'Makna Pembukaan UUD NRI 1945', 'Norma & Keadilan dalam Masyarakat'],
      expectedCompetencies: ['Menghargai komitmen para pendiri bangsa', 'Mematuhi tata tertib hukum demi keadilan bersama', 'Menganalisis 4 pokok pikiran Pembukaan UUD 1945']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Kedaulatan Rakyat, Otonomi Daerah & Bela Negara',
      description: 'Sistem pemilu demokratis, pembagian kekuasaan trias politika (eksekutif, legislatif, yudikatif), dan peran pemuda dalam mempertahankan NKRI.',
      mainTopics: ['Lembaga Negara (MPR, DPR, Presiden, MK, MA)', 'Otonomi Daerah & Pemerintahan Lokal', 'Semangat Kebangkitan Nasional 1908', 'Upaya & Hak Warga Negara dalam Bela Negara'],
      expectedCompetencies: ['Memahami mekanisme check and balances lembaga negara', 'Mengapresiasi keunikan potensi daerah sendiri', 'Menerapkan semangat cinta tanah air di kehidupan sekolah']
    }
  },
  {
    id: 'smp-pendidikan-agama',
    name: 'Pendidikan Agama SMP',
    icon: '🕌',
    color: 'from-teal-600 to-green-800',
    accentColor: 'teal',
    description: 'Kajian kitab suci, tajwid/tafsir, akhlak mulia (amanah, istiqamah, rendah hati), sejarah peradaban Islam/sejarah gereja/dhamma, dan fikih muamalah.',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Hukum Bacaan Tajwid, Iman Kepada Kitab & Sifat Amanah',
      description: 'Hukum nun sukun/tanwin dan mad, mengimani kitab Taurat, Zabur, Injil, Al-Qur’an, serta membiasakan sikap jujur dan bertanggung jawab.',
      mainTopics: ['Hukum Bacaan Nun Mati & Mim Mati', 'Iman kepada Kitab-Kitab Suci', 'Perilaku Amanah, Jujur & Istiqamah', 'Tata Cara Shalat Jamak & Qashar'],
      expectedCompetencies: ['Membaca ayat suci dengan kaidah tajwid yang benar', 'Menjadi pribadi yang dapat dipercaya dalam mengemban tugas', 'Mempraktikkan keringanan shalat saat bepergian jauh']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Fikih Makanan Halal, Sejarah Kejayaan & Toleransi',
      description: 'Kriteria makanan/minuman halal dan thoyyib, sejarah peradaban Daulah Umayyah dan Abbasiyah di masa keemasan ilmu pengetahuan, dan moderasi beragama.',
      mainTopics: ['Kriteria Makanan Halal & Menyehatkan', 'Sejarah Keemasan Ilmu Pengetahuan Islam (Baitul Hikmah)', 'Adab Menuntut Ilmu & Menghormati Guru', 'Moderasi Beragama & Perdamaian Dunia'],
      expectedCompetencies: ['Memilih makanan yang halal dan higienis', 'Meneladani dedikasi ilmuwan Ibnu Sina dan Al-Khawarizmi', 'Membangun persaudaraan lintas agama secara harmonis']
    }
  },
  {
    id: 'smp-seni-budaya',
    name: 'Seni Budaya SMP',
    icon: '🎭',
    color: 'from-fuchsia-600 to-purple-700',
    accentColor: 'fuchsia',
    description: 'Seni rupa 2D & 3D (gambar model, ilustrasi, ragam hias), seni musik vokal & ansambel lagu tradisional, seni tari kreasi, dan seni teater.',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Menggambar Model, Ragam Hias & Vokal Bernyanyi Unisono',
      description: 'Teknik proporsi anatomi, gelap terang arsir, motif batik flora/fauna/geometris nusantara, teknik pernapasan diafragma, dan artikulasi vokal.',
      mainTopics: ['Prinsip Menggambar Model & Perspektif', 'Ragam Hias pada Bahan Tekstil & Kayu', 'Teknik Vokal & Bernyanyi Unisono', 'Gerak Dasar Tari Tradisional'],
      expectedCompetencies: ['Menggambar objek dengan arsiran gelap terang yang proporsional', 'Mendesain pola ragam hias batik modern', 'Menyanyikan lagu daerah dengan artikulasi nada presisi']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Seni Grafis Sablon, Musik Tradisional & Pementasan Teater',
      description: 'Cetak tinggi (woodcut/linocut), sablon manual, memainkan instrumen musik tradisional (angklung, gamelan), dan naskah drama pementasan teater.',
      mainTopics: ['Seni Grafis & Cetak Saring (Sablon)', 'Alat Musik Tradisional Nusantara', 'Pola Lantai Tari Kreasi Baru', 'Dasar Pemeranan Pantomim & Drama Teater'],
      expectedCompetencies: ['Mencetak karya seni grafis dengan presisi', 'Memainkan harmonisasi angklung dalam kelompok', 'Mengekspresikan karakter tokoh dalam panggung sandiwara']
    }
  },
  {
    id: 'smp-pjok',
    name: 'PJOK (Pendidikan Jasmani) SMP',
    icon: '🏃',
    color: 'from-emerald-500 to-green-700',
    accentColor: 'emerald',
    description: 'Sepak bola, bola voli, bola basket, bulu tangkis, atletik (lari estafet, tolak peluru), pencak silat, senam aerobik, dan pencegahan bahaya narkoba/rokok.',
    educationLevel: 'SMP',
    grades: [7, 8, 9],
    semester1Syllabus: {
      semester: 1,
      theme: 'Permainan Bola Besar, Atletik Lari & Bela Diri Pencak Silat',
      description: 'Teknik passing/shooting sepak bola, passing atas/bawah bola voli, lay-up basket, start jongkok lari cepat, dan kuda-kuda serta pukulan silat.',
      mainTopics: ['Variasi Teknik Sepak Bola & Bola Voli', 'Lari Jarak Pendek & Lari Estafet', 'Kuda-Kuda & Tangkisan Pencak Silat', 'Komponen Kebugaran Jasmani (Push-up, Sit-up, Beep Test)'],
      expectedCompetencies: ['Menerapkan taktik kerjasama tim dalam voli dan sepak bola', 'Mengukur tingkat VO2Max dengan tes kebugaran berkala', 'Menjunjung tinggi nilai kejujuran wasit dan sportivitas']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Bulu Tangkis, Senam Ritmik, Renang Gaya Dada & Pola Hidup Sehat',
      description: 'Servis forehand/backhand dan smash bulu tangkis, variasi ayunan lengan senam ritmik, koordinasi tarikan kaki renang gaya dada, dan bahaya narkotika.',
      mainTopics: ['Teknik Dasar Bulu Tangkis & Tenis Meja', 'Senam Ritmik Berkelompok Menggunakan Pita/Tali', 'Teknik Renang Gaya Dada & Gaya Bebas', 'Edukasi Pencegahan Rokok, Miras & Narkoba'],
      expectedCompetencies: ['Menguasai pukulan smash tajam dan dropshot akurat', 'Berenang 25 meter gaya dada dengan pernapasan teratur', 'Menjaga pergaulan sehat dan menolak ajakan zat adiktif']
    }
  },

  // ==========================================
  // SMA SUBJECTS (Kelas 10 - 12)
  // ==========================================
  {
    id: 'sma-matematika',
    name: 'Matematika SMA',
    icon: '📐',
    color: 'from-blue-700 to-indigo-900',
    accentColor: 'blue',
    description: 'Eksponen & logaritma, fungsi kuadrat/rasional, trigonometri analitik, limit fungsi, turunan kalkulus, integral, dan matriks.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Fungsi Eksponensial, Logaritma, Trigonometri & Vektor',
      description: 'Persamaan & pertidaksamaan logaritma, identitas sinus/cosinus/tangen, aturan segitiga trigonometri, serta operasi dot/cross product vektor dimensi 2 dan 3.',
      mainTopics: ['Eksponen & Sifat Logaritma Lanjut', 'Sistem Persamaan Tiga Variabel (SPLTV)', 'Trigonometri: Sudut Berelasi & Aturan Sinus/Cosinus', 'Vektor di R2 dan R3'],
      expectedCompetencies: ['Menyelesaikan persamaan logaritma rumit', 'Menghitung tinggi objek tidak terjangkau dengan sudut elevasi', 'Menentukan panjang proyeksi ortogonal antarvektor']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Kalkulus Diferensial, Integral, Matriks & Dimensi Tiga',
      description: 'Membahas limit aljabar & trigonometri, aturan rantai turunan, garis singgung kurva, nilai optimum, integral tentu/tak tentu, determinan matriks, dan jarak titik ke bidang.',
      mainTopics: ['Limit Fungsi Aljabar & Tak Hingga', 'Turunan (Diferensial) & Aplikasi Optimasi Maksimum/Minimum', 'Integral Tak Tentu & Luas Daerah di Bawah Kurva', 'Matriks: Determinan, Invers & Dimensi Tiga (Geometri Ruang)'],
      expectedCompetencies: ['Menemukan biaya minimum atau keuntungan maksimum melalui turunan', 'Menghitung luas daerah tertutup kurva dengan integral tentu', 'Menghitung jarak titik ke garis dan bidang pada kubus']
    }
  },
  {
    id: 'sma-fisika',
    name: 'Fisika SMA',
    icon: '⚡',
    color: 'from-amber-600 to-red-700',
    accentColor: 'amber',
    description: 'Kinematika gerak parabola/melingkar, dinamika rotasi & benda tegar, fluida dinamis, termodinamika, gelombang bunyi & cahaya, fisika kuantum.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Kinematika Vektor, Dinamika Rotasi & Elastisitas Pegas',
      description: 'Analisis gerak peluru parabola, momen inersia dan torsi pada katrol/silinder menggelinding, modulus Young, hukum Hooke susunan pegas seri-paralel.',
      mainTopics: ['Vektor Posisi, Kecepatan & Gerak Parabola', 'Dinamika Rotasi & Kesetimbangan Benda Tegar', 'Hukum Gravitasi Newton & Orbit Planet Kepler', 'Elastisitas & Getaran Harmonik Sederhana'],
      expectedCompetencies: ['Menghitung titik tertinggi dan jangkauan terjauh proyektil', 'Menghitung percepatan sudut silinder pejal menggelinding', 'Menentukan periode ayunan bandul dan frekuensi pegas']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Fluida Dinamis, Termodinamika, Gelombang Bunyi & Cahaya',
      description: 'Persamaan kontinuitas dan Bernoulli, efisiensi mesin Carnot kalor, efek Doppler frekuensi bunyi, difraksi kisi cahaya, dan teori relativitas khusus Einstein.',
      mainTopics: ['Fluida Dinamis: Asas Bernoulli & Tabung Venturi', 'Hukum Termodinamika I & II (Siklus Mesin Carnot)', 'Gelombang Bunyi, Taraf Intensitas & Efek Doppler', 'Optik Fisis: Interferensi Celah Ganda & Kisi Difraksi'],
      expectedCompetencies: ['Menjelaskan gaya angkat sayap pesawat terbang', 'Menghitung efisiensi maksimum mesin pendingin dan pembangkit listrik', 'Menghitung pergeseran frekuensi sirene ambulans bergerak']
    }
  },
  {
    id: 'sma-kimia',
    name: 'Kimia SMA',
    icon: '🧪',
    color: 'from-emerald-600 to-teal-800',
    accentColor: 'emerald',
    description: 'Struktur atom & ikatan kimia, stoikiometri mol, termokimia entalpi, laju reaksi & kesetimbangan, asam-basa, larutan penyangga, elektrokimia, senyawa karbon.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Struktur Atom, Tabel Periodik, Ikatan Kimia & Stoikiometri',
      description: 'Konfigurasi elektron mekanika kuantum, kepolaran molekul, ikatan kovalen/ionik, konsep mol, rumus empiris, dan persamaan reaksi redoks.',
      mainTopics: ['Konfigurasi Elektron & Bilangan Kuantum', 'Ikatan Kimia (Kovalen, Ion, Logam, Ikatan Hidrogen)', 'Hukum Dasar Kimia & Perhitungan Konsep Mol', 'Termokimia: Hukum Hess & Energi Ikatan'],
      expectedCompetencies: ['Memprediksi bentuk geometri molekul berdasarkan teori VSEPR', 'Menghitung massa endapan hasil reaksi stoikiometri larutan', 'Menghitung perubahan entalpi pembakaran menggunakan data entalpi standar']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Laju Reaksi, Kesetimbangan, Asam Basa, Buffer & Redoks Sel Volta',
      description: 'Faktor konsentrasi/suhu/katalis pada laju reaksi, pergeseran Le Chatelier, pH asam kuat/lemah, hidrolisis garam, larutan buffer darah, dan potensial sel baterai.',
      mainTopics: ['Persamaan Laju Reaksi & Orde Reaksi', 'Faktor Pergeseran Kesetimbangan Kimia', 'Asam Basa (Arrhenius, Bronsted-Lowry, Lewis) & pH', 'Larutan Penyangga (Buffer), Hidrolisis & Sel Volta'],
      expectedCompetencies: ['Menentukan orde reaksi total dari data eksperimen konsentrasi', 'Menghitung pH larutan penyangga asam asetat dan natrium asetat', 'Menghitung voltase potensial standar sel elektrokimia baterai']
    }
  },
  {
    id: 'sma-biologi',
    name: 'Biologi SMA',
    icon: '🧬',
    color: 'from-green-600 to-lime-700',
    accentColor: 'green',
    description: 'Keanekaragaman hayati, virus & bakteri, struktur tumbuhan & hewan, fisiologi manusia, metabolisme enzim & respirasi sel, genetika DNA, bioteknologi modern.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Keanekaragaman Hayati, Virus, Bakteri & Enzim Metabolisme',
      description: 'Klasifikasi makhluk hidup 5 kingdom, struktur virus SARS-CoV-2/HIV, reproduksi bakteri, kerja enzim, glikolisis respirasi aerob, dan siklus Krebs.',
      mainTopics: ['Keanekaragaman Hayati Tingkat Gen, Spesies & Ekosistem', 'Struktur & Replikasi Virus (Siklus Litik & Lisogenik)', 'Struktur Sel Hewan & Tumbuhan', 'Enzim & Katabolisme (Glikolisis, Dekarboksilasi, Siklus Krebs)'],
      expectedCompetencies: ['Membedakan fase litik dan lisogenik pada infeksi bakteriofag', 'Menganalisis hasil produksi ATP pada respirasi seluler', 'Menjelaskan peran organel mitokondria dan kloroplas']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Fotosintesis, Sintesis Protein, Hereditas Genetika & Bioteknologi',
      description: 'Reaksi terang & gelap fotosintesis (Siklus Calvin), transkripsi & translasi DNA ke polipeptida, persilangan genetik terpaut kromosom seks, dan rekayasa genetika CRISPR/Plasmid.',
      mainTopics: ['Anabolisme: Reaksi Terang & Siklus Calvin Fotosintesis', 'Sintesis Protein (Transkripsi & Translasi mRNA-tRNA)', 'Pola Hereditas & Penyakit Menurun (Hemofilia, Buta Warna)', 'Bioteknologi Modern: Rekombinasi DNA, Kloning & Kultur Jaringan'],
      expectedCompetencies: ['Menerjemahkan kodon mRNA menjadi urutan asam amino', 'Menghitung peluang keturunan pembawa sifat hemofilia dengan diagram punnett', 'Menjelaskan mekanisme isolasi gen pada pembuatan insulin rekombinan']
    }
  },
  {
    id: 'sma-bahasa-indonesia',
    name: 'Bahasa Indonesia SMA',
    icon: '📚',
    color: 'from-orange-600 to-amber-700',
    accentColor: 'orange',
    description: 'Teks Eksposisi, Teks Anekdot, Cerita Rakyat & Hikayat, Negosiasi, Debat Kritis, Biografi, Resensi Karya Sastra, Artikel Opini Ilmiah, Surat Lamaran Pekerjaan.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Teks Eksposisi, Kritik Sosial Anekdot, Hikayat & Negosiasi',
      description: 'Menyusun argumen tesis eksposisi, menyindir isu publik secara cerdas lewat anekdot, mengonversi hikayat kuno ke cerpen modern, dan strategi tawar-menawar negosiasi.',
      mainTopics: ['Teks Eksposisi & Fakta Penguat Tesis', 'Teks Anekdot & Konjungsi Temporal', 'Nilai Edukatif dalam Hikayat Melayu Klasik', 'Teks Negosiasi & Taktik Capai Kesepakatan Win-Win'],
      expectedCompetencies: ['Menyusun teks eksposisi berbasis data riset valid', 'Menulis naskah komedi kritik sosial yang santun', 'Memimpin perundingan negosiasi dengan etika diplomatis']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Debat Publik, Artikel Opini Media, Resensi Novel & Lamaran Kerja',
      description: 'Menyusun mosi debat, membangun sanggahan logis tanpa falasi, menulis artikel ilmiah populer untuk koran, menulis resensi novel psikologis, dan format surat lamaran profesional.',
      mainTopics: ['Teknik Debat Parlementer & Logika Falasi', 'Kritik Sastra & Esai Opini Budaya', 'Menulis Artikel Opini Ilmiah Populer', 'Surat Lamaran Pekerjaan & CV Standar ATS'],
      expectedCompetencies: ['Menyampaikan argumen pro/kontra secara terstruktur di panggung debat', 'Menulis artikel opini 600 kata dengan gaya jurnalisme bermutu', 'Menyusun surat lamaran kerja formal yang sesuai standar industri']
    }
  },
  {
    id: 'sma-bahasa-inggris',
    name: 'Bahasa Inggris SMA',
    icon: '🇬🇧',
    color: 'from-sky-600 to-indigo-700',
    accentColor: 'sky',
    description: 'Analytical Exposition, Hortatory Exposition, News Item, Explanation Text, Discussion Text, Conditional Sentences (Types 0-3), Subjunctive, and IELTS/TOEFL Prep.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Analytical Exposition, News Report & Conditional Sentences',
      description: 'Crafting persuasive essays with thesis-arguments-reiteration, journalistic headlines, active/passive voice in breaking news, and hypothetical conditionals (If I were you, I would...).',
      mainTopics: ['Analytical Exposition Text Structure', 'News Item & Journalistic Language', 'Conditional Sentences Types 1, 2, and 3', 'Modals of Deduction (Must have, Could have)'],
      expectedCompetencies: ['Write an academic persuasive essay advocating renewable energy', 'Express hypothetical regrets using third conditional grammar', 'Deliver an oral news broadcast with accurate pronunciation']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Explanation of Science Phenomena, Discussion Texts & Reviews',
      description: 'Explaining chain reactions (how tsunamis occur), balancing pros & cons in discussion texts on Artificial Intelligence, film/book reviews, and academic presentation skills.',
      mainTopics: ['Scientific Explanation Texts (Causal Sequences)', 'Discussion Texts: Presenting Two Opposing Views', 'Film & Literary Reviews (Evaluation & Recommendation)', 'Formal Business Letters & Job Applications'],
      expectedCompetencies: ['Deconstruct complicated natural phenomena into clear sequenced paragraphs', 'Evaluate contentious societal debates with balanced neutrality', 'Author a compelling personal statement for university admission']
    }
  },
  {
    id: 'sma-ekonomi',
    name: 'Ekonomi SMA',
    icon: '📈',
    color: 'from-emerald-600 to-green-800',
    accentColor: 'emerald',
    description: 'Kelangkaan & biaya peluang, sistem ekonomi, elastisitas harga, bank sentral & kebijakan moneter, pasar modal, pendapatan nasional (PDB), akuntansi perusahaan jasa & dagang.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Konsep Kelangkaan, Mekanisme Pasar & Kebijakan Moneter-Fiskal',
      description: 'Menghitung opportunity cost, elastisitas permintaan elastis/inelastis, peran Bank Indonesia menjaga stabilitas rupiah, operasi pasar terbuka, dan anggaran APBN.',
      mainTopics: ['Masalah Ekonomi Klasik & Modern (Kelangkaan)', 'Elastisitas Permintaan & Penawaran', 'Bank Sentral, Sistem Pembayaran & Uang Digital', 'Kebijakan Moneter vs Fiskal untuk Pengendalian Inflasi'],
      expectedCompetencies: ['Menghitung koefisien elastisitas harga barang', 'Menganalisis dampak kenaikan suku bunga acuan terhadap investasi', 'Memahami alokasi pendapatan dan belanja negara dalam APBN']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Pendapatan Nasional, Pertumbuhan Ekonomi & Siklus Akuntansi',
      description: 'Menghitung PDB, PNB, NNI, Pendapatan Per Kapita, mengukur kesenjangan Rasio Gini, neraca perdagangan ekspor-impor, jurnal umum, buku besar, dan laporan laba rugi.',
      mainTopics: ['Metode Penghitungan Pendapatan Nasional (PDB/GNP)', 'Pertumbuhan & Pembangunan Ekonomi serta Pengangguran', 'Perdagangan Internasional & Kurs Valuta Asing', 'Siklus Akuntansi Perusahaan Jasa: Jurnal hingga Laporan Keuangan'],
      expectedCompetencies: ['Menghitung Pendapatan Nasional dengan pendekatan pengeluaran dan pendapatan', 'Menganalisis penyebab inflasi dan jenis-jenis pengangguran', 'Menyusun neraca saldo dan laporan laba rugi secara berimbang']
    }
  },
  {
    id: 'sma-sosiologi',
    name: 'Sosiologi SMA',
    icon: '👥',
    color: 'from-amber-600 to-yellow-700',
    accentColor: 'amber',
    description: 'Fungsi sosiologi mengkaji gejala sosial, sosialisasi & pembentukan kepribadian, interaksi & konflik sosial, stratifikasi sosial, perubahan sosial, kearifan lokal.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Objek Kajian Sosiologi, Sosialisasi & Hubungan Sosial',
      description: 'Teori sosiologi Auguste Comte dan Emile Durkheim, agen sosialisasi (keluarga, teman sebaya, media sosial), penyimpangan primer-sekunder, dan dinamika kelompok sosial.',
      mainTopics: ['Sosiologi Sebagai Ilmu Gejala Sosial', 'Agen Sosialisasi & Pembentukan Karakter', 'Penyimpangan Sosial & Pengendalian Sosial', 'Diferensiasi & Stratifikasi Sosial (Kelas Terbuka & Tertutup)'],
      expectedCompetencies: ['Menganalisis fenomena konformitas dan perilaku menyimpang remaja', 'Membedakan sistem stratifikasi kasta tertutup dan kelas terbuka', 'Melakukan observasi sosiologis sederhana di lingkungan tempat tinggal']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Konflik Sosial, Resolusi Damai, Perubahan Sosial & Globalisasi',
      description: 'Faktor pemicu konflik horizontal/vertikal, mediasi & konsiliasi perundingan, teori perubahan sosial siklus dan linier, westernisasi vs modernisasi, serta pelestarian kearifan lokal.',
      mainTopics: ['Faktor Penyebab Konflik Sosial & Kekerasan', 'Bentuk Akomodasi & Resolusi Konflik (Mediasi, Arbitrase)', 'Teori Perubahan Sosial & Dampak Modernisasi', 'Pemberdayaan Komunitas Berbasis Kearifan Lokal'],
      expectedCompetencies: ['Merumuskan langkah mediasi damai saat terjadi perselisihan antarkelompok', 'Menganalisis dampak disrupsi teknologi terhadap pergeseran nilai budaya', 'Mendesain program pelestarian tradisi gotong royong di era digital']
    }
  },
  {
    id: 'sma-geografi',
    name: 'Geografi SMA',
    icon: '🗺️',
    color: 'from-teal-600 to-blue-800',
    accentColor: 'teal',
    description: 'Prinsip & pendekatan geografi, penginderaan jauh & SIG (GIS), litosfer & bencana geologi, atmosfer cuaca-iklim, hidrosfer, biosfer flora-fauna, demografi kependudukan.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Pendekatan Geografi, Peta Citra Satelit & Dinamika Litosfer',
      description: 'Pendekatan keruangan, ekologi, kompleks wilayah, interpretasi foto udara SIG, tektonisme lempeng, vulkanisme erupsi gunung api, gempa bumi seisme, dan erosi tanah.',
      mainTopics: ['10 Konsep Esensial & 4 Prinsip Geografi', 'Pemetaan, Penginderaan Jauh & Sistem Informasi Geografis (SIG)', 'Dinamika Litosfer: Tektonisme, Vulkanisme & Seisme', 'Pedosfer: Lapisan Tanah & Mitigasi Erosi'],
      expectedCompetencies: ['Membaca pola tata guna lahan dari citra satelit Google Earth', 'Menjelaskan mekanisme pembentukan cincin api (Ring of Fire) Indonesia', 'Menyusun rencana mitigasi evakuasi mandiri gempa bumi']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Atmosfer, Iklim Global, Hidrosfer, Bioma & Kependudukan',
      description: 'Klasifikasi iklim Koppen dan Junghuhn, fenomena El Nino/La Nina, siklus hidrologi DAS sungai, bioma tundra/taiga/hutan hujan tropis, piramida penduduk dan bonus demografi.',
      mainTopics: ['Dinamika Atmosfer: Unsur Cuaca & Klasifikasi Iklim', 'Hidrosfer: Daerah Aliran Sungai (DAS) & Arus Laut', 'Persebaran Flora & Fauna di Indonesia (Garis Wallace-Weber)', 'Dinamika Antroposfer: Migrasi, Kualitas Hidup & Bonus Demografi'],
      expectedCompetencies: ['Memprediksi pola musim tanam berdasarkan pergeseran angin monsun', 'Menganalisis karakteristik fauna tipe Asiatis, Peralihan, dan Australis', 'Menghitung sex ratio dan angka beban ketergantungan (dependency ratio)']
    }
  },
  {
    id: 'sma-sejarah',
    name: 'Sejarah SMA',
    icon: '🏛️',
    color: 'from-amber-700 to-stone-800',
    accentColor: 'amber',
    description: 'Konsep dasar ilmu sejarah, masa praaksara, kerajaan Hindu-Buddha & Islam di Nusantara, masa penjajahan bangsa Eropa, revolusi kemerdekaan, Orde Lama, Orde Baru, & Reformasi.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Metodologi Sejarah, Masa Praaksara & Kerajaan Maritim Nusantara',
      description: 'Konsep berpikir diakronik/sinkronik, kritik sumber primer-sekunder, peninggalan fosil manusia purba, kejayaan maritim Sriwijaya, Majapahit, Samudera Pasai, dan Kesultanan Mataram.',
      mainTopics: ['Konsep Berpikir Diakronik, Sinkronik, Kausalitas & Kronologis', 'Corak Kehidupan Manusia Purba di Indonesia', 'Kejayaan Kerajaan Hindu-Buddha (Kutai, Sriwijaya, Majapahit)', 'Masuk & Berkembangnya Islam Serta Kesultanan Nusantara'],
      expectedCompetencies: ['Memverifikasi keaslian prasasti dan dokumen arsip kuno', 'Menjelaskan peran Sumpah Palapa Gajah Mada dalam penyatuan nusantara', 'Menganalisis jalur sutra maritim perdagangan rempah-rempah internasional']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Pergerakan Nasional, Proklamasi, Diplomasi Revolusi & Era Reformasi',
      description: 'Lahirnya kesadaran kebangsaan 1908, pendudukan militer Jepang 1942, diplomasi Linggarjati & Renville, Konferensi Meja Bundar (KMB), Demokrasi Parlementer/Terpimpin, hingga Reformasi 1998.',
      mainTopics: ['Politik Etis & Kebangkitan Nasional (Budi Utomo & Sarekat Islam)', 'Peristiwa Rengasdengklok & Makna Proklamasi 17 Agustus 1945', 'Perjuangan Fisik & Diplomasi Mempertahankan Kemerdekaan', 'Dinamika Politik Indonesia dari Orde Lama, Orde Baru, hingga Reformasi'],
      expectedCompetencies: ['Menganalisis strategi pemuda saat mendesak percepatan proklamasi', 'Menilai keunggulan jalur diplomasi KMB dalam pengakuan kedaulatan RI', 'Merefleksikan agenda demokratisasi dan kebebasan pers pasca reformasi 1998']
    }
  },
  {
    id: 'sma-informatika',
    name: 'Informatika SMA',
    icon: '💻',
    color: 'from-indigo-600 to-purple-900',
    accentColor: 'indigo',
    description: 'Algoritma lanjut (sorting, searching, greedy, dynamic programming), struktur data (array, stack, queue, tree), pemrograman Python, basis data SQL, kecerdasan buatan (AI) & siber.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Berpikir Komputasional Lanjut, Struktur Data & Pemrograman Python',
      description: 'Menganalisis efisiensi algoritma Big-O, implementasi Stack (LIFO) dan Queue (FIFO), fungsi rekursif, pengurutan Quick Sort/Merge Sort, dan pemrograman modular Python.',
      mainTopics: ['Kompleksitas Waktu Algoritma (Notasi Big-O)', 'Struktur Data Linear: Array, List, Stack & Queue', 'Algoritma Pengurutan (Merge Sort, Binary Search)', 'Pemrograman Python: Fungsi, Looping & Penanganan Error'],
      expectedCompetencies: ['Memilih struktur data yang optimal untuk efisiensi memori program', 'Mengimplementasikan pencarian Binary Search pada dataset besar', 'Menulis script otomasi Python yang bersih dan minim bug']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Basis Data Relasional SQL, Rekayasa Web, AI & Keamanan Siber',
      description: 'Merancang Entity Relationship Diagram (ERD), query SELECT/JOIN/GROUP BY SQL, pengenalan Machine Learning (klasifikasi data), dan kriptografi enkripsi AES/RSA.',
      mainTopics: ['Model Data Relasional & Perancangan ERD', 'Bahasa Query SQL (DDL, DML, INNER JOIN, Aggregate)', 'Pengenalan Machine Learning & Klasifikasi Dataset', 'Kriptografi, Hash MD5/SHA256 & Etika AI'],
      expectedCompetencies: ['Membuat database tabel siswa dan relasi nilai dengan SQL', 'Mengevaluasi akurasi model machine learning pada dataset prediksi', 'Memahami pentingnya enkripsi end-to-end dalam melindungi privasi pengguna']
    }
  },
  {
    id: 'sma-pendidikan-pancasila',
    name: 'Pendidikan Pancasila SMA',
    icon: '🦅',
    color: 'from-rose-600 to-red-800',
    accentColor: 'rose',
    description: 'Nilai praksis Pancasila menghadapi tantangan global, perlindungan HAM, sistem peradilan di Indonesia, integrasi nasional, dan budaya demokrasi konstitusional.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Nilai Instrumental & Praksis Pancasila Serta Penegakan HAM',
      description: 'Menganalisis kasus pelanggaran HAM berat, upaya Komnas HAM, peran aparat penegak hukum (Polisi, Jaksa, Hakim, Advokat, KPK), dan budaya taat hukum.',
      mainTopics: ['Nilai Dasar, Instrumental & Praksis Sila-Sila Pancasila', 'Substansi & Upaya Penegakan Hak Asasi Manusia (HAM)', 'Sistem Peradilan Nasional & Lembaga Peradilan di Indonesia', 'Pencegahan Tindak Pidana Korupsi & Transparansi'],
      expectedCompetencies: ['Mengidentifikasi solusi penanganan kasus intoleransi dengan nilai Pancasila', 'Memahami alur proses peradilan pidana dan perdata di pengadilan', 'Menolak segala bentuk gratifikasi dan budaya korupsi sejak dini']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Integrasi Nasional, Ancaman IPOLEKSOSBUDHANKAM & Hubungan Internasional',
      description: 'Strategi menghadapi ancaman ideologi, politik, ekonomi, sosial budaya, dan pertahanan keamanan; politik luar negeri bebas aktif RI; dan peran di PBB & ASEAN.',
      mainTopics: ['Dinamika Persatuan & Kesatuan Bangsa dalam NKRI', 'Strategi Mengatasi Ancaman IPOLEKSOSBUDHANKAM', 'Politik Luar Negeri Bebas Aktif Indonesia', 'Peran Indonesia dalam Menciptakan Perdamaian Dunia (PBB & GNB)'],
      expectedCompetencies: ['Menganalisis potensi disintegrasi bangsa dan solusi penguatannya', 'Menjelaskan kontribusi Pasukan Garuda RI dalam misi perdamaian PBB', 'Menunjukkan sikap nasionalisme yang terbuka dan berwawasan global']
    }
  },
  {
    id: 'sma-pendidikan-agama',
    name: 'Pendidikan Agama SMA',
    icon: '🕌',
    color: 'from-teal-700 to-green-900',
    accentColor: 'teal',
    description: 'Kajian ayat berpikir kritis dan toleransi, beriman kepada qada & qadar, etika pergaulan Islami, hukum pernikahan & waris, kejayaan dakwah Islam rahmatan lil alamin.',
    educationLevel: 'SMA',
    grades: [10, 11, 12],
    semester1Syllabus: {
      semester: 1,
      theme: 'Berpikir Kritis, Moderasi Agama, Iman Hari Akhir & Qada Qadar',
      description: 'Tadabbur QS Ali Imran 190-191 tentang penciptaan alam semesta, membina sikap toleran QS Yunus 40-41, mengimani takdir mubram dan muallaq, dan etika berkomunikasi di medsos.',
      mainTopics: ['Kajian Ayat Berpikir Kritis & Sikap Demokratis', 'Prinsip Toleransi & Kerukunan Beragama', 'Iman kepada Hari Kiamat & Hikmahnya', 'Iman kepada Qada dan Qadar (Ikhtiar & Tawakal)'],
      expectedCompetencies: ['Mengembangkan nalar ilmiah yang selaras dengan nilai spiritual', 'Mempraktikkan toleransi nyata tanpa mencampuradukkan akidah', 'Menunjukkan etos kerja keras dengan tetap berpasrah pada ketentuan Tuhan']
    },
    semester2Syllabus: {
      semester: 2,
      theme: 'Fikih Munakahat (Pernikahan), Mawaris (Hukum Waris) & Dakwah Rahmatan Lil Alamin',
      description: 'Syarat rukun pernikahan sakinah mawaddah warahmah, asas keadilan pembagian harta waris, strategi dakwah Walisongo di Jawa, dan kontribusi muslim bagi peradaban dunia.',
      mainTopics: ['Ketentuan Pernikahan dalam Fikih Islam (Munakahat)', 'Dasar-Dasar Pembagian Warisan (Faraid / Mawaris)', 'Sejarah Perkembangan Islam di Nusantara (Metode Walisongo)', 'Islam sebagai Rahmatan Lil Alamin Menolak Ekstremisme'],
      expectedCompetencies: ['Memahami hak dan kewajiban dalam membangun keluarga berkarakter mulia', 'Menghitung simulasi pembagian waris keluarga secara proporsional', 'Meneladani kearifan dakwah kultural para ulama nusantara']
    }
  }
];

// Helper functions
export function getSubjectsByEducationLevel(level: EducationLevel): Subject[] {
  return SUBJECTS.filter(s => s.educationLevel === level);
}

export function getSubjectsByGrade(grade: number): Subject[] {
  return SUBJECTS.filter(s => s.grades.includes(grade));
}

export function getSubjectById(subjectId: string): Subject | undefined {
  return SUBJECTS.find(s => s.id === subjectId);
}
