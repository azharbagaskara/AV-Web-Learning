import { Topic } from '../types';

export const TOPICS: Topic[] = [
  // ==========================================
  // SD MATEMATIKA (Kelas 1-6)
  // ==========================================
  {
    id: 'sd-mat-bilangan-cacah',
    title: 'Bilangan Cacah & Nilai Tempat',
    description: 'Mengenal konsep angka, nilai tempat (satuan, puluhan, ratusan, ribuan), dan perbandingan besar-kecil bilangan.',
    subjectId: 'sd-matematika',
    grade: 3,
    semester: 1,
    difficulty: 'mudah',
    estimatedMinutes: 12,
    explanation: 'Bilangan cacah adalah himpunan bilangan bulat yang tidak negatif, yaitu dimulai dari angka 0, 1, 2, 3, 4, 5, dan seterusnya. Dalam sistem desimal yang kita gunakan sehari-hari, posisi setiap angka menentukan nilainya (nilai tempat). Misalnya pada angka 3.425, angka 3 bernilai tiga ribuan (3.000), 4 bernilai empat ratusan (400), 2 bernilai dua puluhan (20), dan 5 bernilai lima satuan (5).',
    coreConcepts: [
      {
        title: 'Pengertian Nilai Tempat',
        description: 'Nilai suatu angka bergantung pada letak posisinya dalam suatu bilangan.',
        example: 'Pada bilangan 7.821: Angka 7 = Ribuan (7.000), Angka 8 = Ratusan (800), Angka 2 = Puluhan (20), Angka 1 = Satuan (1).'
      },
      {
        title: 'Membandingkan Bilangan',
        description: 'Bandingkan mulai dari nilai tempat paling kiri (terbesar). Gunakan tanda > (lebih besar), < (lebih kecil), atau = (sama dengan).',
        example: '4.520 > 4.390 (karena ratusan 5 lebih besar dari ratusan 3).'
      }
    ],
    realWorldExample: 'Saat kamu berbelanja di minimarket, kamu membandingkan harga snack Rp 4.500 dan Rp 3.800. Karena nilai ribuan 4 lebih besar dari 3, snack pertama lebih mahal.',
    summary: [
      'Bilangan cacah dimulai dari 0 hingga tak terhingga.',
      'Urutan nilai tempat dari kanan ke kiri: Satuan, Puluhan, Ratusan, Ribuan, Puluh Ribuan.',
      'Tanda > berarti lebih besar, < berarti lebih kecil.'
    ],
    studyTips: 'Tuliskan angka dalam tabel kolom nilai tempat agar tidak keliru saat menjumlahkan bersusun!'
  },
  {
    id: 'sd-mat-pecahan-sederhana',
    title: 'Pecahan Sederhana & Pecahan Senilai',
    description: 'Memahami pembilang dan penyebut, membagi benda secara merata, serta membandingkan pecahan senilai.',
    subjectId: 'sd-matematika',
    grade: 4,
    semester: 2,
    difficulty: 'sedang',
    estimatedMinutes: 15,
    explanation: 'Pecahan digunakan untuk menyatakan bagian dari keseluruhan. Dituliskan dalam bentuk a/b, di mana angka di atas (a) disebut Pembilang dan angka di bawah (b) disebut Penyebut (tidak boleh 0). Jika sebuah pizza dibagi menjadi 4 bagian sama besar dan kamu memakan 1 potong, maka kamu telah memakan 1/4 bagian pizza tersebut.',
    coreConcepts: [
      {
        title: 'Pembilang dan Penyebut',
        description: 'Pembilang menunjukkan jumlah bagian yang diambil, Penyebut menunjukkan total seluruh bagian sama rata.',
        example: '3/8 artinya 3 bagian dari total 8 bagian.'
      },
      {
        title: 'Pecahan Senilai',
        description: 'Pecahan senilai diperoleh dengan mengalikan atau membagi pembilang dan penyebut dengan angka yang sama.',
        example: '1/2 senilai dengan 2/4 dan 4/8 karena (1x2)/(2x2) = 2/4.'
      }
    ],
    realWorldExample: 'Ibu memotong martabak manis menjadi 8 potong sama besar. Kakak makan 2 potong (2/8) dan adik makan 1 potong (1/8). Kakak makan lebih banyak dari adik.',
    summary: [
      'Bentuk pecahan adalah a/b (a = pembilang, b = penyebut).',
      'Untuk mencari pecahan senilai, kalikan pembilang dan penyebut dengan bilangan bulat yang sama.',
      'Menyederhanakan pecahan dilakukan dengan membagi FPB pembilang dan penyebut.'
    ],
    studyTips: 'Bayangkan pecahan sebagai potongan kue ulang tahun atau pizza agar visualisasinya mudah dipahami!'
  },

  // ==========================================
  // SD IPAS
  // ==========================================
  {
    id: 'sd-ipas-fotosintesis',
    title: 'Fotosintesis: Dapur Ajaib Tumbuhan',
    description: 'Bagaimana daun hijau mengolah sinar matahari, air, dan karbon dioksida menjadi glukosa dan oksigen segar.',
    subjectId: 'sd-ipas',
    grade: 4,
    semester: 1,
    difficulty: 'mudah',
    estimatedMinutes: 14,
    explanation: 'Tumbuhan adalah makhluk hidup autotrof yang dapat memasak makanannya sendiri melalui proses fotosintesis. Proses ini berlangsung di kloroplas yang mengandung pigmen hijau daun (klorofil). Daun menyerap karbon dioksida (CO2) dari udara dan air (H2O) yang diserap akar dari tanah. Dengan bantuan cahaya matahari, tumbuhan menghasilkan makanan berupa glukosa (zat gula/energi) dan gas oksigen (O2) yang dihirup manusia dan hewan.',
    coreConcepts: [
      {
        title: 'Bahan Baku Fotosintesis',
        description: 'Air (H2O) dari tanah + Karbon Dioksida (CO2) dari udara + Cahaya Matahari + Klorofil.',
        example: 'Reaksi: 6CO2 + 6H2O + Sinar Matahari -> C6H12O6 (Glukosa) + 6O2 (Oksigen).'
      },
      {
        title: 'Peran Klorofil',
        description: 'Klorofil adalah zat hijau daun yang berfungsi menangkap energi gelombang cahaya matahari.',
        example: 'Daun yang tertutup sinar matahari dalam waktu lama akan menjadi pucat dan layu karena tidak bisa berfotosintesis.'
      }
    ],
    realWorldExample: 'Saat kita berteduh di bawah pohon rindang pada siang hari, udara terasa sangat sejuk karena pohon sedang aktif mengeluarkan gas oksigen segar hasil fotosintesis.',
    summary: [
      'Fotosintesis terjadi pada bagian tumbuhan yang berklorofil (terutama daun).',
      'Hasil fotosintesis adalah glukosa (cadangan makanan) dan oksigen (O2).',
      'Tumbuhan menjadi produsen utama dalam rantai makanan bumi.'
    ],
    studyTips: 'Ingat singkatan: Air + Udara (CO2) + Matahari = Makanan Pohon + Nafas Segar (O2)!'
  },
  {
    id: 'sd-ipas-siklus-air',
    title: 'Siklus Air & Kelestarian Lingkungan',
    description: 'Proses perputaran air di bumi: evaporasi, kondensasi, presipitasi, dan infiltrasi tanpa pernah habis.',
    subjectId: 'sd-ipas',
    grade: 5,
    semester: 2,
    difficulty: 'sedang',
    estimatedMinutes: 12,
    explanation: 'Jumlah air di bumi sebenarnya relatif tetap karena mengalami siklus hidrologi yang berputar terus-menerus. Air laut, sungai, dan danau menguap karena panas matahari (Evaporasi). Tumbuhan juga menguapkan air (Transpirasi). Uap air naik dan mendingin membentuk awan (Kondensasi). Ketika awan sudah jenuh dan berat, butiran air jatuh ke bumi sebagai hujan (Presipitasi). Air hujan kemudian meresap ke dalam tanah (Infiltrasi) dan mengalir kembali ke sungai dan laut.',
    coreConcepts: [
      {
        title: '4 Tahap Utama Siklus Air',
        description: '1. Evaporasi/Transpirasi (Penguapan), 2. Kondensasi (Pengembunan jadi awan), 3. Presipitasi (Turun hujan), 4. Infiltrasi (Penyerapan air ke tanah).',
        example: 'Membentuk awan mendung di langit adalah contoh fase kondensasi uap air.'
      }
    ],
    realWorldExample: 'Air hujan yang membasahi halaman rumahmu sebagian menguap kembali saat terik dan sebagian meresap ke sumur yang kamu gunakan untuk mandi.',
    summary: [
      'Siklus air menjaga ketersediaan air tawar di daratan bumi.',
      'Hutan lebat berperan penting dalam proses infiltrasi dan mencegah banjir.',
      'Menghemat air dan menanam pohon membantu menjaga siklus air tetap stabil.'
    ],
    studyTips: 'Ingat urutannya: Menguap (Naik) -> Mengembun (Awan) -> Hujan (Turun) -> Meresap (Tanah).'
  },

  // ==========================================
  // SMP MATEMATIKA (Kelas 7 - 9)
  // ==========================================
  {
    id: 'smp-mat-pythagoras',
    title: 'Teorema Pythagoras & Tripel Pythagoras',
    description: 'Hubungan kuadrat sisi miring (hipotenusa) dengan kuadrat kedua sisi siku-siku pada segitiga siku-siku.',
    subjectId: 'smp-matematika',
    grade: 8,
    semester: 1,
    difficulty: 'sedang',
    estimatedMinutes: 16,
    explanation: 'Teorema Pythagoras menyatakan bahwa pada setiap segitiga siku-siku, kuadrat panjang sisi miring (hipotenusa, sisi terpanjang di depan sudut 90 derajat) sama dengan jumlah kuadrat panjang kedua sisi penyikunya. Rumus umumnya: c² = a² + b², di mana c adalah sisi miring, sedangkan a dan b adalah sisi-sisi tegak siku-sikunya.',
    coreConcepts: [
      {
        title: 'Rumus Pythagoras',
        description: 'c² = a² + b² → c = √(a² + b²). Untuk mencari sisi tegak: a² = c² - b².',
        example: 'Jika a = 3 cm dan b = 4 cm, maka c² = 3² + 4² = 9 + 16 = 25. c = √25 = 5 cm.'
      },
      {
        title: 'Tripel Pythagoras Populer',
        description: 'Kombinasi 3 bilangan bulat yang memenuhi teorema Pythagoras: (3, 4, 5), (5, 12, 13), (7, 24, 25), (8, 15, 17) serta kelipatannya.',
        example: 'Kelipatan dari (3, 4, 5) x 2 = (6, 8, 10) juga pasti segitiga siku-siku.'
      }
    ],
    realWorldExample: 'Tukang bangunan menyandarkan tangga sepanjang 5 meter pada dinding rumah setinggi 4 meter. Jarak kaki tangga ke dinding adalah √(5² - 4²) = √(25 - 16) = √9 = 3 meter.',
    summary: [
      'Berlaku HANYA pada segitiga siku-siku (sudut 90°).',
      'Sisi miring (hipotenusa) selalu sisi yang terpanjang.',
      'c² = a² + b² (mencari miring), a² = c² - b² (mencari sisi tegak).'
    ],
    studyTips: 'Hafalkan tripel dasar (3,4,5) dan (5,12,13) untuk menghemat waktu berhitung saat kuis!'
  },
  {
    id: 'smp-mat-spldv',
    title: 'Sistem Persamaan Linear Dua Variabel (SPLDV)',
    description: 'Metode eliminasi, substitusi, dan gabungan untuk mencari nilai x dan y pada dua persamaan simultan.',
    subjectId: 'smp-matematika',
    grade: 8,
    semester: 1,
    difficulty: 'sulit',
    estimatedMinutes: 18,
    explanation: 'SPLDV adalah sistem yang terdiri dari dua persamaan linear yang memiliki dua variabel berpangkat satu (misalnya x dan y). Solusi dari SPLDV adalah pasangan nilai (x, y) yang memenuhi kedua persamaan secara bersamaan. Ada 3 metode utama untuk menyelesaikannya: Metode Substitusi (mengganti variabel), Metode Eliminasi (menghilangkan salah satu variabel), dan Metode Gabungan (Eliminasi lalu Substitusi).',
    coreConcepts: [
      {
        title: 'Bentuk Umum SPLDV',
        description: 'a1·x + b1·y = c1 dan a2·x + b2·y = c2.',
        example: 'Persamaan 1: 2x + y = 8. Persamaan 2: x - y = 1.'
      },
      {
        title: 'Metode Gabungan (Paling Cepat)',
        description: '1. Samakan koefisien salah satu variabel. 2. Jumlahkan/kurangkan untuk mengeliminasi. 3. Masukkan hasilnya ke persamaan awal.',
        example: 'Dari 2x+y=8 dan x-y=1: Jumlahkan kedua persamaan -> 3x = 9 -> x = 3. Substitusi ke x-y=1 -> 3-y=1 -> y = 2. Himpunan Penyelesaian = {(3, 2)}.'
      }
    ],
    realWorldExample: 'Andi membeli 2 buku dan 1 pensil seharga Rp 8.000. Budi membeli 1 buku dan 1 pensil seharga Rp 5.000. Dengan SPLDV, kita tahu harga 1 buku = Rp 3.000 dan 1 pensil = Rp 2.000.',
    summary: [
      'SPLDV memiliki 2 persamaan dan 2 variabel.',
      'Metode gabungan (eliminasi + substitusi) adalah cara paling praktis.',
      'Titik potong grafik kedua garis merupakan solusi (x, y) dari sistem.'
    ],
    studyTips: 'Cari variabel yang koefisiennya 1 atau -1 terlebih dahulu agar eliminasi/substitusi lebih mudah tanpa pecahan!'
  },
  {
    id: 'smp-mat-statistika',
    title: 'Statistika: Mean, Median, Modus & Kuartil',
    description: 'Ukuran pemusatan data: mencari nilai rata-rata, nilai tengah data berurutan, dan nilai yang paling sering muncul.',
    subjectId: 'smp-matematika',
    grade: 8,
    semester: 2,
    difficulty: 'mudah',
    estimatedMinutes: 14,
    explanation: 'Statistika membantu kita menyajikan dan menyimpulkan sekumpulan data angka. Tiga ukuran pemusatan utama adalah: 1. Mean (Rata-rata): Jumlah seluruh data dibagi banyaknya data. 2. Median (Nilai tengah): Nilai yang berada tepat di tengah setelah semua data diurutkan dari terkecil ke terbesar. 3. Modus (Nilai paling sering): Angka yang memiliki frekuensi kemunculan tertinggi.',
    coreConcepts: [
      {
        title: 'Rumus Mean',
        description: 'Mean = (Jumlah Semua Nilai) / (Banyak Data).',
        example: 'Data: 6, 7, 8, 8, 9, 10. Mean = (6+7+8+8+9+10)/6 = 48/6 = 8.'
      },
      {
        title: 'Menentukan Median & Modus',
        description: 'Median: urutkan data dulu. Jika genap, rata-ratakan 2 angka di tengah. Modus: angka terbanyak.',
        example: 'Data: 4, 5, 7, 7, 7, 8, 9. Median = 7 (angka ke-4). Modus = 7 (muncul 3 kali).'
      }
    ],
    realWorldExample: 'Guru menghitung nilai rata-rata ulangan harian kelas 8B untuk mengetahui apakah sebagian besar siswa sudah mencapai standar KKM kelulusan.',
    summary: [
      'Selalu urutkan data dari yang terkecil sebelum mencari Median.',
      'Modus bisa lebih dari satu atau tidak ada sama sekali jika semua frekuensi sama.',
      'Mean sangat dipengaruhi oleh nilai ekstrem (angka yang terlalu besar/kecil).'
    ],
    studyTips: 'Coret angka dari kiri dan kanan secara berpasangan saat mencari median data ganjil!'
  },

  // ==========================================
  // SMP IPA (Fisika & Biologi)
  // ==========================================
  {
    id: 'smp-ipa-hukum-newton',
    title: 'Hukum Gerak Newton (I, II, III)',
    description: 'Konsep inersia kelembaman, gaya dan percepatan (F = m · a), serta aksi-reaksi pada gaya interaksi benda.',
    subjectId: 'smp-ipa',
    grade: 8,
    semester: 1,
    difficulty: 'sedang',
    estimatedMinutes: 15,
    explanation: 'Sir Isaac Newton merumuskan 3 hukum fundamental tentang gerak benda: 1. Hukum I Newton (Hukum Kelembaman/Inersia): Benda cenderung mempertahankan keadaannya (diam tetap diam, bergerak lurus beraturan tetap bergerak) jika resultan gaya sama dengan nol (ΣF = 0). 2. Hukum II Newton: Percepatan berbanding lurus dengan resultan gaya dan berbanding terbalik dengan massa benda (ΣF = m · a). 3. Hukum III Newton (Aksi-Reaksi): Jika benda A memberi gaya pada benda B, maka benda B memberi gaya yang sama besar namun berlawanan arah pada benda A (F_aksi = -F_reaksi).',
    coreConcepts: [
      {
        title: 'Hukum I Newton (ΣF = 0)',
        description: 'Benda mempertahankan posisi diam atau gerak lurus konstan tanpa percepatan.',
        example: 'Tubuh kita terdorong ke depan saat mobil yang melaju kencang tiba-tiba direm mendadak.'
      },
      {
        title: 'Hukum II Newton (F = m · a)',
        description: 'Semakin besar gaya dorong, semakin cepat percepatan benda. Semakin berat benda, percepatannya semakin kecil.',
        example: 'Gaya F = 20 N mendorong troli bermassa m = 4 kg menghasilkan percepatan a = F/m = 20/4 = 5 m/s².'
      },
      {
        title: 'Hukum III Newton (F_aksi = -F_reaksi)',
        description: 'Gaya selalu terjadi berpasangan pada dua benda berbeda dengan arah berlawanan.',
        example: 'Saat mendayung perahu ke belakang (aksi), perahu meluncur maju ke depan (reaksi).'
      }
    ],
    realWorldExample: 'Roket luar angkasa bisa meluncur ke atas karena semburan gas panas bertekanan tinggi mendorong kuat ke bawah (Gaya Aksi-Reaksi Hukum III Newton).',
    summary: [
      'Hukum I: Kelembaman (Inersia), ΣF = 0.',
      'Hukum II: Hubungan Gaya, Massa, Percepatan (F = m · a).',
      'Hukum III: Aksi = -Reaksi (besar sama, arah berlawanan, pada 2 benda berbeda).'
    ],
    studyTips: 'Ingat bahwa gaya aksi dan reaksi bekerja pada DUA benda yang berbeda, sehingga tidak saling meniadakan!'
  },
  {
    id: 'smp-ipa-listrik-dinamis',
    title: 'Listrik Dinamis & Hukum Ohm',
    description: 'Arus listrik, beda potensial (tegangan), hambatan kawat, dan rangkaian seri serta paralel.',
    subjectId: 'smp-ipa',
    grade: 9,
    semester: 2,
    difficulty: 'sedang',
    estimatedMinutes: 16,
    explanation: 'Listrik dinamis adalah muatan listrik yang bergerak atau mengalir melalui konduktor dalam suatu rangkaian tertutup. Kuat arus listrik (I, Ampere) mengalir dari kutub positif ke kutub negatif. Hukum Ohm menyatakan bahwa besar kuat arus listrik sebanding dengan beda potensial (V, Volt) dan berbanding terbalik dengan hambatan (R, Ohm). Rumus: V = I · R.',
    coreConcepts: [
      {
        title: 'Segitiga Rumus Hukum Ohm',
        description: 'V = I · R | I = V / R | R = V / I.',
        example: 'Sebuah lampu memiliki hambatan R = 20 Ω dihubungkan ke baterai 12 V. Kuat arusnya I = 12 / 20 = 0,6 A.'
      },
      {
        title: 'Rangkaian Seri vs Paralel',
        description: 'Seri: Arus listrik sama di semua titik, hambatan bertambah (R_total = R1 + R2). Paralel: Tegangan sama di setiap cabang (1/R_total = 1/R1 + 1/R2).',
        example: 'Instalasi listrik rumah tangga dipasang secara paralel agar jika satu lampu padam, lampu lain tetap menyala.'
      }
    ],
    realWorldExample: 'Ketika baterai HP kita hampir habis, resistor di dalam adaptor charger mengatur arus listrik yang aman agar baterai tidak overheat saat dicas.',
    summary: [
      'Hukum Ohm: V = I · R (Volt = Ampere x Ohm).',
      'Rangkaian paralel menjaga tegangan tetap sama di semua alat elektronik rumah.',
      'Alat ukur Voltmeter dipasang paralel, Amperemeter dipasang seri.'
    ],
    studyTips: 'Gunakan segitiga V di puncak, I dan R di bawah: tutup huruf yang ingin kamu hitung untuk menemukan rumusnya!'
  },

  // ==========================================
  // SMP INFORMATIKA
  // ==========================================
  {
    id: 'smp-inf-berpikir-komputasional',
    title: '4 Pilar Berpikir Komputasional',
    description: 'Dekomposisi, Pengenalan Pola, Abstraksi, dan Perancangan Algoritma untuk menyelesaikan masalah secara sistematis.',
    subjectId: 'smp-informatika',
    grade: 7,
    semester: 1,
    difficulty: 'mudah',
    estimatedMinutes: 13,
    explanation: 'Berpikir Komputasional (Computational Thinking) adalah cara berpikir logis untuk memecahkan masalah rumit dengan metode yang juga digunakan oleh komputer. Ada 4 pilar utama: 1. Dekomposisi: Memecah masalah besar menjadi bagian-bagian kecil yang lebih mudah dikelola. 2. Pengenalan Pola: Melihat kesamaan atau tren dari masalah terdahulu. 3. Abstraksi: Memilah informasi penting dan mengabaikan detail yang tidak relevan. 4. Algoritma: Menyusun langkah-langkah terurut yang logis untuk menyelesaikan masalah.',
    coreConcepts: [
      {
        title: 'Pilar 1: Dekomposisi',
        description: 'Memecah target besar menjadi sub-tugas kecil.',
        example: 'Membuat aplikasi toko online dipecah menjadi: sistem login, keranjang belanja, katalog produk, dan pembayaran.'
      },
      {
        title: 'Pilar 3: Abstraksi',
        description: 'Hanya fokus pada inti informasi penting.',
        example: 'Peta rute MRT hanya menampilkan stasiun pemberhentian dan jalur, tanpa menggambar pepohonan atau gedung di sekitarnya.'
      }
    ],
    realWorldExample: 'Saat merencanakan liburan sekolah bersama keluarga, kamu menyusun anggaran, rute perjalanan, jadwal hotel, dan daftar perlengkapan secara sistematis.',
    summary: [
      'Dekomposisi = Pecah menjadi kecil.',
      'Pengenalan Pola = Cari kemiripan.',
      'Abstraksi = Ambil intinya saja, buang detail tak penting.',
      'Algoritma = Langkah runtut terurut.'
    ],
    studyTips: 'Latihan soal logika Bebras adalah cara terbaik mengasah 4 pilar berpikir komputasional!'
  },

  // ==========================================
  // SMA MATEMATIKA (Kelas 10-12)
  // ==========================================
  {
    id: 'sma-mat-turunan-kalkulus',
    title: 'Turunan Fungsi Aljabar (Diferensial) & Optimasi',
    description: 'Aturan pangkat d/dx(x^n) = n·x^(n-1), turunan perkalian/pembagian, serta aplikasi mencari nilai maksimum dan minimum.',
    subjectId: 'sma-matematika',
    grade: 11,
    semester: 2,
    difficulty: 'sulit',
    estimatedMinutes: 20,
    explanation: 'Turunan (diferensial) menyatakan laju perubahan sesaat suatu fungsi f(x) terhadap variabel x. Secara geometris, turunan f\'(x) merupakan gradien (kemiringan) garis singgung kurva f(x) pada titik x tersebut. Konsep turunan sangat vital dalam sains dan ekonomi untuk menentukan kondisi titik stasioner (f\'(x) = 0), titik balik maksimum (laba terbesar), dan titik balik minimum (biaya terendah).',
    coreConcepts: [
      {
        title: 'Aturan Dasar Turunan',
        description: 'Jika f(x) = a·x^n, maka f\'(x) = a·n·x^(n-1). Turunan dari konstanta adalah 0.',
        example: 'f(x) = 3x⁴ - 5x² + 7x - 12 → f\'(x) = 12x³ - 10x + 7.'
      },
      {
        title: 'Titik Stasioner & Nilai Ekstrem',
        description: 'Titik puncak kurva terjadi saat gradien f\'(x) = 0. Uji turunan kedua: f\'\'(x) < 0 menunjukkan nilai Maksimum, f\'\'(x) > 0 menunjukkan nilai Minimum.',
        example: 'Fungsi laba L(x) = -2x² + 40x - 100. L\'(x) = -4x + 40 = 0 → 4x = 40 → x = 10 unit untuk laba optimal.'
      }
    ],
    realWorldExample: 'Perusahaan manufaktur menggunakan diferensial untuk menghitung jumlah produksi optimal agar biaya operasional per unit berada pada titik minimum.',
    summary: [
      'Rumus dasar: d/dx(x^n) = n·x^(n-1).',
      'Nilai stasioner dicari dengan menetapkan f\'(x) = 0.',
      'Turunan kedua f\'\'(x) digunakan untuk membedakan puncak maksimum atau lembah minimum.'
    ],
    studyTips: 'Ingat aturan rantai (Chain Rule) untuk fungsi komposisi: [g(f(x))]\' = g\'(f(x)) · f\'(x)!'
  },
  {
    id: 'sma-mat-trigonometri',
    title: 'Trigonometri: Sudut Berelasi & Aturan Sinus/Cosinus',
    description: 'Perbandingan sudut istimewa, kuadran I-IV, aturan sinus (a/sin A = b/sin B), dan aturan cosinus pada segitiga sembarang.',
    subjectId: 'sma-matematika',
    grade: 10,
    semester: 1,
    difficulty: 'sedang',
    estimatedMinutes: 18,
    explanation: 'Trigonometri mempelajari relasi perbandingan panjang sisi segitiga siku-siku dengan besar sudutnya (sinus = depan/miring, cosinus = samping/miring, tangen = depan/samping). Untuk sudut di luar kuadran I (0-90°), kita menggunakan aturan tanda kuadran ASTC (All, Sin, Tan, Cos positif). Pada segitiga sembarang, kita menggunakan Aturan Sinus dan Aturan Cosinus.',
    coreConcepts: [
      {
        title: 'Aturan Sinus',
        description: 'a / sin(A) = b / sin(B) = c / sin(C) = 2R. Digunakan jika diketahui kombinasi sisi dan sudut di hadapannya.',
        example: 'Pada segitiga ABC: a = 10 cm, ∠A = 30°, ∠B = 45°. b = a · sin(45°) / sin(30°) = 10 · (1/2√2) / (1/2) = 10√2 cm.'
      },
      {
        title: 'Aturan Cosinus',
        description: 'c² = a² + b² - 2·a·b·cos(C). Digunakan jika diketahui 2 sisi dan 1 sudut apit, atau diketahui ketiga sisinya.',
        example: 'Jika a = 6, b = 8, dan ∠C = 60°: c² = 6² + 8² - 2(6)(8)cos(60°) = 36 + 64 - 96(0,5) = 100 - 48 = 52 → c = √52 = 2√13.'
      }
    ],
    realWorldExample: 'Sistem radar navigasi pesawat terbang dan menara kontrol bandara mengukur jarak dan sudut kemiringan menggunakan trigonometri gelombang sinyal.',
    summary: [
      'Sinus = demi, Cosinus = sami, Tangen = desa.',
      'Tanda Kuadran: Kuadran I (Semua +), II (Sin +), III (Tan +), IV (Cos +).',
      'Gunakan Aturan Cosinus jika ketiga sisi diketahui untuk mencari besar sudut.'
    ],
    studyTips: 'Ingat jembatan keledai: Semua Suka Tahu Cokelat (Kuadran I: Semua, II: Sin, III: Tan, IV: Cos)!'
  },

  // ==========================================
  // SMA FISIKA
  // ==========================================
  {
    id: 'sma-fis-gerak-parabola',
    title: 'Kinematika: Gerak Parabola (Proyektil)',
    description: 'Perpaduan GLB pada sumbu X horizontal dan GLBB diperlambat/dipercepat gravitasi pada sumbu Y vertikal.',
    subjectId: 'sma-fisika',
    grade: 10,
    semester: 1,
    difficulty: 'sedang',
    estimatedMinutes: 17,
    explanation: 'Gerak parabola adalah gerak dua dimensi benda yang dilempar miring dengan sudut elevasi α terhadap bidang horizontal di bawah pengaruh percepatan gravitasi bumi (g = 9,8 atau 10 m/s²). Pada sumbu X, benda bergerak lurus beraturan (GLB) dengan kecepatan konstan Vx = Vo · cos(α). Pada sumbu Y, benda bergerak lurus berubah beraturan (GLBB) dengan Vy = Vo · sin(α) - g · t. Di titik tertinggi, kecepatan vertikal Vy = 0.',
    coreConcepts: [
      {
        title: 'Kecepatan Awal Komponen X dan Y',
        description: 'Vox = Vo · cos(α) | Voy = Vo · sin(α).',
        example: 'Kecepatan awal Vo = 50 m/s dengan sudut α = 37° (sin 37° = 0,6; cos 37° = 0,8): Vox = 50 · 0,8 = 40 m/s, Voy = 50 · 0,6 = 30 m/s.'
      },
      {
        title: 'Waktu Titik Tertinggi & Jangkauan Maksimum',
        description: 'Waktu ke puncak: t_puncak = Voy / g. Titik tertinggi: H_max = (Vo² · sin²α) / (2g). Jarak mendatar terjauh: X_max = (Vo² · sin 2α) / g.',
        example: 'Sudut lemparan 45° akan menghasilkan jarak jangkauan X_max paling jauh karena sin(2 x 45°) = sin(90°) = 1.'
      }
    ],
    realWorldExample: 'Pemain sepak bola menembak bola melambung melewati pagar betis lawan atau pebasket melempar bola three-point ke dalam ring.',
    summary: [
      'Sumbu X selalu GLB: jarak X = Vox · t (kecepatan horizontal konstan).',
      'Sumbu Y selalu GLBB: dipengaruhi tarikan percepatan gravitasi bumi g.',
      'Di titik tertinggi puncak parabola, kecepatan vertikal Vy = 0 (tetapi Vx tetap ada!).'
    ],
    studyTips: 'Jangan lupa bahwa waktu total melayang di udara sampai menyentuh tanah adalah 2 kali waktu mencapai puncak!'
  },
  {
    id: 'sma-fis-termodinamika',
    title: 'Termodinamika & Siklus Mesin Carnot',
    description: 'Hukum I Termodinamika (Q = ΔU + W), proses isotermik/isobarik/isokhorik/adiabatik, dan efisiensi maksimum mesin kalor.',
    subjectId: 'sma-fisika',
    grade: 11,
    semester: 2,
    difficulty: 'sulit',
    estimatedMinutes: 19,
    explanation: 'Termodinamika membahas perpindahan energi dalam bentuk kalor dan usaha mekanik. Hukum I Termodinamika adalah hukum kekekalan energi: Q = ΔU + W (Kalor masuk = Perubahan Energi Dalam gas + Usaha kerja luar). Siklus Carnot adalah siklus ideal teoritis yang memiliki efisiensi termal tertinggi di antara dua reservoir suhu tinggi (T1) dan suhu rendah (T2). Rumus efisiensi mesin Carnot: η = (1 - T2/T1) x 100%, dengan suhu mutlak dalam satuan Kelvin.',
    coreConcepts: [
      {
        title: 'Hukum I Termodinamika',
        description: 'Q bernilai (+) jika sistem menyerap kalor, W bernilai (+) jika sistem melakukan usaha memuai (ekspansi).',
        example: 'Gas menyerap kalor 500 J dan melakukan usaha 200 J. Perubahan energi dalamnya ΔU = Q - W = 500 - 200 = 300 J.'
      },
      {
        title: 'Efisiensi Mesin Carnot',
        description: 'η = 1 - (T_rendah / T_tinggi). Suhu WAJIB dikonversi ke Kelvin (K = °C + 273).',
        example: 'Reservoir tinggi T1 = 500 K dan T2 = 300 K. Efisiensi η = (1 - 300/500) x 100% = 40%.'
      }
    ],
    realWorldExample: 'Mesin pembakaran motor dan kulkas pendingin ruangan di rumah beroperasi berdasarkan siklus termodinamika penyerapan dan pembuangan kalor.',
    summary: [
      'Isobarik (tekanan konstan: W = P·ΔV), Isotermik (suhu konstan: ΔU = 0), Isokhorik (volume konstan: W = 0).',
      'Efisiensi mesin Carnot tidak pernah mencapai 100% karena selalu ada kalor buang T2.',
      'Pastikan selalu menggunakan satuan mutlak Kelvin saat menghitung rasio suhu!'
    ],
    studyTips: 'Selalu ubah suhu Celcius ke Kelvin dengan menambahkan 273 sebelum dimasukkan ke rumus efisiensi!'
  },

  // ==========================================
  // SMA KIMIA
  // ==========================================
  {
    id: 'sma-kim-larutan-buffer',
    title: 'Larutan Penyangga (Buffer) & pH',
    description: 'Mekanisme larutan buffer asam dan basa dalam mempertahankan kestabilan pH saat ditambah sedikit asam, basa, atau air.',
    subjectId: 'sma-kimia',
    grade: 11,
    semester: 2,
    difficulty: 'sulit',
    estimatedMinutes: 18,
    explanation: 'Larutan penyangga (buffer) adalah larutan yang mampu mempertahankan derajat keasaman (pH) relatif konstan meskipun ditambahkan sedikit asam kuat, sedikit basa kuat, atau diencerkan dengan air. Buffer Asam tersusun dari campuran Asam Lemah dan Basa Konjugasinya (contoh: CH3COOH + CH3COONa). Buffer Basa tersusun dari Basa Lemah dan Asam Konjugasinya (contoh: NH3 + NH4Cl). Di dalam tubuh manusia, sistem buffer hemoglobin dan bikarbonat (H2CO3 / HCO3⁻) menjaga pH darah stabil pada kisaran 7,35 - 7,45.',
    coreConcepts: [
      {
        title: 'Rumus pH Buffer Asam',
        description: '[H⁺] = Ka · (mol Asam Lemah / mol Basa Konjugasi) → pH = -log[H⁺].',
        example: 'Campuran 0,1 mol CH3COOH (Ka = 10⁻⁵) dan 0,1 mol CH3COONa: [H⁺] = 10⁻⁵ · (0,1 / 0,1) = 10⁻⁵ M → pH = 5.'
      },
      {
        title: 'Peran Buffer dalam Biologis Tubuh',
        description: 'Menjaga enzim tubuh tidak mengalami denaturasi akibat perubahan asam atau basa yang ekstrem.',
        example: 'Buffer karbonat dalam darah mencegah kondisi asidosis (pH darah turun berbahaya di bawah 7,0).'
      }
    ],
    realWorldExample: 'Cairan infus medis dan obat tetes mata diformulasikan dengan larutan buffer agar memiliki pH yang sama persis dengan cairan fisiologis tubuh.',
    summary: [
      'Buffer asam = Asam Lemah + Garamnya (Basa Konjugasi).',
      'Buffer basa = Basa Lemah + Garamnya (Asam Konjugasi).',
      'Darah manusia mengandung buffer H2CO3 / HCO3⁻ untuk menjaga pH ~7,4.'
    ],
    studyTips: 'Jika asam kuat dan basa lemah bereaksi, buffer terbentuk HANYA JIKA basa lemah bersisa setelah reaksi pembatas selesai!'
  },

  // ==========================================
  // SMA BIOLOGI
  // ==========================================
  {
    id: 'sma-bio-sintesis-protein',
    title: 'Sintesis Protein: Transkripsi & Translasi',
    description: 'Alur dogma sentral biologi molekuler: DNA ditranskripsi menjadi mRNA di nukleus, lalu ditranslasi tRNA menjadi rantai polipeptida di ribosom.',
    subjectId: 'sma-biologi',
    grade: 12,
    semester: 2,
    difficulty: 'sulit',
    estimatedMinutes: 19,
    explanation: 'Dogma sentral biologi menjelaskan bagaimana instruksi genetik pada DNA diwujudkan menjadi protein fungsional tubuh melalui 2 tahap utama: 1. Transkripsi (di dalam inti sel/nukleus): Enzim RNA Polimerase membaca rantai DNA cetakan (template/antisense) untuk mencetak molekul mRNA (RNA duta). Basa Adenin (A) berpasangan dengan Urasil (U) pada RNA, dan Guanin (G) dengan Sitosin (C). 2. Translasi (di sitoplasma pada ribosom): Molekul mRNA dibaca setiap 3 basa nitrogen (Kodon). tRNA membawa antikodon dan asam amino yang sesuai untuk dirangkai menjadi rantai polipeptida (protein).',
    coreConcepts: [
      {
        title: 'Kodon Awal (Start) & Akhir (Stop)',
        description: 'Kodon Start adalah AUG (mengodekan asam amino Metionin). Kodon Stop penanda akhir sintesis adalah UAA, UAG, UGA.',
        example: 'Urutan kodon mRNA: AUG - GGC - UAA menghasilkan rantai: Metionin - Glisin - (Stop).'
      },
      {
        title: 'Perbedaan DNA dan RNA',
        description: 'DNA beruntai ganda (double helix) dengan gula deoksiribosa dan basa Timin (T). RNA beruntai tunggal dengan gula ribosa dan basa Urasil (U).',
        example: 'Jika rantai DNA sense adalah TAC-GGT, maka mRNA yang terbentuk adalah AUG-CCA.'
      }
    ],
    realWorldExample: 'Vaksin mRNA Covid-19 menyuntikkan instruksi mRNA virus agar ribosom sel kita membentuk protein spike jinak, melatih antibodi imun tubuh kita secara aman.',
    summary: [
      'Transkripsi terjadi di nukleus: DNA Template -> mRNA.',
      'Translasi terjadi di ribosom: mRNA -> Asam Amino / Polipeptida.',
      'Kodon Start = AUG, Kodon Stop = UAA, UAG, UGA.'
    ],
    studyTips: 'Hafalkan kodon start: "AUG" (Agustus awal bulan merdeka = Start)!'
  },

  // ==========================================
  // SMA EKONOMI
  // ==========================================
  {
    id: 'sma-eko-kebijakan-moneter',
    title: 'Kebijakan Moneter & Pengendalian Inflasi',
    description: 'Instrumen Bank Sentral: Operasi Pasar Terbuka, Politik Diskonto (Suku Bunga), Giro Wajib Minimum, dan Kredit Selektif.',
    subjectId: 'sma-ekonomi',
    grade: 11,
    semester: 1,
    difficulty: 'sedang',
    estimatedMinutes: 15,
    explanation: 'Kebijakan moneter adalah serangkaian tindakan yang diambil oleh bank sentral (Bank Indonesia) untuk mengatur jumlah uang yang beredar (JUB) di masyarakat dan menjaga stabilitas nilai tukar rupiah serta menekan laju inflasi. Ketika terjadi inflasi tinggi (uang beredar terlalu banyak), BI menerapkan kebijakan Moneter Ketat (Tight Money Policy) dengan menaikkan suku bunga acuan (BI-Rate) dan menjual Surat Berharga Negara (SBN) ke publik.',
    coreConcepts: [
      {
        title: '4 Instrumen Utama Kebijakan Moneter',
        description: '1. Operasi Pasar Terbuka (Jual/Beli SBI). 2. Politik Diskonto (Naik/Turunkan Suku Bunga). 3. Rasio Cadangan Wajib / Cash Ratio. 4. Kebijakan Kredit Selektif.',
        example: 'Saat inflasi tinggi: BI menaikkan suku bunga agar masyarakat lebih memilih menabung di bank dan jumlah uang beredar berkurang.'
      },
      {
        title: 'Moneter Ekspansif vs Kontraktif',
        description: 'Ekspansif (Easy Money): Menambah jumlah uang beredar saat ekonomi lesu/resesi. Kontraktif (Tight Money): Mengurangi jumlah uang beredar saat inflasi melonjak.',
        example: 'Di masa pemulihan pandemi, bank sentral menurunkan suku bunga agar kredit modal usaha bertumbuh.'
      }
    ],
    realWorldExample: 'Kenaikan suku bunga BI-Rate membuat bunga cicilan KPR rumah naik, sehingga konsumsi belanja masyarakat mengerem dan harga barang kembali stabil.',
    summary: [
      'Kebijakan moneter dijalankan secara independen oleh Bank Sentral (Bank Indonesia).',
      'Mengatasi inflasi: Jual surat berharga, naikkan suku bunga diskonto, naikkan giro wajib minimum.',
      'Mengatasi pengangguran/resesi: Beli surat berharga, turunkan suku bunga acuan.'
    ],
    studyTips: 'Ingat korelasi: Inflasi naik -> Rem ekonomi (Taikkan bunga) | Resesi lesu -> Gas ekonomi (Turunkan bunga)!'
  }
];

export function getTopicsBySubjectAndSemester(subjectId: string, semester: 1 | 2, grade?: number): Topic[] {
  return TOPICS.filter(t => {
    const matchSubject = t.subjectId === subjectId;
    const matchSem = t.semester === semester;
    const matchGrade = grade ? t.grade === grade : true;
    return matchSubject && matchSem && matchGrade;
  });
}

export function getAllTopicsForSubject(subjectId: string): Topic[] {
  return TOPICS.filter(t => t.subjectId === subjectId);
}

export function getTopicById(topicId: string): Topic | undefined {
  return TOPICS.find(t => t.id === topicId);
}
