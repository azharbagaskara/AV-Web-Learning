import React from 'react';
import { UserProfile } from '../types';
import { calculateLevel } from '../utils/storage';
import { BookOpen, CheckCircle, Download, GraduationCap, Home, Laptop, PenTool, PieChart, Sparkles, Trophy, User, X } from 'lucide-react';

interface MobileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile | null;
  activeView: string;
  onNavigate: (view: string) => void;
  onOpenChangeClass: () => void;
  onOpenDownloadPc: () => void;
}

export const MobileDrawer: React.FC<MobileDrawerProps> = ({
  isOpen,
  onClose,
  user,
  activeView,
  onNavigate,
  onOpenChangeClass,
  onOpenDownloadPc
}) => {
  if (!isOpen) return null;

  const levelInfo = user ? calculateLevel(user.totalXP) : null;

  const navItems = [
    { id: 'dashboard', label: 'Beranda', icon: <Home className="w-5 h-5" />, desc: 'Ringkasan aktivitas & rekomendasi' },
    { id: 'subjects', label: 'Materi Belajar', icon: <BookOpen className="w-5 h-5" />, desc: 'Mata pelajaran & silabus' },
    { id: 'quizzes', label: 'Kuis (10 Soal)', icon: <CheckCircle className="w-5 h-5" />, desc: 'Latihan kuis pilihan ganda 10 soal' },
    { id: 'essays', label: 'Latihan Essay', icon: <PenTool className="w-5 h-5" />, desc: 'Asah pemahaman analitis' },
    { id: 'progress', label: 'Progress Belajar', icon: <PieChart className="w-5 h-5" />, desc: 'Statistik nilai & pencapaian' },
    { id: 'profile', label: 'Profil Saya', icon: <User className="w-5 h-5" />, desc: 'Pengaturan akun & ganti kelas' },
  ];

  return (
    <div className="fixed inset-0 z-50 md:hidden flex">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Panel */}
      <div className="relative w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-200">
        {/* Header */}
        <div className="p-5 bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center font-bold text-lg">
              AV
            </div>
            <div>
              <h2 className="font-bold text-base leading-tight">AV Learning</h2>
              <p className="text-xs text-blue-100">Belajar jadi lebih gampang</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Card */}
        {user && (
          <div className="p-4 bg-blue-50/70 border-b border-blue-100">
            <div className="flex items-center justify-between mb-2">
              <div>
                <p className="text-xs text-slate-500 font-medium">Siswa Terdaftar</p>
                <p className="font-bold text-slate-800 text-sm truncate">{user.name}</p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onOpenChangeClass();
                }}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 bg-white px-2.5 py-1 rounded-lg border border-blue-200 shadow-2xs flex items-center gap-1"
              >
                <GraduationCap className="w-3.5 h-3.5" />
                Ganti Kelas
              </button>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="px-2 py-0.5 rounded bg-blue-600 text-white font-medium">
                Kelas {user.grade} {user.educationLevel}
              </span>
              <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-600" />
                {user.totalXP} Poin
              </span>
              <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold flex items-center gap-1">
                <Trophy className="w-3 h-3 text-indigo-600" />
                Lvl {levelInfo?.level}
              </span>
            </div>
          </div>
        )}

        {/* Nav Links */}
        <div className="flex-1 overflow-y-auto py-3 px-3 space-y-1">
          {navItems.map((item) => {
            const isActive = activeView === item.id || 
              (item.id === 'subjects' && activeView === 'study') ||
              (item.id === 'quizzes' && activeView === 'quiz-active') ||
              (item.id === 'essays' && activeView === 'essay-active');

            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={`w-full text-left px-3.5 py-3 rounded-xl flex items-center gap-3 transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white font-semibold shadow-sm shadow-blue-600/20'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className={`p-2 rounded-lg ${isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-blue-600'}`}>
                  {item.icon}
                </div>
                <div>
                  <div className="text-sm">{item.label}</div>
                  <div className={`text-[11px] ${isActive ? 'text-blue-100' : 'text-slate-400'}`}>
                    {item.desc}
                  </div>
                </div>
              </button>
            );
          })}

          {/* PC HTML Download Button in Drawer */}
          <div className="pt-2">
            <button
              onClick={() => {
                onClose();
                onOpenDownloadPc();
              }}
              className="w-full text-left px-3.5 py-3 rounded-xl flex items-center gap-3 bg-slate-900 text-white hover:bg-slate-800 transition-all cursor-pointer"
            >
              <div className="p-2 rounded-lg bg-white/10 text-sky-400">
                <Laptop className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold">Download File HTML PC</div>
                <div className="text-[11px] text-slate-300">Bisa dibuka offline di PC / laptop</div>
              </div>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 text-center text-xs text-slate-400">
          AV Learning v2.0 • Kurikulum Terintegrasi
        </div>
      </div>
    </div>
  );
};
