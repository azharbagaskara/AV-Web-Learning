import React, { useState } from 'react';
import { ProgressItem, Subject, Topic, UserProfile } from '../types';
import { 
  ArrowLeft, 
  BookOpen, 
  CheckCircle, 
  ChevronRight, 
  Clock, 
  Filter, 
  GraduationCap, 
  Info, 
  Layers, 
  PenTool, 
  Play, 
  Search, 
  Sparkles, 
  Star 
} from 'lucide-react';

interface SubjectHierarchyViewProps {
  user: UserProfile;
  subjects: Subject[];
  topics: Topic[];
  progressList: ProgressItem[];
  selectedSubjectId: string | null;
  selectedSemester: 1 | 2;
  onSelectSubject: (subjectId: string | null) => void;
  onSelectSemester: (semester: 1 | 2) => void;
  onOpenTopic: (topic: Topic) => void;
  onStartQuiz: (topic: Topic) => void;
  onStartEssay: (topic: Topic) => void;
}

export const SubjectHierarchyView: React.FC<SubjectHierarchyViewProps> = ({
  user,
  subjects,
  topics,
  progressList,
  selectedSubjectId,
  selectedSemester,
  onSelectSubject,
  onSelectSemester,
  onOpenTopic,
  onStartQuiz,
  onStartEssay
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Selected subject object
  const currentSubject = selectedSubjectId
    ? subjects.find(s => s.id === selectedSubjectId)
    : null;

  // Filter topics for the current selected subject, grade, and semester
  const filteredTopics = topics.filter(t => {
    const matchesSubject = selectedSubjectId ? t.subjectId === selectedSubjectId : true;
    const matchesGrade = t.grade === user.grade;
    const matchesSemester = selectedSubjectId ? t.semester === selectedSemester : true;
    const matchesSearch = searchQuery.trim() === '' || 
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesSubject && matchesGrade && matchesSemester && matchesSearch;
  });

  // Subjects filtered by search if no subject is selected yet
  const filteredSubjects = subjects.filter(s => {
    if (!searchQuery.trim()) return true;
    return s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.description.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-blue-100/80 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 font-bold text-xs">
                Kurikulum Kelas {user.grade} {user.educationLevel}
              </span>
              <span className="text-xs text-slate-400">•</span>
              <span className="text-xs text-slate-500 font-medium">
                {currentSubject ? currentSubject.name : `${subjects.length} Mata Pelajaran`}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight">
              {currentSubject ? currentSubject.name : 'Pilih Mata Pelajaran'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
              {currentSubject
                ? currentSubject.description
                : `Jelajahi seluruh materi dan silabus kurikulum Semester 1 & 2 yang dirancang khusus untuk Kelas ${user.grade} ${user.educationLevel}.`}
            </p>
          </div>

          {/* Search Input */}
          <div className="relative min-w-[260px] sm:min-w-[300px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari materi atau topik..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50/70 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs sm:text-sm transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </div>

      {/* VIEW 1: SUBJECT SELECTION GRID (when no subject is selected) */}
      {!currentSubject && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-2">
              <Layers className="w-5 h-5 text-blue-600" />
              <span>Daftar Mata Pelajaran</span>
            </h2>
            <span className="text-xs text-slate-400">
              {filteredSubjects.length} mata pelajaran tersedia
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSubjects.map((sub) => (
              <div
                key={sub.id}
                onClick={() => onSelectSubject(sub.id)}
                className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs hover:border-blue-400 hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-100 text-3xl flex items-center justify-center group-hover:scale-105 transition-transform shadow-2xs">
                      {sub.icon}
                    </div>
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                      {sub.educationLevel}
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-800 text-base sm:text-lg mt-3 group-hover:text-blue-600 transition-colors">
                    {sub.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                    {sub.description}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-blue-600 font-semibold">
                  <span className="flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5" />
                    Silabus Sem 1 & 2
                  </span>
                  <div className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    <span>Pilih</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 2: SUBJECT DETAIL & SEMESTER BREAKDOWN (when subject is selected) */}
      {currentSubject && (
        <div className="space-y-6">
          {/* Back button */}
          <button
            onClick={() => onSelectSubject(null)}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs sm:text-sm font-semibold hover:bg-slate-50 transition-colors shadow-2xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali ke Semua Mata Pelajaran</span>
          </button>

          {/* Detailed Syllabus Comparison for Semester 1 & 2 */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-blue-100 shadow-sm space-y-5">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
                <Info className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 text-lg">
                  Gambaran Mata Pelajaran: {currentSubject.name}
                </h3>
                <p className="text-xs text-slate-500">
                  Berikut ringkasan capaian pembelajaran dari Semester 1 sampai Semester 2
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Semester 1 Syllabus Card */}
              <div className={`rounded-2xl p-5 border-2 transition-all ${
                selectedSemester === 1
                  ? 'border-blue-500 bg-blue-50/40 shadow-xs'
                  : 'border-slate-200 bg-slate-50/60 hover:border-slate-300'
              }`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">📘</span>
                    <h4 className="font-bold text-slate-800 text-base">Semester 1</h4>
                  </div>
                  {selectedSemester === 1 && (
                    <span className="px-2 py-0.5 rounded bg-blue-600 text-white text-[11px] font-semibold">
                      Aktif Dipilih
                    </span>
                  )}
                </div>
                <div className="text-xs font-semibold text-blue-700 mb-1">
                  Tema: {currentSubject.semester1Syllabus.theme}
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {currentSubject.semester1Syllabus.description}
                </p>
                <div className="mt-3 pt-3 border-t border-slate-200/70">
                  <div className="text-[11px] font-bold text-slate-700 mb-1">Topik Utama:</div>
                  <ul className="list-disc list-inside text-xs text-slate-600 space-y-0.5">
                    {currentSubject.semester1Syllabus.mainTopics.map((tp, idx) => (
                      <li key={idx} className="line-clamp-1">{tp}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Semester 2 Syllabus Card */}
              <div className={`rounded-2xl p-5 border-2 transition-all ${
                selectedSemester === 2
                  ? 'border-emerald-500 bg-emerald-50/40 shadow-xs'
                  : 'border-slate-200 bg-slate-50/60 hover:border-slate-300'
              }`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">📗</span>
                    <h4 className="font-bold text-slate-800 text-base">Semester 2</h4>
                  </div>
                  {selectedSemester === 2 && (
                    <span className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[11px] font-semibold">
                      Aktif Dipilih
                    </span>
                  )}
                </div>
                <div className="text-xs font-semibold text-emerald-700 mb-1">
                  Tema: {currentSubject.semester2Syllabus.theme}
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {currentSubject.semester2Syllabus.description}
                </p>
                <div className="mt-3 pt-3 border-t border-slate-200/70">
                  <div className="text-[11px] font-bold text-slate-700 mb-1">Topik Utama:</div>
                  <ul className="list-disc list-inside text-xs text-slate-600 space-y-0.5">
                    {currentSubject.semester2Syllabus.mainTopics.map((tp, idx) => (
                      <li key={idx} className="line-clamp-1">{tp}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Semester Switcher Tabs */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Pilih Semester untuk Menampilkan Materi & Kuis:
              </label>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => onSelectSemester(1)}
                  className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    selectedSemester === 1
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span>📘 Semester 1</span>
                </button>
                <button
                  type="button"
                  onClick={() => onSelectSemester(2)}
                  className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    selectedSemester === 2
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span>📗 Semester 2</span>
                </button>
              </div>
            </div>
          </div>

          {/* Topics List for Active Semester */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-800 text-lg flex items-center gap-2">
                <span>Daftar Materi {selectedSemester === 1 ? '📘 Semester 1' : '📗 Semester 2'}</span>
              </h3>
              <span className="text-xs text-slate-500">
                {filteredTopics.length} modul pembelajaran
              </span>
            </div>

            {filteredTopics.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center border border-dashed border-slate-300">
                <p className="text-sm font-semibold text-slate-600">
                  Belum ada materi yang sesuai dengan filter pencarian.
                </p>
                <button
                  onClick={() => setSearchQuery('')}
                  className="mt-2 text-xs text-blue-600 font-bold underline"
                >
                  Reset Pencarian
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredTopics.map((topic) => {
                  const progress = progressList.find(
                    p => p.topicId === topic.id && p.grade === user.grade && p.semester === selectedSemester
                  );
                  const isDone = progress?.isCompleted;

                  return (
                    <div
                      key={topic.id}
                      className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs hover:border-blue-300 hover:shadow-md transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-1.5">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              topic.difficulty === 'mudah'
                                ? 'bg-emerald-100 text-emerald-800'
                                : topic.difficulty === 'sedang'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}>
                              Level {topic.difficulty}
                            </span>
                            <span className="text-slate-400 text-xs flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {topic.estimatedMinutes} mnt
                            </span>
                          </div>

                          {isDone && (
                            <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                              <CheckCircle className="w-3.5 h-3.5" />
                              Selesai
                            </span>
                          )}
                        </div>

                        <h4 className="font-bold text-slate-800 text-base mt-2 line-clamp-1">
                          {topic.title}
                        </h4>
                        <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                          {topic.description}
                        </p>
                      </div>

                      {/* Action Buttons: Baca Materi, Kuis 10 Soal, Essay */}
                      <div className="mt-5 pt-3 border-t border-slate-100 grid grid-cols-3 gap-2">
                        <button
                          onClick={() => onOpenTopic(topic)}
                          className="py-2 px-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <BookOpen className="w-3.5 h-3.5 shrink-0" />
                          <span>Materi</span>
                        </button>

                        <button
                          onClick={() => onStartQuiz(topic)}
                          className="py-2 px-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-2xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
                          title="Kuis 10 Soal"
                        >
                          <Sparkles className="w-3.5 h-3.5 shrink-0" />
                          <span>Kuis 10</span>
                        </button>

                        <button
                          onClick={() => onStartEssay(topic)}
                          className="py-2 px-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                          title="Latihan Essay"
                        >
                          <PenTool className="w-3.5 h-3.5 shrink-0" />
                          <span>Essay</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
