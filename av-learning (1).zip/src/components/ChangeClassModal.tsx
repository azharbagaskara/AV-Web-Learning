import React, { useState } from 'react';
import { EducationLevel } from '../types';
import { BookOpen, Check, GraduationCap, Sparkles, X } from 'lucide-react';

interface ChangeClassModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLevel: EducationLevel;
  currentGrade: number;
  onSaveClass: (newLevel: EducationLevel, newGrade: number) => void;
}

export const ChangeClassModal: React.FC<ChangeClassModalProps> = ({
  isOpen,
  onClose,
  currentLevel,
  currentGrade,
  onSaveClass
}) => {
  if (!isOpen) return null;

  const [selectedLevel, setSelectedLevel] = useState<EducationLevel>(currentLevel);
  const [selectedGrade, setSelectedGrade] = useState<number>(currentGrade);

  const handleLevelChange = (lvl: EducationLevel) => {
    setSelectedLevel(lvl);
    if (lvl === 'SD') setSelectedGrade(3);
    else if (lvl === 'SMP') setSelectedGrade(8);
    else if (lvl === 'SMA') setSelectedGrade(11);
  };

  const getGradesForLevel = (lvl: EducationLevel): number[] => {
    if (lvl === 'SD') return [1, 2, 3, 4, 5, 6];
    if (lvl === 'SMP') return [7, 8, 9];
    return [10, 11, 12];
  };

  const handleSave = () => {
    onSaveClass(selectedLevel, selectedGrade);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Box */}
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden z-10 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-white/20">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">🎓 Ganti Kelas Belajar</h3>
              <p className="text-xs text-blue-100">Sesuaikan jenjang & kelas aktif kamu</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-4">
          {/* Info Banner */}
          <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200 text-xs text-blue-900 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Progress Kelas Lamamu Aman!</p>
              <p className="text-slate-600 text-[11px] mt-0.5">
                Saat kamu naik atau berganti kelas, seluruh riwayat kuis, essay, dan nilai kelas sebelumnya tetap tersimpan rapi.
              </p>
            </div>
          </div>

          {/* Jenjang */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Pilih Jenjang
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['SD', 'SMP', 'SMA'] as EducationLevel[]).map((lvl) => {
                const isSelected = selectedLevel === lvl;
                return (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => handleLevelChange(lvl)}
                    className={`py-3 px-2 rounded-xl text-center font-bold text-sm border-2 transition-all flex flex-col items-center justify-center gap-1 ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-2xs'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="text-base">
                      {lvl === 'SD' ? '🎒' : lvl === 'SMP' ? '📘' : '🎓'}
                    </span>
                    <span>{lvl}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Kelas */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Pilih Kelas
            </label>
            <div className="grid grid-cols-3 gap-2">
              {getGradesForLevel(selectedLevel).map((g) => {
                const isSelected = selectedGrade === g;
                return (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setSelectedGrade(g)}
                    className={`py-2.5 px-2 rounded-xl text-center text-xs sm:text-sm font-semibold border transition-all flex items-center justify-center gap-1.5 ${
                      isSelected
                        ? 'bg-blue-600 border-blue-600 text-white shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                    <span>Kelas {g}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="w-1/2 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-semibold text-xs sm:text-sm hover:bg-slate-50 transition-colors"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="w-1/2 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Simpan Kelas</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
