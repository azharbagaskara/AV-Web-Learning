import React, { useState } from 'react';
import { EducationLevel, UserProfile } from '../types';
import { createInitialProfile } from '../utils/storage';
import { BookOpen, CheckCircle, GraduationCap, Sparkles, Star } from 'lucide-react';

interface AuthModalProps {
  onLoginSuccess: (profile: UserProfile) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onLoginSuccess }) => {
  const [name, setName] = useState('');
  const [educationLevel, setEducationLevel] = useState<EducationLevel>('SMP');
  const [grade, setGrade] = useState<number>(8);
  const [error, setError] = useState('');

  const handleLevelChange = (lvl: EducationLevel) => {
    setEducationLevel(lvl);
    if (lvl === 'SD') setGrade(3);
    else if (lvl === 'SMP') setGrade(8);
    else if (lvl === 'SMA') setGrade(11);
  };

  const getGradesForLevel = (lvl: EducationLevel): number[] => {
    if (lvl === 'SD') return [1, 2, 3, 4, 5, 6];
    if (lvl === 'SMP') return [7, 8, 9];
    return [10, 11, 12];
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Silakan masukkan nama kamu');
      return;
    }
    if (name.trim().length < 2) {
      setError('Nama minimal 2 huruf');
      return;
    }

    const profile = createInitialProfile(name.trim(), educationLevel, grade);
    onLoginSuccess(profile);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-400 via-blue-600 to-indigo-950 flex flex-col items-center justify-center p-4 sm:p-6 md:p-8">
      {/* Decorative background glow */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 w-96 h-96 bg-sky-300/20 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border border-white/20 relative z-10">
        {/* Card Header with AV Branding */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-6 sm:p-8 text-center text-white relative">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/15 backdrop-blur-md text-white font-black text-2xl shadow-inner border border-white/30 mb-3.5">
            AV
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Selamat Datang di AV Learning
          </h1>
          <p className="text-blue-100 text-xs sm:text-sm mt-1.5 font-medium">
            Platform belajar interaktif dari Kelas 1 SD hingga Kelas 12 SMA
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-5">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs sm:text-sm font-medium">
              ⚠️ {error}
            </div>
          )}

          {/* Name Input */}
          <div>
            <label className="block text-xs sm:text-sm font-bold text-slate-700 mb-1.5">
              Nama Lengkap / Panggilan
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError('');
              }}
              placeholder="Contoh: Budi Santoso"
              maxLength={30}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-800 text-sm font-medium transition-all"
              autoFocus
            />
          </div>

          {/* Education Level Selector */}
          <div>
            <label className="block text-xs sm:text-sm font-bold text-slate-700 mb-1.5">
              Pilih Jenjang Sekolah
            </label>
            <div className="grid grid-cols-3 gap-2.5">
              {(['SD', 'SMP', 'SMA'] as EducationLevel[]).map((lvl) => {
                const isSelected = educationLevel === lvl;
                return (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => handleLevelChange(lvl)}
                    className={`py-3 px-2 rounded-xl text-center font-bold text-sm border-2 transition-all flex flex-col items-center justify-center gap-1 ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-xs'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="text-base">
                      {lvl === 'SD' ? '🎒' : lvl === 'SMP' ? '📘' : '🎓'}
                    </span>
                    <span>{lvl}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Grade Selector */}
          <div>
            <label className="block text-xs sm:text-sm font-bold text-slate-700 mb-1.5">
              Pilih Kelas
            </label>
            <div className="grid grid-cols-3 gap-2">
              {getGradesForLevel(educationLevel).map((g) => {
                const isSelected = grade === g;
                return (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setGrade(g)}
                    className={`py-2.5 px-2 rounded-xl text-center text-xs sm:text-sm font-semibold border transition-all ${
                      isSelected
                        ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    Kelas {g}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Feature Highlights */}
          <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-100 space-y-1.5 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Kuis 10 soal acak & latihan essay otomatis dinilai</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Sistem XP, kenaikan level & kembang api perayaan</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Bisa ganti kelas kapan saja tanpa menghapus progres</span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm shadow-md shadow-blue-500/30 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Masuk & Mulai Belajar</span>
            <Sparkles className="w-4 h-4" />
          </button>
        </form>
      </div>

      <div className="mt-6 text-center text-xs text-blue-200/80">
        AV Learning © 2026 • Kurikulum Merdeka Terlengkap
      </div>
    </div>
  );
};
