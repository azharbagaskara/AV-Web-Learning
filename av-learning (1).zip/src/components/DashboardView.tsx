import React from 'react';
import { EducationLevel, ProgressItem, QuizHistoryItem, Subject, Topic, UserProfile } from '../types';
import { calculateLevel } from '../utils/storage';
import { 
  ArrowRight, 
  Award, 
  BookCheck, 
  BookOpen, 
  CheckCircle2, 
  ChevronRight, 
  Download, 
  Flame, 
  GraduationCap, 
  Laptop, 
  PenTool, 
  Play, 
  Sparkles, 
  Star, 
  Target, 
  Trophy 
} from 'lucide-react';

interface DashboardViewProps {
  user: UserProfile;
  subjects: Subject[];
  topics: Topic[];
  progressList: ProgressItem[];
  quizHistory: QuizHistoryItem[];
  onOpenSubject: (subjectId: string, semester?: 1 | 2) => void;
  onOpenTopic: (topic: Topic) => void;
  onStartQuiz: (topic: Topic) => void;
  onStartEssay: (topic: Topic) => void;
  onOpenChangeClass: () => void;
  onOpenDownloadPc: () => void;
  onNavigate: (view: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  subjects,
  topics,
  progressList,
  quizHistory,
  onOpenSubject,
  onOpenTopic,
  onStartQuiz,
  onStartEssay,
  onOpenChangeClass,
  onOpenDownloadPc,
  onNavigate
}) => {
  const levelInfo = calculateLevel(user.totalXP);

  // Filter topics belonging to current grade
  const gradeTopics = topics.filter(t => t.grade === user.grade);
  const completedTopicsCount = progressList.filter(
    p => p.grade === user.grade && p.isCompleted
  ).length;

  const totalGradeTopics = Math.max(1, gradeTopics.length);
  const gradeProgressPercent = Math.min(
    100,
    Math.round((completedTopicsCount / totalGradeTopics) * 100)
  );

  // Last quiz taken
  const lastQuiz = quizHistory.length > 0 ? quizHistory[0] : null;

  // Last studied topic
  const lastTopic = user.lastStudiedTopicId
    ? topics.find(t => t.id === user.lastStudiedTopicId)
    : gradeTopics[0] || null;

  // Recommendations for current grade
  const recommendedTopics = gradeTopics.slice(0, 3);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Hero Greeting & Stats Card */}
      <div className="rounded-3xl bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white p-6 sm:p-8 shadow-xl relative overflow-hidden">
        {/* Subtle decorative circles */}
        <div className="absolute -top-16 -right-16 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-indigo-500/20 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Left Column: Greeting & Class */}
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur-md text-xs font-semibold text-blue-100 border border-white/20">
              <GraduationCap className="w-4 h-4 text-sky-300" />
              <span>Kelas {user.grade} {user.educationLevel}</span>
              <button
                onClick={onOpenChangeClass}
                className="underline hover:text-white ml-1 text-sky-200 cursor-pointer"
              >
                Ganti Kelas
              </button>
            </div>

            <div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight">
                Hallo, {user.name} 👋
              </h1>
              <p className="text-blue-100 text-sm sm:text-base mt-1 max-w-xl">
                Semangat belajarmu luar biasa hari ini! Selesaikan kuis 10 soal untuk menaikkan level dan membuka tantangan baru.
              </p>
            </div>

            {/* Overall Progress for Current Grade */}
            <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 max-w-lg space-y-2">
              <div className="flex items-center justify-between text-xs sm:text-sm font-semibold">
                <span className="flex items-center gap-1.5 text-blue-100">
                  <Target className="w-4 h-4 text-sky-300" />
                  Progress Belajar Kelas {user.grade}
                </span>
                <span className="text-white font-bold text-base">
                  {gradeProgressPercent}%
                </span>
              </div>
              
              {/* Visual Progress Bar */}
              <div className="w-full h-3 rounded-full bg-black/20 overflow-hidden p-0.5">
                <div 
                  className="h-full rounded-full bg-gradient-to-r from-sky-400 to-emerald-400 transition-all duration-500 shadow-sm"
                  style={{ width: `${Math.max(5, gradeProgressPercent)}%` }}
                />
              </div>

              <div className="flex justify-between text-[11px] text-blue-200 font-medium">
                <span>{completedTopicsCount} dari {totalGradeTopics} materi selesai</span>
                <span>Tingkat Kesiapan Ujian</span>
              </div>
            </div>
          </div>

          {/* Right Column: Level & XP Milestones Card */}
          <div className="lg:col-span-5">
            <div className="bg-white/15 backdrop-blur-md rounded-2xl p-5 border border-white/20 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white shadow-md">
                    <Trophy className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs text-blue-100 uppercase tracking-wider font-semibold">
                      Tingkat Level
                    </div>
                    <div className="text-xl font-black text-white flex items-center gap-2">
                      Level {levelInfo.level}
                      <span className="text-xs font-normal px-2 py-0.5 rounded-md bg-amber-400/30 text-amber-200 border border-amber-300/30">
                        {levelInfo.title}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs text-blue-100">Total Poin</div>
                  <div className="text-xl font-black text-amber-300 flex items-center gap-1 justify-end">
                    <Sparkles className="w-4 h-4 fill-amber-300" />
                    ⭐ {user.totalXP}
                  </div>
                </div>
              </div>

              {/* XP Progress towards next level */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-blue-100">
                  <span>Menuju Level {levelInfo.level + 1}</span>
                  <span className="font-bold text-white">{levelInfo.progressPercent}%</span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-black/25 overflow-hidden">
                  <div 
                    className="h-full rounded-full bg-gradient-to-r from-amber-400 to-yellow-300 transition-all duration-300"
                    style={{ width: `${levelInfo.progressPercent}%` }}
                  />
                </div>
                <div className="text-[11px] text-blue-200 text-right">
                  Butuh {levelInfo.nextLevelXP - user.totalXP} poin lagi untuk naik level
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action & Last Activity Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Card 1: Last Studied Topic */}
        {lastTopic && (
          <div className="bg-white rounded-2xl p-5 border border-blue-100/80 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">
                  📖 Materi Terakhir
                </span>
                <span className="text-xs text-slate-400">
                  Sem. {lastTopic.semester}
                </span>
              </div>
              <h3 className="font-bold text-slate-800 text-base leading-snug group-hover:text-blue-600 transition-colors">
                {lastTopic.title}
              </h3>
              <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                {lastTopic.description}
              </p>
            </div>

            <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => onOpenTopic(lastTopic)}
                className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Lanjut Belajar</span>
              </button>
            </div>
          </div>
        )}

        {/* Card 2: Last Quiz Score */}
        <div className="bg-white rounded-2xl p-5 border border-blue-100/80 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg">
                📝 Kuis Terakhir
              </span>
              {lastQuiz && (
                <span className="text-xs text-slate-400">
                  {new Date(lastQuiz.date).toLocaleDateString('id-ID', { month: 'short', day: 'numeric' })}
                </span>
              )}
            </div>

            {lastQuiz ? (
              <div className="space-y-2">
                <h3 className="font-bold text-slate-800 text-base truncate">
                  {lastQuiz.topicTitle}
                </h3>
                <div className="flex items-center gap-3">
                  <div className="text-2xl font-black text-blue-600">
                    {lastQuiz.score}
                    <span className="text-xs text-slate-400 font-normal"> / 100</span>
                  </div>
                  <div className="text-xs text-slate-500 font-medium">
                    ✅ {lastQuiz.correctCount} Benar • ❌ {lastQuiz.incorrectCount} Salah
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-3 text-slate-400 text-xs">
                Belum ada kuis yang dikerjakan. Mulai kuis pertamamu dan dapatkan +100 poin!
              </div>
            )}
          </div>

          <div className="pt-4 mt-3 border-t border-slate-100">
            <button
              onClick={() => onNavigate('quizzes')}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <span>{lastQuiz ? 'Buka Riwayat Kuis' : 'Mulai Kuis Sekarang'}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Card 3: Quick Grade Statistics */}
        <div className="bg-white rounded-2xl p-5 border border-blue-100/80 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg">
                📊 Statistik Belajar
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-2">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="text-xs text-slate-500">Materi Selesai</div>
                <div className="text-lg font-bold text-slate-800 mt-0.5">
                  {completedTopicsCount} <span className="text-xs text-slate-400">topik</span>
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="text-xs text-slate-500">Total Kuis</div>
                <div className="text-lg font-bold text-slate-800 mt-0.5">
                  {user.completedQuizzesCount || 0} <span className="text-xs text-slate-400">sesi</span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 mt-3 border-t border-slate-100">
            <button
              onClick={() => onNavigate('progress')}
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <span>Lihat Detail Progress</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Standalone PC HTML Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-5 sm:p-6 border border-slate-800 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-white/10 text-sky-400 flex items-center justify-center text-xl shrink-0">
            <Laptop className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base sm:text-lg text-white">
                Bisa Digunakan Sebagai File HTML di PC / Laptop
              </h3>
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 uppercase tracking-wider">
                100% Offline
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5 max-w-xl">
              Unduh 1 file <code className="text-sky-300 font-mono">AV-Learning-Offline.html</code> lalu klik 2x di komputer Anda untuk belajar tanpa internet.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenDownloadPc}
          className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 shrink-0 cursor-pointer transition-all"
        >
          <Download className="w-4 h-4" />
          <span>Download File HTML PC</span>
        </button>
      </div>

      {/* Recommended Topics Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-800">
              💡 Rekomendasi Materi untuk Kelas {user.grade}
            </h2>
            <p className="text-xs text-slate-500">
              Topik pilihan yang disesuaikan dengan tingkat kesulitan dan kurikulummu
            </p>
          </div>

          <button
            onClick={() => onNavigate('subjects')}
            className="text-xs sm:text-sm font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            <span>Semua Mata Pelajaran</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {recommendedTopics.map((topic) => {
            const subject = subjects.find(s => s.id === topic.subjectId);
            return (
              <div
                key={topic.id}
                className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs hover:border-blue-300 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                      {subject?.name || 'Mata Pelajaran'}
                    </span>
                    <span className="text-[11px] font-medium text-slate-400">
                      ⏱️ {topic.estimatedMinutes} Menit
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-800 text-sm sm:text-base mt-2 line-clamp-1">
                    {topic.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                    {topic.description}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => onOpenTopic(topic)}
                    className="flex-1 py-2 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold transition-colors"
                  >
                    📖 Baca Materi
                  </button>
                  <button
                    onClick={() => onStartQuiz(topic)}
                    className="py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-2xs transition-colors"
                    title="Kuis 10 Soal"
                  >
                    🎯 Kuis
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Subject Shortcuts Grid for Current Grade */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg sm:text-xl font-bold text-slate-800">
            📚 Mata Pelajaran Kelas {user.grade} {user.educationLevel}
          </h2>
          <span className="text-xs text-slate-500">
            Pilih mata pelajaran untuk melihat Semester 1 & 2
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-4">
          {subjects.map((sub) => (
            <div
              key={sub.id}
              onClick={() => onOpenSubject(sub.id)}
              className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs hover:border-blue-400 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500/10 to-indigo-500/20 text-2xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  {sub.icon}
                </div>
                <h3 className="font-bold text-slate-800 text-sm sm:text-base leading-tight group-hover:text-blue-600 transition-colors">
                  {sub.name}
                </h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                  {sub.description}
                </p>
              </div>

              <div className="mt-4 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-blue-600 font-semibold">
                <span>📘 Sem 1 & 2</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
