import React from 'react';
import { Subject, Topic, UserProfile } from '../types';
import { 
  ArrowLeft, 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  HelpCircle, 
  Lightbulb, 
  PenTool, 
  Sparkles, 
  Star, 
  Target 
} from 'lucide-react';

interface MaterialStudyViewProps {
  user: UserProfile;
  topic: Topic;
  subject?: Subject;
  onBack: () => void;
  onStartQuiz: (topic: Topic) => void;
  onStartEssay: (topic: Topic) => void;
}

export const MaterialStudyView: React.FC<MaterialStudyViewProps> = ({
  user,
  topic,
  subject,
  onBack,
  onStartQuiz,
  onStartEssay
}) => {
  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Breadcrumb & Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs sm:text-sm font-semibold hover:bg-slate-50 transition-colors shadow-2xs cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Daftar Materi</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 font-bold text-xs">
            {subject?.name || 'Mata Pelajaran'} • Kelas {topic.grade}
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-xs">
            Semester {topic.semester}
          </span>
        </div>
      </div>

      {/* Main Material Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 md:p-10 border border-blue-100 shadow-sm space-y-8">
        {/* Title Header */}
        <div className="border-b border-slate-100 pb-6 space-y-3">
          <div className="flex items-center gap-2">
            <span className={`px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider ${
              topic.difficulty === 'mudah'
                ? 'bg-emerald-100 text-emerald-800'
                : topic.difficulty === 'sedang'
                ? 'bg-amber-100 text-amber-800'
                : 'bg-rose-100 text-rose-800'
            }`}>
              Tingkat: {topic.difficulty}
            </span>
            <span className="text-xs text-slate-400 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              Estimasi Waktu: {topic.estimatedMinutes} Menit
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
            {topic.title}
          </h1>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
            {topic.description}
          </p>
        </div>

        {/* Section 1: Penjelasan Mendalam */}
        <div className="space-y-3">
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            <span>Penjelasan Materi</span>
          </h2>
          <div className="text-sm sm:text-base text-slate-700 leading-relaxed bg-blue-50/40 p-5 rounded-2xl border border-blue-100/80">
            {topic.explanation}
          </div>
        </div>

        {/* Section 2: Konsep Utama & Contoh */}
        <div className="space-y-4">
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-600" />
            <span>Konsep Utama & Contoh Kasus</span>
          </h2>

          <div className="grid grid-cols-1 gap-4">
            {topic.coreConcepts.map((concept, idx) => (
              <div
                key={idx}
                className="bg-slate-50/80 rounded-2xl p-5 border border-slate-200/80 space-y-2.5"
              >
                <h3 className="font-bold text-slate-800 text-base flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">
                    {idx + 1}
                  </span>
                  <span>{concept.title}</span>
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {concept.description}
                </p>
                {concept.example && (
                  <div className="p-3 bg-white rounded-xl border border-blue-100 text-xs sm:text-sm text-blue-900 font-medium space-y-1">
                    <span className="font-bold text-blue-700 block">💡 Contoh Perhitungan / Kasus:</span>
                    <span>{concept.example}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Section 3: Penerapan Nyata dalam Kehidupan Sehari-hari */}
        <div className="space-y-3">
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-amber-500" />
            <span>Contoh Penerapan Nyata</span>
          </h2>
          <div className="p-5 rounded-2xl bg-amber-50/50 border border-amber-200 text-xs sm:text-sm text-amber-950 leading-relaxed">
            {topic.realWorldExample}
          </div>
        </div>

        {/* Section 4: Ringkasan Materi */}
        <div className="space-y-3">
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>Ringkasan Inti Materi</span>
          </h2>
          <div className="bg-emerald-50/40 rounded-2xl p-5 border border-emerald-100">
            <ul className="space-y-2 text-xs sm:text-sm text-emerald-950">
              {topic.summary.map((point, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold mt-0.5">•</span>
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Section 5: Tips Belajar Cepat */}
        <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-100 text-xs sm:text-sm text-indigo-900 flex items-start gap-3">
          <span className="text-xl">🎯</span>
          <div>
            <span className="font-bold block text-indigo-800">Tips Belajar Cepat:</span>
            <p className="text-slate-600 mt-0.5">{topic.studyTips}</p>
          </div>
        </div>

        {/* Action Call to Action Footer */}
        <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-500 text-center sm:text-left">
            Siap menguji pemahamanmu? Dapatkan hingga <strong className="text-blue-600">+100 Poin XP</strong> di kuis!
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={() => onStartEssay(topic)}
              className="flex-1 sm:flex-initial py-3 px-5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs sm:text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <PenTool className="w-4 h-4" />
              <span>Latihan Essay</span>
            </button>
            <button
              onClick={() => onStartQuiz(topic)}
              className="flex-1 sm:flex-initial py-3 px-6 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Mulai Kuis (10 Soal)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
