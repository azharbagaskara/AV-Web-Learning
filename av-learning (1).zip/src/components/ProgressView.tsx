import React from 'react';
import { EssayHistoryItem, ProgressItem, QuizHistoryItem, Subject, Topic, UserProfile } from '../types';
import { calculateLevel } from '../utils/storage';
import { 
  Award, 
  BookCheck, 
  BookOpen, 
  CheckCircle2, 
  Flame, 
  GraduationCap, 
  LineChart, 
  PieChart, 
  Sparkles, 
  Star, 
  Target, 
  Trophy 
} from 'lucide-react';

interface ProgressViewProps {
  user: UserProfile;
  subjects: Subject[];
  topics: Topic[];
  progressList: ProgressItem[];
  quizHistory: QuizHistoryItem[];
  essayHistory: EssayHistoryItem[];
  onOpenSubject: (subjectId: string) => void;
}

export const ProgressView: React.FC<ProgressViewProps> = ({
  user,
  subjects,
  topics,
  progressList,
  quizHistory,
  essayHistory,
  onOpenSubject
}) => {
  const levelInfo = calculateLevel(user.totalXP);

  // Grade-specific metrics
  const gradeTopics = topics.filter(t => t.grade === user.grade);
  const completedInGrade = progressList.filter(p => p.grade === user.grade && p.isCompleted).length;
  const gradePercent = Math.min(100, Math.round((completedInGrade / Math.max(1, gradeTopics.length)) * 100));

  // Average quiz score
  const avgQuizScore = quizHistory.length > 0
    ? Math.round(quizHistory.reduce((acc, q) => acc + q.score, 0) / quizHistory.length)
    : 0;

  // Level milestones definition
  const milestones = [
    { level: 1, title: 'Pemula Cerdas', minXP: 0, maxXP: 99, icon: '🌱' },
    { level: 2, title: 'Pelajar Aktif', minXP: 100, maxXP: 199, icon: '⭐' },
    { level: 3, title: 'Penjelajah Ilmu', minXP: 200, maxXP: 299, icon: '🚀' },
    { level: 4, title: 'Master Akademik', minXP: 300, maxXP: 399, icon: '🔥' },
    { level: 5, title: 'Sang Bintang Juara', minXP: 400, maxXP: 9999, icon: '👑' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-blue-100/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 font-bold text-xs">
              Laporan Hasil Belajar
            </span>
            <span className="text-xs text-slate-400">•</span>
            <span className="text-xs text-slate-500 font-medium">
              Kelas {user.grade} {user.educationLevel}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight">
            Progress & Statistik Belajar
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
            Pantau pertumbuhan nilai, akumulasi poin pengalaman (XP), tingkat level, dan capaian materi di setiap mata pelajaran.
          </p>
        </div>

        {/* Current Level Badge */}
        <div className="flex items-center gap-3 p-3 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl shrink-0">
          <div className="w-12 h-12 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-xl shadow-xs">
            🏆
          </div>
          <div>
            <div className="text-xs text-amber-800 font-semibold">Tingkat Level</div>
            <div className="text-base font-black text-amber-950">
              Level {levelInfo.level} • {levelInfo.title}
            </div>
            <div className="text-[11px] text-amber-700">
              ⭐ {user.totalXP} Total Poin
            </div>
          </div>
        </div>
      </div>

      {/* 4 Summary Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
        {/* Card 1 */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Rata-Rata Nilai Kuis</span>
            <Target className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-blue-700">
            {avgQuizScore}
            <span className="text-xs text-slate-400 font-normal"> / 100</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Dari {quizHistory.length} sesi kuis 10 soal
          </div>
        </div>

        {/* Card 2 */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Materi Terselesaikan</span>
            <BookCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-700">
            {completedInGrade}
            <span className="text-xs text-slate-400 font-normal"> / {gradeTopics.length}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {gradePercent}% tuntas di Kelas {user.grade}
          </div>
        </div>

        {/* Card 3 */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Latihan Essay</span>
            <Sparkles className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-indigo-700">
            {essayHistory.length}
            <span className="text-xs text-slate-400 font-normal"> essay</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Telah dievaluasi rubrik otomatis
          </div>
        </div>

        {/* Card 4 */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Poin Belajar (XP)</span>
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-600">
            {user.totalXP}
            <span className="text-xs text-slate-400 font-normal"> XP</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            +{levelInfo.nextLevelXP - user.totalXP} XP lagi menuju Level {levelInfo.level + 1}
          </div>
        </div>
      </div>

      {/* Level Milestones Roadmap Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-blue-100/80 shadow-sm space-y-4">
        <h2 className="text-lg sm:text-xl font-bold text-slate-800 flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-500" />
          <span>Tingkatan Level & Milestone Prestasi</span>
        </h2>
        <p className="text-xs text-slate-500">
          Kumpulkan poin dengan menyelesaikan kuis 10 soal (+10 poin/soal benar) dan latihan essay untuk membuka soal-soal lebih menantang!
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 pt-2">
          {milestones.map((m) => {
            const isReached = levelInfo.level >= m.level;
            const isCurrent = levelInfo.level === m.level;

            return (
              <div
                key={m.level}
                className={`p-4 rounded-2xl border-2 transition-all text-center flex flex-col justify-between ${
                  isCurrent
                    ? 'border-blue-600 bg-blue-50/70 shadow-xs'
                    : isReached
                    ? 'border-emerald-300 bg-emerald-50/40'
                    : 'border-slate-200 bg-slate-50/50 opacity-60'
                }`}
              >
                <div>
                  <div className="text-2xl mb-1">{m.icon}</div>
                  <div className="font-extrabold text-sm text-slate-800">
                    Level {m.level}
                  </div>
                  <div className="text-xs font-semibold text-blue-700 mt-0.5">
                    {m.title}
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-black/5 text-[11px] font-medium text-slate-500">
                  {m.minXP} - {m.maxXP >= 9000 ? '400+' : m.maxXP} Poin
                  {isCurrent && (
                    <div className="mt-1 font-bold text-blue-600 bg-blue-100 rounded py-0.5">
                      Level Kamu Sekarang
                    </div>
                  )}
                  {isReached && !isCurrent && (
                    <div className="mt-1 font-bold text-emerald-600">
                      ✓ Tercapai
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Subject Completion Breakdown for Active Grade */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-blue-100/80 shadow-sm space-y-4">
        <h2 className="text-lg sm:text-xl font-bold text-slate-800 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-blue-600" />
          <span>Progress per Mata Pelajaran (Kelas {user.grade})</span>
        </h2>

        <div className="space-y-3 pt-1">
          {subjects.map(sub => {
            const subTopics = topics.filter(t => t.subjectId === sub.id && t.grade === user.grade);
            const subCompleted = progressList.filter(
              p => p.subjectId === sub.id && p.grade === user.grade && p.isCompleted
            ).length;
            const subPercent = Math.min(100, Math.round((subCompleted / Math.max(1, subTopics.length)) * 100));

            return (
              <div
                key={sub.id}
                onClick={() => onOpenSubject(sub.id)}
                className="p-4 rounded-2xl border border-slate-200/80 hover:border-blue-300 bg-white transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{sub.icon}</span>
                    <div>
                      <h4 className="font-bold text-slate-800 text-sm group-hover:text-blue-600 transition-colors">
                        {sub.name}
                      </h4>
                      <span className="text-[11px] text-slate-400">
                        {subCompleted} dari {subTopics.length} materi tuntas
                      </span>
                    </div>
                  </div>

                  <span className="font-bold text-slate-800 text-sm">
                    {subPercent}%
                  </span>
                </div>

                <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 transition-all duration-300"
                    style={{ width: `${subPercent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
