import React, { useState } from 'react';
import { EssayHistoryItem, Subject, Topic, UserProfile } from '../types';
import { 
  ArrowRight, 
  BookOpen, 
  CheckCircle, 
  Eye, 
  History, 
  PenTool, 
  Play, 
  RotateCcw, 
  Sparkles, 
  Star, 
  X 
} from 'lucide-react';

interface EssaysListViewProps {
  user: UserProfile;
  subjects: Subject[];
  topics: Topic[];
  essayHistory: EssayHistoryItem[];
  onStartEssay: (topic: Topic) => void;
}

export const EssaysListView: React.FC<EssaysListViewProps> = ({
  user,
  subjects,
  topics,
  essayHistory,
  onStartEssay
}) => {
  const [activeTab, setActiveTab] = useState<'available' | 'history'>('available');
  const [selectedSemester, setSelectedSemester] = useState<1 | 2>(1);
  const [selectedReviewItem, setSelectedReviewItem] = useState<EssayHistoryItem | null>(null);

  const gradeTopics = topics.filter(t => {
    const matchesGrade = t.grade === user.grade;
    const matchesSemester = t.semester === selectedSemester;
    return matchesGrade && matchesSemester;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-blue-100/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-xs">
              Latihan Menulis Essay & Uraian
            </span>
            <span className="text-xs text-slate-400">•</span>
            <span className="text-xs text-slate-500 font-medium">
              Kelas {user.grade} {user.educationLevel}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight">
            Latihan Soal Essay
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
            Tuliskan pemahaman konsepmu secara terstruktur. Sistem rubrik otomatis akan menilai argumen, kata kunci, dan memberikan feedback komprehensif!
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 rounded-2xl shrink-0">
          <button
            onClick={() => setActiveTab('available')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'available'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            ✍️ Daftar Soal
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Riwayat Essay ({essayHistory.length})</span>
          </button>
        </div>
      </div>

      {/* Available Essay Topics */}
      {activeTab === 'available' && (
        <div className="space-y-5">
          {/* Semester Selector */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedSemester(1)}
              className={`py-2 px-4 rounded-xl text-xs font-bold transition-all ${
                selectedSemester === 1
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              📘 Semester 1
            </button>
            <button
              onClick={() => setSelectedSemester(2)}
              className={`py-2 px-4 rounded-xl text-xs font-bold transition-all ${
                selectedSemester === 2
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              📗 Semester 2
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {gradeTopics.map(topic => {
              const subject = subjects.find(s => s.id === topic.subjectId);
              const pastAttempts = essayHistory.filter(e => e.topicId === topic.id);
              const bestScore = pastAttempts.length > 0
                ? Math.max(...pastAttempts.map(e => e.score))
                : null;

              return (
                <div
                  key={topic.id}
                  className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700">
                        {subject?.name || 'Mata Pelajaran'}
                      </span>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                        Rubrik Otomatis
                      </span>
                    </div>

                    <h3 className="font-bold text-slate-800 text-base mt-2 line-clamp-1">
                      {topic.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                      {topic.description}
                    </p>

                    {bestScore !== null && (
                      <div className="mt-3 p-2.5 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-between text-xs">
                        <span className="text-indigo-800 font-medium">Nilai Essay Terakhir:</span>
                        <span className="font-black text-indigo-700 text-sm">
                          {bestScore} / 100
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <button
                      onClick={() => onStartEssay(topic)}
                      className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <PenTool className="w-4 h-4" />
                      <span>{bestScore !== null ? 'Tulis Ulang Essay' : 'Mulai Latihan Essay'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Essay History */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          {essayHistory.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
              <div className="w-16 h-16 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto text-2xl">
                ✍️
              </div>
              <h3 className="font-bold text-slate-800 text-lg">Belum Ada Riwayat Essay</h3>
              <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">
                Kamu belum menyelesaikan latihan essay. Pilih topik materi di atas untuk mulai menulis dan dinilai!
              </p>
              <button
                onClick={() => setActiveTab('available')}
                className="mt-2 py-2.5 px-5 rounded-xl bg-indigo-600 text-white font-bold text-xs shadow-xs"
              >
                Pilih Soal Essay
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {essayHistory.map(item => (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs hover:border-indigo-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-50 text-indigo-700">
                        {item.subjectName} • Kelas {item.grade}
                      </span>
                      <span className="text-xs text-slate-400">
                        {new Date(item.date).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric'
                        })}
                      </span>
                    </div>

                    <h4 className="font-bold text-slate-800 text-base">
                      {item.topicTitle}
                    </h4>

                    <p className="text-xs text-slate-500 line-clamp-1 italic">
                      "{item.userAnswer}"
                    </p>
                  </div>

                  <div className="flex items-center gap-3 self-end sm:self-center">
                    <div className="text-right">
                      <div className="text-2xl font-black text-indigo-600">
                        {item.score}
                        <span className="text-xs text-slate-400 font-normal"> / 100</span>
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedReviewItem(item)}
                      className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Detail</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Review Modal for Essay */}
      {selectedReviewItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            onClick={() => setSelectedReviewItem(null)}
          />

          <div className="relative w-full max-w-2xl max-h-[85vh] bg-white rounded-3xl shadow-2xl overflow-hidden z-10 flex flex-col animate-in zoom-in-95 duration-200">
            <div className="bg-gradient-to-r from-indigo-600 to-blue-700 p-5 text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-base sm:text-lg">
                  Detail Evaluasi Essay: {selectedReviewItem.topicTitle}
                </h3>
                <p className="text-xs text-indigo-100">
                  Nilai: {selectedReviewItem.score}/100 • +{selectedReviewItem.pointsEarned} Poin
                </p>
              </div>
              <button
                onClick={() => setSelectedReviewItem(null)}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs sm:text-sm">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <strong className="text-slate-800 block mb-1">Pertanyaan Essay:</strong>
                <p className="text-slate-700">{selectedReviewItem.questionText}</p>
              </div>

              <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-100">
                <strong className="text-indigo-900 block mb-1">Jawaban Kamu:</strong>
                <p className="text-slate-800 whitespace-pre-line leading-relaxed">{selectedReviewItem.userAnswer}</p>
              </div>

              <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-100">
                <strong className="text-emerald-900 block mb-1">Feedback Evaluasi:</strong>
                <p className="text-slate-800">{selectedReviewItem.feedback}</p>
              </div>

              <div className="space-y-1.5">
                <strong className="text-slate-700 block">Kata Kunci yang Ditemukan:</strong>
                <div className="flex flex-wrap gap-1.5">
                  {selectedReviewItem.matchedKeywords?.map((kw, i) => (
                    <span key={i} className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-xs font-bold">
                      ✓ {kw}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
