import React, { useState } from 'react';
import { QuizHistoryItem, Subject, Topic, UserProfile } from '../types';
import { 
  ArrowRight, 
  Calendar, 
  CheckCircle, 
  ChevronRight, 
  Eye, 
  Filter, 
  History, 
  Layers, 
  Play, 
  RotateCcw, 
  Search, 
  Sparkles, 
  Star, 
  Trophy, 
  X 
} from 'lucide-react';

interface QuizzesListViewProps {
  user: UserProfile;
  subjects: Subject[];
  topics: Topic[];
  quizHistory: QuizHistoryItem[];
  onStartQuiz: (topic: Topic) => void;
}

export const QuizzesListView: React.FC<QuizzesListViewProps> = ({
  user,
  subjects,
  topics,
  quizHistory,
  onStartQuiz
}) => {
  const [activeTab, setActiveTab] = useState<'available' | 'history'>('available');
  const [selectedSemester, setSelectedSemester] = useState<1 | 2>(1);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('all');
  const [reviewItem, setReviewItem] = useState<QuizHistoryItem | null>(null);

  // Filter available topics for current grade
  const gradeTopics = topics.filter(t => {
    const matchesGrade = t.grade === user.grade;
    const matchesSemester = t.semester === selectedSemester;
    const matchesSubject = selectedSubjectId === 'all' || t.subjectId === selectedSubjectId;
    return matchesGrade && matchesSemester && matchesSubject;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-blue-100/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 font-bold text-xs">
              Kuis Pilihan Ganda (10 Soal Acak)
            </span>
            <span className="text-xs text-slate-400">•</span>
            <span className="text-xs text-slate-500 font-medium">
              Kelas {user.grade} {user.educationLevel}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight">
            Tantangan Kuis 10 Soal
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
            Tiap sesi kuis terdiri dari tepat 10 soal acak berbobot. Selesaikan kuis untuk mengumpulkan poin, naik level, dan membuka soal tingkat lanjut!
          </p>
        </div>

        {/* Tab Switcher: Daftar Kuis vs Riwayat */}
        <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 rounded-2xl shrink-0">
          <button
            onClick={() => setActiveTab('available')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'available'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            🎯 Daftar Kuis
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Riwayat Nilai ({quizHistory.length})</span>
          </button>
        </div>
      </div>

      {/* ========================================== */}
      {/* TAB 1: AVAILABLE QUIZZES                   */}
      {/* ========================================== */}
      {activeTab === 'available' && (
        <div className="space-y-5">
          {/* Filter Bar: Semester & Subject */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            {/* Semester Buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSelectedSemester(1)}
                className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all ${
                  selectedSemester === 1
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                📘 Semester 1
              </button>
              <button
                onClick={() => setSelectedSemester(2)}
                className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all ${
                  selectedSemester === 2
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                📗 Semester 2
              </button>
            </div>

            {/* Subject Select Dropdown */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600 hidden sm:inline">Mata Pelajaran:</span>
              <select
                value={selectedSubjectId}
                onChange={(e) => setSelectedSubjectId(e.target.value)}
                className="py-2 px-3 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Semua Mata Pelajaran</option>
                {subjects.map(sub => (
                  <option key={sub.id} value={sub.id}>{sub.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Quiz Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {gradeTopics.map(topic => {
              const subject = subjects.find(s => s.id === topic.subjectId);
              const pastAttempts = quizHistory.filter(q => q.topicId === topic.id);
              const bestScore = pastAttempts.length > 0 
                ? Math.max(...pastAttempts.map(q => q.score))
                : null;

              return (
                <div
                  key={topic.id}
                  className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs hover:border-blue-300 hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-700">
                        {subject?.name || 'Mata Pelajaran'}
                      </span>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                        10 Soal
                      </span>
                    </div>

                    <h3 className="font-bold text-slate-800 text-base mt-2 line-clamp-1">
                      {topic.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                      {topic.description}
                    </p>

                    {bestScore !== null && (
                      <div className="mt-3 p-2.5 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-between text-xs">
                        <span className="text-emerald-800 font-medium">Nilai Terbaik:</span>
                        <span className="font-black text-emerald-700 text-sm">
                          {bestScore} / 100
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <button
                      onClick={() => onStartQuiz(topic)}
                      className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-white" />
                      <span>{bestScore !== null ? 'Ulangi Kuis (10 Soal)' : 'Mulai Kuis 10 Soal'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* TAB 2: QUIZ HISTORY                        */}
      {/* ========================================== */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          {quizHistory.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
              <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto text-2xl">
                📝
              </div>
              <h3 className="font-bold text-slate-800 text-lg">Belum Ada Riwayat Kuis</h3>
              <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">
                Kamu belum menyelesaikan kuis apapun. Pilih salah satu modul kuis di atas untuk mengumpulkan nilai dan poin!
              </p>
              <button
                onClick={() => setActiveTab('available')}
                className="mt-2 py-2.5 px-5 rounded-xl bg-blue-600 text-white font-bold text-xs shadow-xs"
              >
                Mulai Kuis Pertama
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {quizHistory.map(item => (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs hover:border-blue-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-blue-50 text-blue-700">
                        {item.subjectName} • Kelas {item.grade}
                      </span>
                      <span className="text-xs text-slate-400">
                        {new Date(item.date).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>

                    <h4 className="font-bold text-slate-800 text-base">
                      {item.topicTitle}
                    </h4>

                    <div className="flex items-center gap-3 text-xs text-slate-600">
                      <span className="text-emerald-600 font-semibold">
                        ✅ {item.correctCount} Benar
                      </span>
                      <span className="text-rose-600 font-semibold">
                        ❌ {item.incorrectCount} Salah
                      </span>
                      <span className="text-amber-700 font-semibold flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-amber-500" />
                        +{item.pointsEarned} Poin
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 self-end sm:self-center">
                    <div className="text-right">
                      <div className="text-2xl font-black text-blue-600">
                        {item.score}
                        <span className="text-xs text-slate-400 font-normal"> / 100</span>
                      </div>
                    </div>

                    <button
                      onClick={() => setReviewItem(item)}
                      className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Review</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Review Modal for Past Quiz */}
      {reviewItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            onClick={() => setReviewItem(null)}
          />

          <div className="relative w-full max-w-2xl max-h-[85vh] bg-white rounded-3xl shadow-2xl overflow-hidden z-10 flex flex-col animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-5 text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-base sm:text-lg">
                  Review Kuis: {reviewItem.topicTitle}
                </h3>
                <p className="text-xs text-blue-100">
                  Nilai {reviewItem.score}/100 • {reviewItem.correctCount} Benar • {reviewItem.incorrectCount} Salah
                </p>
              </div>
              <button
                onClick={() => setReviewItem(null)}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              {reviewItem.answersReview?.map((rev, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl border ${
                    rev.isCorrect ? 'border-emerald-200 bg-emerald-50/40' : 'border-rose-200 bg-rose-50/40'
                  } space-y-2 text-xs sm:text-sm`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">
                      Soal #{idx + 1}: {rev.questionText}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      rev.isCorrect ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {rev.isCorrect ? 'Benar' : 'Salah'}
                    </span>
                  </div>

                  <div className="space-y-1 text-xs">
                    <div>
                      <span className="text-slate-500">Jawabanmu: </span>
                      <span className={rev.isCorrect ? 'font-bold text-emerald-700' : 'font-bold text-rose-700'}>
                        {rev.userAnswer}
                      </span>
                    </div>
                    {!rev.isCorrect && (
                      <div>
                        <span className="text-slate-500">Kunci Jawaban: </span>
                        <span className="font-bold text-emerald-700">
                          {rev.correctAnswer}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="mt-2 p-2.5 rounded-xl bg-white text-xs text-slate-600 border border-slate-100">
                    <span className="font-bold text-blue-700 block mb-0.5">Penjelasan:</span>
                    {rev.explanation}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
