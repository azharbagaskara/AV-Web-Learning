import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Download, 
  FileCode, 
  Globe, 
  Laptop, 
  Monitor, 
  Sparkles, 
  WifiOff, 
  X 
} from 'lucide-react';
import { downloadStandaloneHtml } from '../utils/htmlExporter';

interface DownloadPcModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadPcModal: React.FC<DownloadPcModalProps> = ({ isOpen, onClose }) => {
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  if (!isOpen) return null;

  const handleDownload = async () => {
    setDownloading(true);
    const success = await downloadStandaloneHtml();
    setDownloading(false);
    if (success) {
      setDownloaded(true);
      setTimeout(() => {
        setDownloaded(false);
      }, 4000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-lg rounded-3xl p-6 sm:p-7 shadow-2xl border border-blue-100 relative space-y-5">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 pr-8">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold shadow-md shadow-blue-600/20 shrink-0">
            <Laptop className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">
              Jadikan File HTML di PC
            </h3>
            <p className="text-xs text-slate-500">
              Gunakan AV Learning secara mandiri & offline di komputer/laptop
            </p>
          </div>
        </div>

        {/* Feature Highlights */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-center gap-2.5">
            <WifiOff className="w-5 h-5 text-emerald-600 shrink-0" />
            <div className="text-xs">
              <div className="font-bold text-emerald-950">100% Offline</div>
              <div className="text-emerald-700 text-[11px]">Tanpa kuota internet</div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-blue-50 border border-blue-100 flex items-center gap-2.5">
            <FileCode className="w-5 h-5 text-blue-600 shrink-0" />
            <div className="text-xs">
              <div className="font-bold text-blue-950">Single File HTML</div>
              <div className="text-blue-700 text-[11px]">Tinggal klik 2x langsung jalan</div>
            </div>
          </div>
        </div>

        {/* 3 Step Instructions */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
          <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            📋 Cara Penggunaan di PC / Laptop:
          </div>

          <ol className="text-xs text-slate-600 space-y-2 pl-4 list-decimal marker:text-blue-600 marker:font-bold">
            <li>
              Klik tombol <strong className="text-slate-800">"Download File HTML"</strong> di bawah ini.
            </li>
            <li>
              File <code className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 font-mono text-[11px]">AV-Learning-Offline.html</code> akan otomatis tersimpan di folder <em>Downloads</em> PC Anda.
            </li>
            <li>
              Klik 2x pada file tersebut di PC untuk langsung membukanya di browser (<strong>Chrome, Edge, Firefox, Safari</strong>).
            </li>
            <li>
              Semua materi SD–SMA, kuis 10 soal, essay, dan fitur ganti kelas langsung dapat digunakan sepenuhnya!
            </li>
          </ol>
        </div>

        {/* Action Download Button */}
        <div className="space-y-2 pt-1">
          <button
            onClick={handleDownload}
            disabled={downloading}
            className={`w-full py-3.5 px-5 rounded-2xl font-extrabold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
              downloaded
                ? 'bg-emerald-600 text-white shadow-emerald-600/20'
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-600/20'
            }`}
          >
            {downloaded ? (
              <>
                <CheckCircle2 className="w-5 h-5" />
                <span>Berhasil Diunduh! Cek Folder Downloads PC</span>
              </>
            ) : downloading ? (
              <span>Menyiapkan File HTML...</span>
            ) : (
              <>
                <Download className="w-5 h-5" />
                <span>Download File HTML (AV-Learning-Offline.html)</span>
              </>
            )}
          </button>

          <p className="text-center text-[11px] text-slate-400">
            Kompatibel untuk Windows 10/11, macOS, dan Linux.
          </p>
        </div>
      </div>
    </div>
  );
};
