import React, { useState } from 'react';
import { EssayHistoryItem, EssayQuestion, Subject, Topic, UserProfile } from '../types';
import { evaluateEssay, getEssayForTopic } from '../data/essayBank';
import { addXPToProfile, saveEssayHistory, saveTopicProgress } from '../utils/storage';
import { triggerFireworks } from '../utils/confetti';
import { 
  ArrowLeft, 
  Award, 
  BookOpen, 
  Check, 
  CheckCircle, 
  HelpCircle, 
  PenTool, 
  RefreshCw, 
  RotateCcw, 
  Send, 
  Sparkles, 
  Star, 
  Trophy 
} from 'lucide-react';

interface EssayPracticeViewProps {
  user: UserProfile;
  topic: Topic;
  subject?: Subject;
  onFinishEssay: (updatedUser: UserProfile) => void;
  onBackToTopic: () => void;
  onStartQuiz: (topic: Topic) => void;
}

export const EssayPracticeView: React.FC<EssayPracticeViewProps> = ({
  user,
  topic,
  subject,
  onFinishEssay,
  onBackToTopic,
  onStartQuiz
}) => {
  const essayQuestion: EssayQuestion = getEssayForTopic(topic.id);
  const [userText, setUserText] = useState('');
  const [isEvaluated, setIsEvaluated] = useState(false);
  const [evaluation, setEvaluation] = useState<{
    score: number;
    feedback: string;
    matchedKeywords: string[];
    pointsEarned: number;
    leveledUp: boolean;
    oldLevel: number;
    newLevel: number;
    newTotalXP: number;
  } | null>(null);

  const handleSubmitEssay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userText.trim()) return;

    const result = evaluateEssay(essayQuestion, userText);

    // Save progress
    saveTopicProgress(
      user.educationLevel,
      user.grade,
      topic.subjectId,
      topic.semester,
      topic.id,
      false,
      result.score
    );

    // Add XP
    const xpResult = addXPToProfile(
      result.pointsEarned,
      topic.id,
      topic.title,
      subject?.name || 'Mata Pelajaran'
    );

    // Save essay history
    const historyItem: EssayHistoryItem = {
      id: `essay_${Date.now()}`,
      date: new Date().toISOString(),
      jenjang: user.educationLevel,
      grade: user.grade,
      subjectId: topic.subjectId,
      subjectName: subject?.name || 'Mata Pelajaran',
      semester: topic.semester,
      topicId: topic.id,
      topicTitle: topic.title,
      questionText: essayQuestion.question,
      userAnswer: userText,
      score: result.score,
      feedback: result.feedback,
      matchedKeywords: result.matchedKeywords,
      pointsEarned: result.pointsEarned
    };
    saveEssayHistory(historyItem);

    setEvaluation({
      score: result.score,
      feedback: result.feedback,
      matchedKeywords: result.matchedKeywords,
      pointsEarned: result.pointsEarned,
      leveledUp: xpResult.leveledUp,
      oldLevel: xpResult.oldLevel,
      newLevel: xpResult.newLevel,
      newTotalXP: xpResult.profile.totalXP
    });

    setIsEvaluated(true);
    triggerFireworks();
    onFinishEssay(xpResult.profile);
  };

  const handleReset = () => {
    setUserText('');
    setIsEvaluated(false);
    setEvaluation(null);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToTopic}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs sm:text-sm font-semibold hover:bg-slate-50 transition-colors shadow-2xs cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Materi</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-xs">
            ✍️ Latihan Essay
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 font-bold text-xs">
            Kelas {topic.grade} • Sem {topic.semester}
          </span>
        </div>
      </div>

      {/* Main Question & Prompt Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 md:p-10 border border-blue-100 shadow-sm space-y-6">
        <div className="space-y-2 border-b border-slate-100 pb-5">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-indigo-100 text-indigo-800">
              Soal Uraian / Essay
            </span>
            <span className="text-xs text-slate-400">
              {topic.title}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
            {essayQuestion.question}
          </h2>
        </div>

        {/* Rubric Criteria Table */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2.5">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <span>📋 Kriteria Penilaian Rubrik</span>
          </h3>
          <div className="space-y-1.5">
            {essayQuestion.rubric.map((r, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs text-slate-600 bg-white p-2.5 rounded-xl border border-slate-100">
                <span>{r.criteria}</span>
                <span className="font-bold text-indigo-600 shrink-0 ml-2">Maks. {r.points} Poin</span>
              </div>
            ))}
          </div>
        </div>

        {/* ========================================== */}
        {/* EVALUATED RESULT VIEW                      */}
        {/* ========================================== */}
        {isEvaluated && evaluation && (
          <div className="space-y-6 pt-2 animate-in zoom-in-95 duration-200">
            {/* Score & Feedback Card */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-200 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                    Hasil Penilaian Otomatis
                  </span>
                  <div className="text-3xl font-black text-indigo-900 mt-1">
                    Nilai: {evaluation.score} <span className="text-sm font-normal text-slate-500">/ 100</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 rounded-xl bg-amber-100 border border-amber-200 text-amber-900 font-black text-sm flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-600" />
                    +{evaluation.pointsEarned} Poin XP
                  </div>
                </div>
              </div>

              {/* Feedback Note */}
              <div className="p-4 bg-white rounded-xl border border-indigo-100 text-xs sm:text-sm text-slate-700 leading-relaxed">
                <strong className="text-indigo-800 block mb-1">Evaluasi Guru:</strong>
                {evaluation.feedback}
              </div>

              {/* Matched Keywords */}
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-700">
                  Kata Kunci Konsep yang Teridentifikasi:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {evaluation.matchedKeywords.length > 0 ? (
                    evaluation.matchedKeywords.map((kw, idx) => (
                      <span key={idx} className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold flex items-center gap-1">
                        <Check className="w-3 h-3 text-emerald-600" />
                        {kw}
                      </span>
                    ))
                  ) : (
                    <span className="text-xs text-slate-400 italic">
                      Belum banyak istilah materi yang digunakan.
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Reference Answer Comparison */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-3">
              <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <span>Referensi Jawaban Ideal:</span>
              </h4>
              <div className="p-4 rounded-xl bg-slate-50 text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line border border-slate-100 font-mono">
                {essayQuestion.referenceAnswer}
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={handleReset}
                className="py-3 px-5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs sm:text-sm transition-colors flex items-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Tulis Ulang Jawaban</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onStartQuiz(topic)}
                  className="py-3 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-600/20 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Coba Kuis (10 Soal)</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================== */}
        {/* ESSAY WRITING INPUT VIEW                   */}
        {/* ========================================== */}
        {!isEvaluated && (
          <form onSubmit={handleSubmitEssay} className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Tulis Jawabanmu di Sini:
                </label>
                <span className="text-xs text-slate-400">
                  {userText.trim().split(/\s+/).filter(Boolean).length} kata • {userText.length} karakter
                </span>
              </div>

              <textarea
                value={userText}
                onChange={(e) => setUserText(e.target.value)}
                placeholder="Tuliskan uraian konsep, langkah-langkah, rumus, atau contoh nyata secara runtut dan jelas..."
                rows={8}
                className="w-full p-4 rounded-2xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 text-xs sm:text-sm leading-relaxed transition-all"
                required
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-slate-500">
                💡 Tip: Sertakan istilah teknis materi untuk mendapatkan poin rubrik maksimal!
              </span>

              <button
                type="submit"
                disabled={!userText.trim() || userText.trim().length < 10}
                className="py-3 px-6 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs sm:text-sm shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Kirim & Nilai Essay</span>
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
