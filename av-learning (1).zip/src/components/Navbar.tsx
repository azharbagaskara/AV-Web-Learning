import React from 'react';
import { calculateLevel } from '../utils/storage';
import { UserProfile } from '../types';
import { BookOpen, Download, GraduationCap, Laptop, Menu, Sparkles, Trophy, X } from 'lucide-react';

interface NavbarProps {
  user: UserProfile | null;
  activeView: string;
  onNavigate: (view: string) => void;
  onOpenChangeClass: () => void;
  onOpenMobileMenu: () => void;
  onOpenDownloadPc: () => void;
  mobileMenuOpen: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  activeView,
  onNavigate,
  onOpenChangeClass,
  onOpenMobileMenu,
  onOpenDownloadPc,
  mobileMenuOpen
}) => {
  const levelInfo = user ? calculateLevel(user.totalXP) : null;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-blue-100 shadow-sm transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenMobileMenu}
              className="md:hidden p-2 rounded-xl text-slate-600 hover:text-blue-600 hover:bg-blue-50 focus:outline-none transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            <div 
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-2.5 cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white font-extrabold text-lg shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
                AV
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-slate-900 text-lg leading-tight tracking-tight flex items-center gap-1.5">
                  AV Learning
                  <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 tracking-wider">
                    Edu
                  </span>
                </span>
                <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                  Belajar jadi lebih gampang
                </span>
              </div>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            <button
              onClick={() => onNavigate('dashboard')}
              className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                activeView === 'dashboard'
                  ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              🏠 Beranda
            </button>
            <button
              onClick={() => onNavigate('subjects')}
              className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                activeView === 'subjects' || activeView === 'study'
                  ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              📚 Materi
            </button>
            <button
              onClick={() => onNavigate('quizzes')}
              className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                activeView === 'quizzes' || activeView === 'quiz-active'
                  ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              📝 Kuis (10 Soal)
            </button>
            <button
              onClick={() => onNavigate('essays')}
              className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                activeView === 'essays' || activeView === 'essay-active'
                  ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              ✍️ Essay
            </button>
            <button
              onClick={() => onNavigate('progress')}
              className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                activeView === 'progress'
                  ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              📊 Progress
            </button>
            <button
              onClick={() => onNavigate('profile')}
              className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                activeView === 'profile'
                  ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              👤 Profil
            </button>
          </nav>

          {/* User Stats & Class Badge */}
          {user && (
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Download PC HTML Button */}
              <button
                onClick={onOpenDownloadPc}
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-xs hover:shadow-sm transition-all cursor-pointer"
                title="Download file HTML untuk dibuka di PC secara offline"
              >
                <Laptop className="w-3.5 h-3.5 text-sky-400" />
                <span>File HTML PC</span>
              </button>

              {/* Grade Badge with Change Class Trigger */}
              <button
                onClick={onOpenChangeClass}
                className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200/80 text-blue-800 text-xs sm:text-sm font-semibold hover:border-blue-300 hover:shadow-xs transition-all"
                title="Klik untuk ganti kelas"
              >
                <GraduationCap className="w-4 h-4 text-blue-600 shrink-0" />
                <span className="truncate max-w-[110px] sm:max-w-none">
                  Kelas {user.grade} {user.educationLevel}
                </span>
                <span className="text-[10px] text-blue-500 font-normal underline hidden sm:inline">
                  Ganti
                </span>
              </button>

              {/* XP & Level Badge */}
              <div 
                onClick={() => onNavigate('progress')}
                className="flex items-center gap-2 px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs sm:text-sm font-bold cursor-pointer hover:bg-amber-100/80 transition-colors shadow-2xs"
              >
                <div className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500 shrink-0" />
                  <span>{user.totalXP} Poin</span>
                </div>
                <div className="w-px h-3.5 bg-amber-300" />
                <div className="flex items-center gap-1 text-amber-700">
                  <Trophy className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>Lvl {levelInfo?.level || 1}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
