import React, { useEffect, useState } from 'react';
import { Question, QuizHistoryItem, Subject, Topic, UserProfile } from '../types';
import { getQuestionsForTopic } from '../data/questionBank';
import { triggerFireworks } from '../utils/confetti';
import { addXPToProfile, calculateLevel, saveQuizHistory, saveTopicProgress } from '../utils/storage';
import { 
  AlertCircle, 
  ArrowLeft, 
  ArrowRight, 
  Award, 
  BookOpen, 
  Check, 
  CheckCircle2, 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  HelpCircle, 
  PenTool, 
  RefreshCw, 
  RotateCcw, 
  Sparkles, 
  Star, 
  Trophy, 
  X, 
  XCircle 
} from 'lucide-react';

interface QuizViewProps {
  user: UserProfile;
  topic: Topic;
  subject?: Subject;
  onFinishQuiz: (updatedUser: UserProfile) => void;
  onBackToTopic: () => void;
  onStartEssay: (topic: Topic) => void;
  onGoHome: () => void;
}

export const QuizView: React.FC<QuizViewProps> = ({
  user,
  topic,
  subject,
  onFinishQuiz,
  onBackToTopic,
  onStartEssay,
  onGoHome
}) => {
  // 10 randomized questions generated from pool
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<(number | null)[]>(Array(10).fill(null));
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [resultData, setResultData] = useState<{
    score: number;
    correctCount: number;
    incorrectCount: number;
    pointsEarned: number;
    leveledUp: boolean;
    oldLevel: number;
    newLevel: number;
    newTotalXP: number;
  } | null>(null);

  // Initialize questions on mount
  useEffect(() => {
    startNewQuizSession();
  }, [topic.id]);

  const startNewQuizSession = () => {
    // Generates exactly 10 questions with shuffled choices and dynamic difficulty matching user level
    const sessionQuestions = getQuestionsForTopic(topic.id, user.level, 10);
    setQuestions(sessionQuestions);
    setSelectedAnswers(Array(10).fill(null));
    setCurrentIndex(0);
    setIsSubmitted(false);
    setResultData(null);
  };

  const handleSelectOption = (optionIndex: number) => {
    if (isSubmitted) return;
    const updated = [...selectedAnswers];
    updated[currentIndex] = optionIndex;
    setSelectedAnswers(updated);
  };

  const handleSubmitQuiz = () => {
    if (questions.length === 0) return;

    let correct = 0;
    const answersReview = questions.map((q, idx) => {
      const userChoiceIdx = selectedAnswers[idx];
      const isCorrect = userChoiceIdx === q.correctIndex;
      if (isCorrect) correct += 1;

      return {
        questionText: q.question,
        userAnswer: userChoiceIdx !== null ? q.options[userChoiceIdx] : 'Tidak dijawab',
        correctAnswer: q.options[q.correctIndex],
        isCorrect,
        explanation: q.explanation
      };
    });

    const incorrect = 10 - correct;
    const score = Math.round((correct / 10) * 100);
    const pointsEarned = correct * 10; // +10 points per correct answer (up to +100)

    // Save progress to storage
    saveTopicProgress(
      user.educationLevel,
      user.grade,
      topic.subjectId,
      topic.semester,
      topic.id,
      true,
      score
    );

    // Add points & check level up
    const xpResult = addXPToProfile(
      pointsEarned,
      topic.id,
      topic.title,
      subject?.name || 'Mata Pelajaran'
    );

    // Save full quiz history item
    const historyItem: QuizHistoryItem = {
      id: `quiz_${Date.now()}`,
      date: new Date().toISOString(),
      jenjang: user.educationLevel,
      grade: user.grade,
      subjectId: topic.subjectId,
      subjectName: subject?.name || 'Mata Pelajaran',
      semester: topic.semester,
      topicId: topic.id,
      topicTitle: topic.title,
      score,
      correctCount: correct,
      incorrectCount: incorrect,
      totalQuestions: 10,
      pointsEarned,
      userLevelAtQuiz: user.level,
      difficultyUsed: topic.difficulty,
      answersReview
    };
    saveQuizHistory(historyItem);

    setResultData({
      score,
      correctCount: correct,
      incorrectCount: incorrect,
      pointsEarned,
      leveledUp: xpResult.leveledUp,
      oldLevel: xpResult.oldLevel,
      newLevel: xpResult.newLevel,
      newTotalXP: xpResult.profile.totalXP
    });

    setIsSubmitted(true);

    // Trigger fireworks and confetti celebration!
    triggerFireworks();

    // Inform parent of updated user profile
    onFinishQuiz(xpResult.profile);
  };

  if (questions.length === 0) {
    return (
      <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
        <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4" />
        <p className="text-slate-600 font-semibold text-sm">Menyiapkan 10 soal acak untukmu...</p>
      </div>
    );
  }

  const currentQ = questions[currentIndex];
  const optionLetters = ['A', 'B', 'C', 'D'];
  const answeredCount = selectedAnswers.filter(a => a !== null).length;

  // ==========================================
  // VIEW: RESULT & CELEBRATION SCREEN
  // ==========================================
  if (isSubmitted && resultData) {
    const isHighScore = resultData.score >= 80;
    const isMediumScore = resultData.score >= 60 && resultData.score < 80;

    let motivationMsg = '';
    if (isHighScore) {
      motivationMsg = 'Keren! Pemahaman kamu semakin bagus!';
    } else if (isMediumScore) {
      motivationMsg = 'Bagus, terus latihan agar semakin kuat.';
    } else {
      motivationMsg = 'Jangan menyerah. Coba pelajari materinya lagi lalu ulangi kuis.';
    }

    return (
      <div className="max-w-3xl mx-auto space-y-6 pb-12 animate-in zoom-in-95 duration-300">
        {/* Confetti & Result Banner Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 md:p-10 border border-blue-100 shadow-xl text-center space-y-6 relative overflow-hidden">
          {/* Top fireworks decorative icon */}
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-amber-400 via-orange-500 to-pink-500 text-white shadow-lg text-3xl mb-1">
            🎆
          </div>

          <div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-slate-900 tracking-tight">
              {isHighScore ? '🎆 Keren! Kuis Selesai! 🎆' : '🎉 Kuis Selesai! 🎉'}
            </h1>
            <p className="text-slate-600 text-sm sm:text-base mt-2 max-w-md mx-auto font-medium">
              {motivationMsg}
            </p>
          </div>

          {/* Level Up Banner if applicable */}
          {resultData.leveledUp && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white font-bold text-sm sm:text-base shadow-md flex items-center justify-center gap-3 animate-pulse">
              <Trophy className="w-6 h-6 text-yellow-200" />
              <span>
                SELAMAT! Kamu naik ke <strong>Level {resultData.newLevel}</strong>! 🏆
              </span>
            </div>
          )}

          {/* Core Score & Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 pt-2">
            {/* Nilai */}
            <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-100 flex flex-col items-center justify-center">
              <span className="text-xs text-blue-700 font-bold uppercase tracking-wider">Nilai</span>
              <span className="text-3xl font-black text-blue-800 mt-1">
                {resultData.score}
              </span>
              <span className="text-[11px] text-slate-400">dari 100</span>
            </div>

            {/* Benar */}
            <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-100 flex flex-col items-center justify-center">
              <span className="text-xs text-emerald-700 font-bold uppercase tracking-wider flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> Benar
              </span>
              <span className="text-3xl font-black text-emerald-800 mt-1">
                {resultData.correctCount}
              </span>
              <span className="text-[11px] text-slate-400">soal</span>
            </div>

            {/* Salah */}
            <div className="p-4 rounded-2xl bg-rose-50/70 border border-rose-100 flex flex-col items-center justify-center">
              <span className="text-xs text-rose-700 font-bold uppercase tracking-wider flex items-center gap-1">
                <X className="w-3.5 h-3.5" /> Salah
              </span>
              <span className="text-3xl font-black text-rose-800 mt-1">
                {resultData.incorrectCount}
              </span>
              <span className="text-[11px] text-slate-400">soal</span>
            </div>

            {/* Poin Didapat */}
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 flex flex-col items-center justify-center">
              <span className="text-xs text-amber-800 font-bold uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Poin
              </span>
              <span className="text-3xl font-black text-amber-900 mt-1">
                +{resultData.pointsEarned}
              </span>
              <span className="text-[11px] text-slate-500 font-medium">
                Total: ⭐ {resultData.newTotalXP}
              </span>
            </div>
          </div>

          {/* Quick Buttons */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={startNewQuizSession}
              className="py-3 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-600/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Ulangi Kuis (10 Soal Acak Baru)</span>
            </button>
            <button
              onClick={onBackToTopic}
              className="py-3 px-5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm transition-colors flex items-center gap-2 cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
              <span>Baca Materi</span>
            </button>
            <button
              onClick={() => onStartEssay(topic)}
              className="py-3 px-5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs sm:text-sm transition-colors flex items-center gap-2 cursor-pointer"
            >
              <PenTool className="w-4 h-4" />
              <span>Latihan Essay</span>
            </button>
          </div>
        </div>

        {/* Detailed Question-by-Question Review */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-blue-100 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <h3 className="font-extrabold text-slate-800 text-lg sm:text-xl flex items-center gap-2">
              <span>📋 Pembahasan & Kunci Jawaban (10 Soal)</span>
            </h3>
            <span className="text-xs text-slate-500">
              Evaluasi jawabanmu
            </span>
          </div>

          <div className="space-y-4">
            {questions.map((q, qIdx) => {
              const userChoiceIdx = selectedAnswers[qIdx];
              const isCorrect = userChoiceIdx === q.correctIndex;

              return (
                <div
                  key={q.id}
                  className={`p-5 rounded-2xl border-2 transition-all ${
                    isCorrect
                      ? 'border-emerald-200 bg-emerald-50/30'
                      : 'border-rose-200 bg-rose-50/30'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2.5">
                    <div className="flex items-center gap-2">
                      <span className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                        isCorrect ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
                      }`}>
                        {qIdx + 1}
                      </span>
                      <span className="text-xs font-bold uppercase text-slate-500">
                        Soal {qIdx + 1} / 10
                      </span>
                    </div>

                    <span className={`text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                      isCorrect ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {isCorrect ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                      {isCorrect ? 'Benar (+10 Poin)' : 'Salah'}
                    </span>
                  </div>

                  <p className="font-bold text-slate-800 text-sm sm:text-base leading-snug">
                    {q.question}
                  </p>

                  {/* Options status */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3 text-xs">
                    {q.options.map((opt, optIdx) => {
                      const isOptionCorrect = optIdx === q.correctIndex;
                      const isOptionChosen = optIdx === userChoiceIdx;

                      let optStyle = 'border-slate-200 bg-white text-slate-700';
                      if (isOptionCorrect) {
                        optStyle = 'border-emerald-500 bg-emerald-100/70 text-emerald-900 font-bold';
                      } else if (isOptionChosen && !isOptionCorrect) {
                        optStyle = 'border-rose-400 bg-rose-100/70 text-rose-900 font-semibold line-through';
                      }

                      return (
                        <div
                          key={optIdx}
                          className={`p-2.5 rounded-xl border flex items-center gap-2 ${optStyle}`}
                        >
                          <span className="w-5 h-5 rounded-md bg-black/10 flex items-center justify-center font-bold text-[10px]">
                            {optionLetters[optIdx]}
                          </span>
                          <span className="flex-1">{opt}</span>
                          {isOptionCorrect && <Check className="w-3.5 h-3.5 text-emerald-700 shrink-0" />}
                          {isOptionChosen && !isOptionCorrect && <X className="w-3.5 h-3.5 text-rose-700 shrink-0" />}
                        </div>
                      );
                    })}
                  </div>

                  {/* Explanation box */}
                  <div className="mt-3.5 p-3 rounded-xl bg-white border border-slate-200/80 text-xs text-slate-700 space-y-1">
                    <span className="font-bold text-blue-700 block">💡 Pembahasan:</span>
                    <p className="leading-relaxed">{q.explanation}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // VIEW: ACTIVE 10-QUESTION QUIZ INTERFACE
  // ==========================================
  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Quiz Header Bar */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-blue-100 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <button
            onClick={onBackToTopic}
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Keluar Kuis</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 font-bold text-xs">
              {subject?.name || 'Mata Pelajaran'} • Kelas {topic.grade}
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 font-bold text-xs flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Tingkat: Level {user.level}
            </span>
          </div>
        </div>

        {/* Question Counter and Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs sm:text-sm font-bold">
            <span className="text-blue-700">
              Soal {currentIndex + 1} / 10
            </span>
            <span className="text-slate-500 font-normal">
              {answeredCount} dari 10 soal dijawab
            </span>
          </div>

          <div className="w-full h-2.5 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / 10) * 100}%` }}
            />
          </div>
        </div>

        {/* 10 Question Navigation Pills */}
        <div className="flex items-center justify-between gap-1 sm:gap-2 pt-1 overflow-x-auto pb-1">
          {questions.map((_, idx) => {
            const isAnswered = selectedAnswers[idx] !== null;
            const isCurrent = currentIndex === idx;

            let pillStyle = 'bg-slate-100 text-slate-600 hover:bg-slate-200';
            if (isCurrent) {
              pillStyle = 'bg-blue-600 text-white font-bold ring-2 ring-blue-300';
            } else if (isAnswered) {
              pillStyle = 'bg-blue-100 text-blue-800 font-semibold';
            }

            return (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`w-8 h-8 rounded-xl text-xs flex items-center justify-center transition-all shrink-0 cursor-pointer ${pillStyle}`}
                title={`Lompat ke Soal ${idx + 1}`}
              >
                {idx + 1}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Question Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 md:p-10 border border-blue-100 shadow-sm space-y-6">
        {/* Question Heading */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800">
              Pertanyaan #{currentIndex + 1}
            </span>
            <span className="text-xs text-slate-400">
              Pilihan Ganda
            </span>
          </div>

          <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-slate-900 leading-snug">
            {currentQ.question}
          </h2>
        </div>

        {/* 4 Shuffled Options (A, B, C, D) */}
        <div className="space-y-3 pt-2">
          {currentQ.options.map((opt, optIdx) => {
            const isSelected = selectedAnswers[currentIndex] === optIdx;

            return (
              <button
                key={optIdx}
                type="button"
                onClick={() => handleSelectOption(optIdx)}
                className={`w-full text-left p-4 sm:p-5 rounded-2xl border-2 transition-all flex items-center gap-3.5 group cursor-pointer ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/60 shadow-xs'
                    : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50/60'
                }`}
              >
                <div className={`w-8 h-8 rounded-xl font-bold text-sm flex items-center justify-center shrink-0 transition-colors ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 group-hover:bg-blue-100 group-hover:text-blue-700'
                }`}>
                  {optionLetters[optIdx]}
                </div>

                <span className={`text-xs sm:text-sm md:text-base leading-relaxed flex-1 ${
                  isSelected ? 'font-bold text-blue-950' : 'font-medium text-slate-700'
                }`}>
                  {opt}
                </span>

                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                  isSelected
                    ? 'border-blue-600 bg-blue-600'
                    : 'border-slate-300'
                }`}>
                  {isSelected && <Check className="w-3 h-3 text-white" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Bottom Pagination & Submit Bar */}
        <div className="pt-6 border-t border-slate-100 flex items-center justify-between gap-3">
          <button
            type="button"
            disabled={currentIndex === 0}
            onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
            className="py-3 px-4 sm:px-5 rounded-xl border border-slate-200 text-slate-700 font-semibold text-xs sm:text-sm hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Sebelumnya</span>
          </button>

          {currentIndex < 9 ? (
            <button
              type="button"
              onClick={() => setCurrentIndex(prev => Math.min(9, prev + 1))}
              className="py-3 px-5 sm:px-6 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>Berikutnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmitQuiz}
              className="py-3 px-6 sm:px-8 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs sm:text-sm shadow-md shadow-emerald-600/30 transition-all flex items-center gap-2 cursor-pointer animate-bounce"
            >
              <Sparkles className="w-4 h-4" />
              <span>Selesaikan Kuis (10/10)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
