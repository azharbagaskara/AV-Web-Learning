import React from 'react';
import { EssayHistoryItem, ProgressItem, QuizHistoryItem, UserProfile } from '../types';
import { calculateLevel } from '../utils/storage';
import { 
  Award, 
  BookCheck, 
  Calendar, 
  CheckCircle, 
  Download, 
  GraduationCap, 
  Laptop, 
  LogOut, 
  RotateCcw, 
  ShieldCheck, 
  Sparkles, 
  Star, 
  Trophy, 
  User 
} from 'lucide-react';

interface ProfileViewProps {
  user: UserProfile;
  progressList: ProgressItem[];
  quizHistory: QuizHistoryItem[];
  essayHistory: EssayHistoryItem[];
  onOpenChangeClass: () => void;
  onOpenDownloadPc: () => void;
  onLogout: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  progressList,
  quizHistory,
  essayHistory,
  onOpenChangeClass,
  onOpenDownloadPc,
  onLogout
}) => {
  const levelInfo = calculateLevel(user.totalXP);
  const totalCompletedTopics = progressList.filter(p => p.isCompleted).length;

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Profile Card Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-blue-100/80 shadow-sm relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center font-black text-2xl sm:text-3xl shadow-md shadow-blue-600/20 shrink-0">
              {user.name.charAt(0).toUpperCase()}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  {user.name}
                </h1>
                <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 text-xs font-bold">
                  Siswa Aktif
                </span>
              </div>

              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                Jenjang: <strong className="text-slate-800">Kelas {user.grade} {user.educationLevel}</strong>
              </p>

              <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  Bergabung: {new Date(user.createdAt).toLocaleDateString('id-ID', { month: 'short', year: 'numeric' })}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Ganti Kelas Button */}
          <button
            onClick={onOpenChangeClass}
            className="py-3 px-5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
          >
            <GraduationCap className="w-4 h-4" />
            <span>🎓 Ganti Kelas</span>
          </button>
        </div>
      </div>

      {/* Level & XP Status Banner */}
      <div className="bg-gradient-to-br from-indigo-900 via-blue-900 to-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-400/20 text-amber-300 border border-amber-400/30 flex items-center justify-center text-xl font-bold">
              🏆
            </div>
            <div>
              <div className="text-xs text-blue-200 uppercase tracking-wider font-semibold">
                Status Akademik
              </div>
              <div className="text-lg sm:text-xl font-black text-white">
                Level {levelInfo.level} • {levelInfo.title}
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="text-xs text-blue-200">Total Akumulasi Poin</div>
            <div className="text-xl font-black text-amber-300">
              ⭐ {user.totalXP} XP
            </div>
          </div>
        </div>

        {/* Level XP Progress Bar */}
        <div className="space-y-1.5 pt-1">
          <div className="flex justify-between text-xs text-blue-200">
            <span>Progress menuju Level {levelInfo.level + 1}</span>
            <span className="font-bold text-white">{levelInfo.progressPercent}%</span>
          </div>
          <div className="w-full h-3 rounded-full bg-black/40 overflow-hidden p-0.5">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-400 to-yellow-300 transition-all duration-300"
              style={{ width: `${levelInfo.progressPercent}%` }}
            />
          </div>
          <div className="text-[11px] text-blue-300 text-right">
            Butuh {levelInfo.nextLevelXP - user.totalXP} poin lagi untuk naik level
          </div>
        </div>
      </div>

      {/* Profile Statistics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 sm:gap-4">
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs">
          <div className="text-xs text-slate-500">Materi Selesai</div>
          <div className="text-2xl font-bold text-slate-800 mt-1">
            {totalCompletedTopics} <span className="text-xs font-normal text-slate-400">topik</span>
          </div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">
            ✓ Di seluruh jenjang
          </div>
        </div>

        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs">
          <div className="text-xs text-slate-500">Kuis Diselesaikan</div>
          <div className="text-2xl font-bold text-slate-800 mt-1">
            {quizHistory.length} <span className="text-xs font-normal text-slate-400">kali</span>
          </div>
          <div className="text-[11px] text-blue-600 font-medium mt-1">
            Format 10 Soal Acak
          </div>
        </div>

        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-2xs col-span-2 sm:col-span-1">
          <div className="text-xs text-slate-500">Latihan Essay</div>
          <div className="text-2xl font-bold text-slate-800 mt-1">
            {essayHistory.length} <span className="text-xs font-normal text-slate-400">tulisan</span>
          </div>
          <div className="text-[11px] text-indigo-600 font-medium mt-1">
            Penilaian Otomatis Rubrik
          </div>
        </div>
      </div>

      {/* Account Settings / Actions */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-2xs space-y-4">
        <h3 className="font-bold text-slate-800 text-base">
          Pengaturan Akun & Data
        </h3>

        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 rounded-2xl bg-blue-50/60 border border-blue-100">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0" />
              <div>
                <div className="text-sm font-bold text-slate-800">Penyimpanan Progres Lokal</div>
                <div className="text-xs text-slate-500">Seluruh riwayat belajar tersimpan aman di browsermu</div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-900 text-white">
            <div className="flex items-center gap-3">
              <Laptop className="w-6 h-6 text-sky-400 shrink-0" />
              <div>
                <div className="text-sm font-bold">Gunakan Offline di PC / Laptop</div>
                <div className="text-xs text-slate-300">Unduh sebagai 1 file HTML mandiri (bisa dibuka tanpa internet)</div>
              </div>
            </div>

            <button
              onClick={onOpenDownloadPc}
              className="py-2 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download HTML</span>
            </button>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              onClick={onOpenChangeClass}
              className="w-full sm:w-auto py-2.5 px-4 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <GraduationCap className="w-4 h-4 text-blue-600" />
              <span>Ganti Kelas Aktif</span>
            </button>

            <button
              onClick={onLogout}
              className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs sm:text-sm font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Keluar / Ganti Siswa</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
