import React, { useEffect, useState } from 'react';
import { 
  EducationLevel, 
  EssayHistoryItem, 
  ProgressItem, 
  QuizHistoryItem, 
  Subject, 
  Topic, 
  UserProfile 
} from './types';
import { SUBJECTS, getSubjectsByEducationLevel } from './data/curriculumData';
import { TOPICS } from './data/topicsData';
import { 
  clearAllStorage, 
  getEssayHistory, 
  getProgressList, 
  getQuizHistory, 
  getUserProfile, 
  updateUserGrade 
} from './utils/storage';

import { Navbar } from './components/Navbar';
import { MobileDrawer } from './components/MobileDrawer';
import { AuthModal } from './components/AuthModal';
import { ChangeClassModal } from './components/ChangeClassModal';
import { DownloadPcModal } from './components/DownloadPcModal';
import { DashboardView } from './components/DashboardView';
import { SubjectHierarchyView } from './components/SubjectHierarchyView';
import { MaterialStudyView } from './components/MaterialStudyView';
import { QuizView } from './components/QuizView';
import { EssayPracticeView } from './components/EssayPracticeView';
import { QuizzesListView } from './components/QuizzesListView';
import { EssaysListView } from './components/EssaysListView';
import { ProgressView } from './components/ProgressView';
import { ProfileView } from './components/ProfileView';

export function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [progressList, setProgressList] = useState<ProgressItem[]>([]);
  const [quizHistory, setQuizHistory] = useState<QuizHistoryItem[]>([]);
  const [essayHistory, setEssayHistory] = useState<EssayHistoryItem[]>([]);

  // Subject & Topic navigation state
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [selectedSemester, setSelectedSemester] = useState<1 | 2>(1);
  const [activeTopic, setActiveTopic] = useState<Topic | null>(null);

  // Modals state
  const [isChangeClassModalOpen, setIsChangeClassModalOpen] = useState(false);
  const [isDownloadPcModalOpen, setIsDownloadPcModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Initialize data from LocalStorage
  useEffect(() => {
    const savedUser = getUserProfile();
    if (savedUser) {
      setUser(savedUser);
    }
    setProgressList(getProgressList());
    setQuizHistory(getQuizHistory());
    setEssayHistory(getEssayHistory());
  }, []);

  const refreshState = () => {
    const updatedUser = getUserProfile();
    if (updatedUser) setUser(updatedUser);
    setProgressList(getProgressList());
    setQuizHistory(getQuizHistory());
    setEssayHistory(getEssayHistory());
  };

  const handleLoginSuccess = (profile: UserProfile) => {
    setUser(profile);
    refreshState();
    setActiveView('dashboard');
  };

  const handleSaveClass = (newJenjang: EducationLevel, newGrade: number) => {
    const updated = updateUserGrade(newJenjang, newGrade);
    if (updated) {
      setUser({ ...updated });
      setSelectedSubjectId(null);
      setActiveTopic(null);
      refreshState();
    }
  };

  const handleOpenSubject = (subjectId: string, semester: 1 | 2 = 1) => {
    setSelectedSubjectId(subjectId);
    setSelectedSemester(semester);
    setActiveView('subjects');
  };

  const handleOpenTopic = (topic: Topic) => {
    setActiveTopic(topic);
    setSelectedSubjectId(topic.subjectId);
    setSelectedSemester(topic.semester);
    setActiveView('study');
  };

  const handleStartQuiz = (topic: Topic) => {
    setActiveTopic(topic);
    setSelectedSubjectId(topic.subjectId);
    setSelectedSemester(topic.semester);
    setActiveView('quiz-active');
  };

  const handleStartEssay = (topic: Topic) => {
    setActiveTopic(topic);
    setSelectedSubjectId(topic.subjectId);
    setSelectedSemester(topic.semester);
    setActiveView('essay-active');
  };

  const handleFinishQuiz = (updatedProfile: UserProfile) => {
    setUser(updatedProfile);
    refreshState();
  };

  const handleFinishEssay = (updatedProfile: UserProfile) => {
    setUser(updatedProfile);
    refreshState();
  };

  const handleLogout = () => {
    if (window.confirm('Apakah kamu yakin ingin keluar? Progres belajar tetap tersimpan di browser ini.')) {
      localStorage.removeItem('av_learning_user_profile');
      setUser(null);
      setActiveView('dashboard');
    }
  };

  // If no registered user, show the welcome and grade selector screen
  if (!user) {
    return <AuthModal onLoginSuccess={handleLoginSuccess} />;
  }

  // Get active subjects for student's jenjang
  const activeSubjects = getSubjectsByEducationLevel(user.educationLevel);
  const currentSubjectObj = selectedSubjectId
    ? activeSubjects.find(s => s.id === selectedSubjectId)
    : undefined;

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-100 via-blue-50 to-indigo-100/70 text-slate-800 flex flex-col font-sans selection:bg-blue-500 selection:text-white">
      {/* Top Fixed Navbar */}
      <Navbar
        user={user}
        activeView={activeView}
        onNavigate={(view) => {
          if (view === 'subjects' && activeView !== 'subjects') {
            setSelectedSubjectId(null);
          }
          setActiveView(view);
        }}
        onOpenChangeClass={() => setIsChangeClassModalOpen(true)}
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
        onOpenDownloadPc={() => setIsDownloadPcModalOpen(true)}
        mobileMenuOpen={isMobileMenuOpen}
      />

      {/* Mobile Navigation Drawer */}
      <MobileDrawer
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        user={user}
        activeView={activeView}
        onNavigate={(view) => {
          if (view === 'subjects' && activeView !== 'subjects') {
            setSelectedSubjectId(null);
          }
          setActiveView(view);
        }}
        onOpenChangeClass={() => setIsChangeClassModalOpen(true)}
        onOpenDownloadPc={() => setIsDownloadPcModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
        {/* VIEW: DASHBOARD */}
        {activeView === 'dashboard' && (
          <DashboardView
            user={user}
            subjects={activeSubjects}
            topics={TOPICS}
            progressList={progressList}
            quizHistory={quizHistory}
            onOpenSubject={handleOpenSubject}
            onOpenTopic={handleOpenTopic}
            onStartQuiz={handleStartQuiz}
            onStartEssay={handleStartEssay}
            onOpenChangeClass={() => setIsChangeClassModalOpen(true)}
            onOpenDownloadPc={() => setIsDownloadPcModalOpen(true)}
            onNavigate={setActiveView}
          />
        )}

        {/* VIEW: SUBJECTS & LESSONS (Silabus & Materi) */}
        {activeView === 'subjects' && (
          <SubjectHierarchyView
            user={user}
            subjects={activeSubjects}
            topics={TOPICS}
            progressList={progressList}
            selectedSubjectId={selectedSubjectId}
            selectedSemester={selectedSemester}
            onSelectSubject={setSelectedSubjectId}
            onSelectSemester={setSelectedSemester}
            onOpenTopic={handleOpenTopic}
            onStartQuiz={handleStartQuiz}
            onStartEssay={handleStartEssay}
          />
        )}

        {/* VIEW: STUDY MATERIAL DETAIL */}
        {activeView === 'study' && activeTopic && (
          <MaterialStudyView
            user={user}
            topic={activeTopic}
            subject={currentSubjectObj}
            onBack={() => setActiveView('subjects')}
            onStartQuiz={handleStartQuiz}
            onStartEssay={handleStartEssay}
          />
        )}

        {/* VIEW: ACTIVE 10-QUESTION QUIZ */}
        {activeView === 'quiz-active' && activeTopic && (
          <QuizView
            user={user}
            topic={activeTopic}
            subject={currentSubjectObj}
            onFinishQuiz={handleFinishQuiz}
            onBackToTopic={() => setActiveView('study')}
            onStartEssay={handleStartEssay}
            onGoHome={() => setActiveView('dashboard')}
          />
        )}

        {/* VIEW: ACTIVE ESSAY PRACTICE */}
        {activeView === 'essay-active' && activeTopic && (
          <EssayPracticeView
            user={user}
            topic={activeTopic}
            subject={currentSubjectObj}
            onFinishEssay={handleFinishEssay}
            onBackToTopic={() => setActiveView('study')}
            onStartQuiz={handleStartQuiz}
          />
        )}

        {/* VIEW: QUIZZES TAB (10 Questions List & History) */}
        {activeView === 'quizzes' && (
          <QuizzesListView
            user={user}
            subjects={activeSubjects}
            topics={TOPICS}
            quizHistory={quizHistory}
            onStartQuiz={handleStartQuiz}
          />
        )}

        {/* VIEW: ESSAYS TAB */}
        {activeView === 'essays' && (
          <EssaysListView
            user={user}
            subjects={activeSubjects}
            topics={TOPICS}
            essayHistory={essayHistory}
            onStartEssay={handleStartEssay}
          />
        )}

        {/* VIEW: PROGRESS TRACKING */}
        {activeView === 'progress' && (
          <ProgressView
            user={user}
            subjects={activeSubjects}
            topics={TOPICS}
            progressList={progressList}
            quizHistory={quizHistory}
            essayHistory={essayHistory}
            onOpenSubject={handleOpenSubject}
          />
        )}

        {/* VIEW: USER PROFILE & GRADE SETTINGS */}
        {activeView === 'profile' && (
          <ProfileView
            user={user}
            progressList={progressList}
            quizHistory={quizHistory}
            essayHistory={essayHistory}
            onOpenChangeClass={() => setIsChangeClassModalOpen(true)}
            onOpenDownloadPc={() => setIsDownloadPcModalOpen(true)}
            onLogout={handleLogout}
          />
        )}
      </main>

      {/* Change Class Modal (Always Accessible) */}
      <ChangeClassModal
        isOpen={isChangeClassModalOpen}
        onClose={() => setIsChangeClassModalOpen(false)}
        currentLevel={user.educationLevel}
        currentGrade={user.grade}
        onSaveClass={handleSaveClass}
      />

      {/* Download PC Standalone HTML Modal */}
      <DownloadPcModal
        isOpen={isDownloadPcModalOpen}
        onClose={() => setIsDownloadPcModalOpen(false)}
      />

      {/* App Footer */}
      <footer className="bg-white/80 backdrop-blur-xs border-t border-blue-100 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-blue-600 text-white font-black text-xs flex items-center justify-center">
              AV
            </div>
            <span className="font-bold text-slate-700">AV Learning</span>
            <span>— Platform Belajar Interaktif SD • SMP • SMA</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <button
              onClick={() => setIsDownloadPcModalOpen(true)}
              className="font-bold text-blue-600 hover:text-blue-700 underline cursor-pointer"
            >
              💻 Download File HTML PC
            </button>
            <span>•</span>
            <span>Kurikulum Merdeka 2026</span>
            <span>•</span>
            <span>Pilihan Ganda 10 Soal Acak</span>
            <span>•</span>
            <span>Penilaian Rubrik Essay</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
export default App;
