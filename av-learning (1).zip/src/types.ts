export type EducationLevel = 'SD' | 'SMP' | 'SMA';

export type DifficultyLevel = 'mudah' | 'sedang' | 'sulit';

export interface UserProfile {
  id: string;
  name: string;
  educationLevel: EducationLevel;
  grade: number; // 1 to 12
  totalXP: number;
  level: number; // 1, 2, 3, 4, 5, etc.
  completedQuizzesCount: number;
  completedEssaysCount: number;
  lastStudiedTopicId: string | null;
  lastStudiedTopicTitle: string | null;
  lastStudiedSubjectName: string | null;
  createdAt: string;
}

export interface ProgressItem {
  jenjang: EducationLevel;
  grade: number;
  subjectId: string;
  semester: 1 | 2;
  topicId: string;
  isCompleted: boolean;
  bestQuizScore: number;
  quizAttempts: number;
  essayAttempts: number;
  lastAccessedAt: string;
}

export interface Question {
  id: string;
  jenjang: EducationLevel;
  grade: number;
  subjectId: string;
  semester: 1 | 2;
  topicId: string;
  difficulty: DifficultyLevel;
  question: string;
  options: string[]; // 4 options
  correctIndex: number; // 0-3
  explanation: string;
}

export interface EssayQuestion {
  id: string;
  jenjang: EducationLevel;
  grade: number;
  subjectId: string;
  semester: 1 | 2;
  topicId: string;
  difficulty: DifficultyLevel;
  question: string;
  referenceAnswer: string;
  keywords: string[];
  rubric: {
    criteria: string;
    points: number;
  }[];
  explanation: string;
}

export interface Topic {
  id: string;
  title: string;
  description: string;
  subjectId: string;
  grade: number;
  semester: 1 | 2;
  difficulty: DifficultyLevel;
  estimatedMinutes: number;
  // Study Material Content
  explanation: string;
  coreConcepts: {
    title: string;
    description: string;
    example?: string;
  }[];
  realWorldExample: string;
  summary: string[];
  studyTips: string;
}

export interface SemesterSyllabus {
  semester: 1 | 2;
  theme: string;
  description: string;
  mainTopics: string[];
  expectedCompetencies: string[];
}

export interface Subject {
  id: string;
  name: string;
  icon: string; // Lucide icon name or emoji
  color: string; // Tailwind color class
  accentColor: string;
  description: string;
  educationLevel: EducationLevel;
  grades: number[];
  semester1Syllabus: SemesterSyllabus;
  semester2Syllabus: SemesterSyllabus;
}

export interface QuizHistoryItem {
  id: string;
  date: string;
  jenjang: EducationLevel;
  grade: number;
  subjectId: string;
  subjectName: string;
  semester: 1 | 2;
  topicId: string;
  topicTitle: string;
  score: number; // 0-100
  correctCount: number;
  incorrectCount: number;
  totalQuestions: number; // 10
  pointsEarned: number;
  userLevelAtQuiz: number;
  difficultyUsed: DifficultyLevel;
  answersReview: {
    questionText: string;
    userAnswer: string;
    correctAnswer: string;
    isCorrect: boolean;
    explanation: string;
  }[];
}

export interface EssayHistoryItem {
  id: string;
  date: string;
  jenjang: EducationLevel;
  grade: number;
  subjectId: string;
  subjectName: string;
  semester: 1 | 2;
  topicId: string;
  topicTitle: string;
  questionText?: string;
  userAnswer: string;
  score: number; // 0-100
  pointsEarned: number;
  feedback: string;
  referenceAnswer?: string;
  matchedKeywords: string[];
}
