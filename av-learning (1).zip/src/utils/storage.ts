import { EducationLevel, EssayHistoryItem, ProgressItem, QuizHistoryItem, UserProfile } from '../types';

const STORAGE_KEYS = {
  USER_PROFILE: 'av_learning_user_profile',
  PROGRESS: 'av_learning_progress_items',
  QUIZ_HISTORY: 'av_learning_quiz_history',
  ESSAY_HISTORY: 'av_learning_essay_history'
};

export function calculateLevel(xp: number): { level: number; title: string; currentLevelMinXP: number; nextLevelXP: number; progressPercent: number } {
  const level = Math.floor(xp / 100) + 1;
  const currentLevelMinXP = (level - 1) * 100;
  const nextLevelXP = level * 100;
  const xpInCurrentLevel = xp - currentLevelMinXP;
  const progressPercent = Math.min(100, Math.max(0, Math.round((xpInCurrentLevel / 100) * 100)));

  let title = 'Pemula Cerdas';
  if (level === 2) title = 'Pelajar Aktif';
  else if (level === 3) title = 'Penjelajah Ilmu';
  else if (level === 4) title = 'Master Akademik';
  else if (level >= 5) title = 'Sang Bintang Juara';

  return {
    level,
    title,
    currentLevelMinXP,
    nextLevelXP,
    progressPercent
  };
}

export function getUserProfile(): UserProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse user profile', e);
    return null;
  }
}

export function saveUserProfile(profile: UserProfile): void {
  const levelInfo = calculateLevel(profile.totalXP);
  profile.level = levelInfo.level;
  localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
}

export function createInitialProfile(name: string, educationLevel: EducationLevel, grade: number): UserProfile {
  const newProfile: UserProfile = {
    id: `usr_${Date.now()}`,
    name: name.trim(),
    educationLevel,
    grade,
    totalXP: 0,
    level: 1,
    completedQuizzesCount: 0,
    completedEssaysCount: 0,
    lastStudiedTopicId: null,
    lastStudiedTopicTitle: null,
    lastStudiedSubjectName: null,
    createdAt: new Date().toISOString()
  };
  saveUserProfile(newProfile);
  return newProfile;
}

export function updateUserGrade(newJenjang: EducationLevel, newGrade: number): UserProfile | null {
  const profile = getUserProfile();
  if (!profile) return null;

  profile.educationLevel = newJenjang;
  profile.grade = newGrade;
  saveUserProfile(profile);
  return profile;
}

export function addXPToProfile(points: number, lastTopicId?: string, lastTopicTitle?: string, lastSubjectName?: string): { profile: UserProfile; leveledUp: boolean; oldLevel: number; newLevel: number } {
  let profile = getUserProfile();
  if (!profile) {
    profile = createInitialProfile('Siswa AV', 'SMP', 8);
  }

  const oldLevel = profile.level;
  profile.totalXP += points;
  const newLevelInfo = calculateLevel(profile.totalXP);
  profile.level = newLevelInfo.level;

  if (lastTopicId) profile.lastStudiedTopicId = lastTopicId;
  if (lastTopicTitle) profile.lastStudiedTopicTitle = lastTopicTitle;
  if (lastSubjectName) profile.lastStudiedSubjectName = lastSubjectName;

  saveUserProfile(profile);

  return {
    profile,
    leveledUp: newLevelInfo.level > oldLevel,
    oldLevel,
    newLevel: newLevelInfo.level
  };
}

export function getProgressList(): ProgressItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PROGRESS);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveTopicProgress(
  jenjang: EducationLevel,
  grade: number,
  subjectId: string,
  semester: 1 | 2,
  topicId: string,
  isQuiz: boolean,
  score: number
): void {
  const items = getProgressList();
  const existingIdx = items.findIndex(
    p => p.topicId === topicId && p.grade === grade && p.semester === semester
  );

  if (existingIdx >= 0) {
    const existing = items[existingIdx];
    existing.bestQuizScore = isQuiz ? Math.max(existing.bestQuizScore, score) : existing.bestQuizScore;
    if (isQuiz) existing.quizAttempts += 1;
    else existing.essayAttempts += 1;
    if (score >= 70 || !isQuiz) existing.isCompleted = true;
    existing.lastAccessedAt = new Date().toISOString();
    items[existingIdx] = existing;
  } else {
    items.push({
      jenjang,
      grade,
      subjectId,
      semester,
      topicId,
      isCompleted: score >= 70 || !isQuiz,
      bestQuizScore: isQuiz ? score : 0,
      quizAttempts: isQuiz ? 1 : 0,
      essayAttempts: isQuiz ? 0 : 1,
      lastAccessedAt: new Date().toISOString()
    });
  }

  localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(items));
}

export function getQuizHistory(): QuizHistoryItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.QUIZ_HISTORY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveQuizHistory(item: QuizHistoryItem): void {
  const list = getQuizHistory();
  list.unshift(item); // prepend newest
  localStorage.setItem(STORAGE_KEYS.QUIZ_HISTORY, JSON.stringify(list));

  // Also increment completed quiz count in profile
  const profile = getUserProfile();
  if (profile) {
    profile.completedQuizzesCount = (profile.completedQuizzesCount || 0) + 1;
    saveUserProfile(profile);
  }
}

export function getEssayHistory(): EssayHistoryItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ESSAY_HISTORY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveEssayHistory(item: EssayHistoryItem): void {
  const list = getEssayHistory();
  list.unshift(item);
  localStorage.setItem(STORAGE_KEYS.ESSAY_HISTORY, JSON.stringify(list));

  const profile = getUserProfile();
  if (profile) {
    profile.completedEssaysCount = (profile.completedEssaysCount || 0) + 1;
    saveUserProfile(profile);
  }
}

export function clearAllStorage(): void {
  localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
  localStorage.removeItem(STORAGE_KEYS.PROGRESS);
  localStorage.removeItem(STORAGE_KEYS.QUIZ_HISTORY);
  localStorage.removeItem(STORAGE_KEYS.ESSAY_HISTORY);
}
