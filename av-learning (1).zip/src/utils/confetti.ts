import confetti from 'canvas-confetti';

export function triggerFireworks() {
  // Burst 1
  confetti({
    particleCount: 80,
    spread: 70,
    origin: { y: 0.6 },
    colors: ['#38bdf8', '#3b82f6', '#1d4ed8', '#fbbf24', '#f43f5e', '#10b981']
  });

  // Delayed Side Cannons
  setTimeout(() => {
    confetti({
      particleCount: 50,
      angle: 60,
      spread: 55,
      origin: { x: 0, y: 0.7 },
      colors: ['#60a5fa', '#3b82f6', '#93c5fd', '#fbbf24']
    });
    confetti({
      particleCount: 50,
      angle: 120,
      spread: 55,
      origin: { x: 1, y: 0.7 },
      colors: ['#60a5fa', '#3b82f6', '#93c5fd', '#fbbf24']
    });
  }, 250);

  // Big celebration shower
  setTimeout(() => {
    confetti({
      particleCount: 100,
      spread: 100,
      origin: { y: 0.4 },
      gravity: 0.8,
      ticks: 300,
      shapes: ['circle', 'square']
    });
  }, 500);
}
