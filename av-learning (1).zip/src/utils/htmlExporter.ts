/**
 * Utility to download the standalone AV Learning application as a single .html file
 * that can be opened directly on any PC browser (Chrome, Edge, Firefox) without internet.
 */

export async function downloadStandaloneHtml(): Promise<boolean> {
  try {
    // 1. Try to fetch compiled single-file bundle from /dist/index.html
    const response = await fetch('/dist/index.html');
    if (response.ok) {
      const htmlText = await response.text();
      triggerDownload(htmlText, 'AV-Learning-Offline.html');
      return true;
    }
  } catch {
    // Fallback if not available via dist route
  }

  try {
    // 2. Fallback: generate a standalone HTML document snapshot
    const currentHtml = document.documentElement.outerHTML;
    const cleanHtml = `<!DOCTYPE html>\n` + currentHtml;
    triggerDownload(cleanHtml, 'AV-Learning-Offline.html');
    return true;
  } catch (error) {
    console.error('Failed to export HTML:', error);
    return false;
  }
}

function triggerDownload(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
